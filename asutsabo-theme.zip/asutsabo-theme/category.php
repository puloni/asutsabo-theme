<?php
/**
 * The template for displaying Category pages.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$asutsabo_layout = asutsabo_get_layout();
$has_sidebar     = ( 'right-sidebar' === $asutsabo_layout && is_active_sidebar( 'primary-sidebar' ) );
$layout_class    = $has_sidebar ? 'asutsabo-has-sidebar' : 'asutsabo-no-sidebar';
?>

<main id="primary-content" class="site-main asutsabo-category-main asutsabo-container alignwide <?php echo esc_attr( $layout_class ); ?>" style="padding-top:2rem;padding-bottom:4rem;">
	<header class="page-header asutsabo-archive-header" style="border-bottom:2px solid var(--wp--preset--color--border-dark, #2B2927);padding-bottom:1.5rem;margin-bottom:2.5rem;">
		<span class="is-style-asutsabo-kicker"><?php esc_html_e( 'The News Desk', 'asutsabo' ); ?></span>
		<h1 class="page-title is-style-asutsabo-featured-headline" style="margin:0.25rem 0 0.5rem 0;">
			<?php single_cat_title(); ?>
		</h1>
		<?php if ( category_description() ) : ?>
			<div class="archive-description" style="font-size:1.1rem;color:var(--wp--preset--color--secondary, #474542);line-height:1.6;margin-top:0.5rem;">
				<?php echo category_description(); ?>
			</div>
		<?php endif; ?>
	</header>

	<div class="asutsabo-layout-container <?php echo $has_sidebar ? 'asutsabo-layout-with-sidebar' : 'asutsabo-layout-single-column'; ?>">
		<div class="asutsabo-content-column">
			<?php if ( have_posts() ) : ?>
				<div class="asutsabo-grid asutsabo-archive-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/post/content' );
					endwhile;
					?>
				</div>

				<div class="asutsabo-pagination-wrap" style="margin-top:3.5rem;text-align:center;">
					<?php
					the_posts_pagination(
						array(
							'prev_text' => __( '&larr; Previous', 'asutsabo' ),
							'next_text' => __( 'Next &rarr;', 'asutsabo' ),
						)
					);
					?>
				</div>
			<?php else : ?>
				<div class="asutsabo-no-results" style="padding:3rem 0;text-align:center;">
					<h2 class="is-style-asutsabo-section-label"><?php esc_html_e( 'No Dispatches in this Section', 'asutsabo' ); ?></h2>
					<p style="font-size:1.1rem;color:var(--wp--preset--color--secondary, #474542);">
						<?php esc_html_e( 'Currently there are no published reports under this desk. Please check back soon.', 'asutsabo' ); ?>
					</p>
					<?php get_search_form(); ?>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $has_sidebar ) : ?>
			<div class="asutsabo-sidebar-column">
				<?php get_sidebar(); ?>
			</div>
		<?php endif; ?>
	</div>
</main><!-- #primary-content -->

<?php
get_footer();
