<?php
/**
 * Asutsabo Classic/Hybrid Theme Setup & Definitions.
 *
 * Configures theme support, menus, widget areas, image sizes, asset enqueues,
 * and custom post metadata.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function asutsabo_setup() {
	// Make theme available for translation.
	load_theme_textdomain( 'asutsabo', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	// Let WordPress manage the document title.
	add_theme_support( 'title-tag' );

	// Enable support for Post Thumbnails on posts and pages.
	add_theme_support( 'post-thumbnails' );

	// Custom Logo support.
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 120,
			'width'       => 360,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);

	// Switch default core markup for search form, comment form, and comments to output valid HTML5.
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Add support for responsive embedded content.
	add_theme_support( 'responsive-embeds' );

	// Add support for core block visual styles.
	add_theme_support( 'wp-block-styles' );

	// Add support for full and wide align images in Gutenberg.
	add_theme_support( 'align-wide' );

	// Add support for editor styles.
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/editor.css' );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	// Register Navigation Menus.
	register_nav_menus(
		array(
			'primary'          => esc_html__( 'Main Navigation', 'asutsabo' ),
			'top-bar'          => esc_html__( 'Top Bar Navigation', 'asutsabo' ),
			'footer'           => esc_html__( 'Footer Navigation (Bottom Bar)', 'asutsabo' ),
			'footer-sections'  => esc_html__( 'Footer Sections Menu (Column 2)', 'asutsabo' ),
			'footer-standards' => esc_html__( 'Footer Standards & Policies Menu (Column 3)', 'asutsabo' ),
		)
	);

	// Register custom editorial image sizes.
	add_image_size( 'asutsabo-hero', 1600, 900, true );
	add_image_size( 'asutsabo-feature', 1200, 800, true );
	add_image_size( 'asutsabo-editorial-grid', 800, 533, true );
	add_image_size( 'asutsabo-thumbnail-square', 400, 400, true );
	add_image_size( 'asutsabo-thumbnail-wide', 600, 338, true );
}
add_action( 'after_setup_theme', 'asutsabo_setup' );

/**
 * Register widget area / sidebars.
 */
function asutsabo_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Homepage Top', 'asutsabo' ),
			'id'            => 'home-top',
			'description'   => esc_html__( 'Appears below the main navigation on the magazine front page.', 'asutsabo' ),
			'before_widget' => '<div id="%1$s" class="widget asutsabo-home-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title is-style-asutsabo-section-label">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Homepage Middle', 'asutsabo' ),
			'id'            => 'home-middle',
			'description'   => esc_html__( 'Appears below Editor\'s Picks on the magazine front page.', 'asutsabo' ),
			'before_widget' => '<div id="%1$s" class="widget asutsabo-home-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title is-style-asutsabo-section-label">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Homepage Bottom', 'asutsabo' ),
			'id'            => 'home-bottom',
			'description'   => esc_html__( 'Appears above the footer on the magazine front page.', 'asutsabo' ),
			'before_widget' => '<div id="%1$s" class="widget asutsabo-home-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title is-style-asutsabo-section-label">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Primary Sidebar', 'asutsabo' ),
			'id'            => 'primary-sidebar',
			'description'   => esc_html__( 'Appears in the single article sidebar and archive pages.', 'asutsabo' ),
			'before_widget' => '<section id="%1$s" class="widget asutsabo-widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title is-style-asutsabo-section-label">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Column 1 (About)', 'asutsabo' ),
			'id'            => 'footer-1',
			'description'   => esc_html__( 'First footer column for publication overview.', 'asutsabo' ),
			'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-widget-title is-style-asutsabo-section-label">',
			'after_title'   => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Column 2 (Sections)', 'asutsabo' ),
			'id'            => 'footer-2',
			'description'   => esc_html__( 'Second footer column for section navigation links.', 'asutsabo' ),
			'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-widget-title is-style-asutsabo-section-label">',
			'after_title'   => '</h4>',
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Column 3 (Standards)', 'asutsabo' ),
			'id'            => 'footer-3',
			'description'   => esc_html__( 'Third footer column for policies and editorial standards.', 'asutsabo' ),
			'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-widget-title is-style-asutsabo-section-label">',
			'after_title'   => '</h4>',
		)
	);

}
add_action( 'widgets_init', 'asutsabo_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function asutsabo_enqueue_scripts() {
	$theme_version = wp_get_theme()->get( 'Version' );

	// Main theme stylesheet.
	wp_enqueue_style( 'asutsabo-style', get_stylesheet_uri(), array(), $theme_version );

	// Screen enhancements, responsive layouts, components.
	wp_enqueue_style(
		'asutsabo-screen',
		get_template_directory_uri() . '/assets/css/screen.css',
		array( 'asutsabo-style' ),
		$theme_version
	);

	// Navigation progressive enhancement & mobile drawer toggle.
	wp_enqueue_script(
		'asutsabo-navigation',
		get_template_directory_uri() . '/assets/js/navigation.js',
		array(),
		$theme_version,
		true
	);

	// Breaking news dismiss alert script (sessionStorage memory).
	wp_enqueue_script(
		'asutsabo-dismiss-notice',
		get_template_directory_uri() . '/assets/js/dismiss-notice.js',
		array(),
		$theme_version,
		true
	);

	// Reader enhancements: progress bar, preferences (dark/sepia/font), TOC, back-to-top, breaking news ticker.
	wp_enqueue_script(
		'asutsabo-reader',
		get_template_directory_uri() . '/assets/js/reader.js',
		array(),
		$theme_version,
		true
	);
	wp_localize_script(
		'asutsabo-reader',
		'asutsaboReaderL10n',
		array(
			'copied'       => __( 'Link copied to clipboard!', 'asutsabo' ),
			'collapseTOC'  => __( 'Collapse Contents', 'asutsabo' ),
			'expandTOC'    => __( 'Expand Contents', 'asutsabo' ),
		)
	);

	// Social share interactions on single posts.
	if ( is_singular( 'post' ) ) {
		wp_enqueue_script(
			'asutsabo-share',
			get_template_directory_uri() . '/assets/js/share.js',
			array(),
			$theme_version,
			true
		);

		wp_localize_script(
			'asutsabo-share',
			'asutsaboShareL10n',
			array(
				'copied'     => __( 'Link copied to clipboard!', 'asutsabo' ),
				'copyError'  => __( 'Failed to copy link. Please copy the URL manually.', 'asutsabo' ),
				'shareTitle' => get_the_title(),
				'shareUrl'   => esc_url( get_permalink() ),
			)
		);
	}

	// Comment reply script for threaded comments.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'asutsabo_enqueue_scripts' );

/**
 * Enqueue editor-only scripts and styles.
 */
function asutsabo_enqueue_block_editor_assets() {
	$theme_version = wp_get_theme()->get( 'Version' );

	wp_enqueue_style(
		'asutsabo-editor-custom',
		get_template_directory_uri() . '/assets/css/editor.css',
		array(),
		$theme_version
	);
}
add_action( 'enqueue_block_editor_assets', 'asutsabo_enqueue_block_editor_assets' );

/**
 * Primary menu fallback when no menu is assigned.
 */
function asutsabo_primary_menu_fallback() {
	echo '<nav class="main-navigation asutsabo-nav" aria-label="' . esc_attr__( 'Primary Navigation', 'asutsabo' ) . '">';
	echo '<ul class="nav-menu asutsabo-nav-menu">';
	echo '<li class="menu-item ' . ( is_front_page() ? 'current-menu-item' : '' ) . '"><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'asutsabo' ) . '</a></li>';

	// List top editorial categories if available, else pages
	$categories = get_categories(
		array(
			'number'     => 10,
			'orderby'    => 'count',
			'order'      => 'DESC',
			'hide_empty' => false,
		)
	);

	if ( ! empty( $categories ) ) {
		foreach ( $categories as $cat ) {
			if ( $cat->slug === 'uncategorized' ) {
				continue;
			}
			$is_current = is_category( $cat->term_id ) ? 'current-menu-item' : '';
			echo '<li class="menu-item ' . esc_attr( $is_current ) . '"><a href="' . esc_url( get_category_link( $cat->term_id ) ) . '">' . esc_html( $cat->name ) . '</a></li>';
		}
	} else {
		wp_list_pages(
			array(
				'title_li' => '',
				'depth'    => 1,
				'number'   => 8,
			)
		);
	}

	echo '</ul>';
	echo '</nav>';
}

/**
 * Footer menu fallback when no menu is assigned.
 */
function asutsabo_footer_menu_fallback() {
	echo '<ul class="footer-nav-menu asutsabo-footer-nav-menu">';
	wp_list_pages(
		array(
			'title_li' => '',
			'depth'    => 1,
			'number'   => 6,
		)
	);
	echo '</ul>';
}

/**
 * Register post meta for Post Subtitle / Summary.
 */
function asutsabo_register_subtitle_meta() {
	register_post_meta(
		'post',
		'_asutsabo_subtitle',
		array(
			'show_in_rest'      => true,
			'single'            => true,
			'type'              => 'string',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
			'sanitize_callback' => 'wp_kses_post',
		)
	);
}
add_action( 'init', 'asutsabo_register_subtitle_meta' );

/**
 * Register post meta for Editor's Pick.
 */
function asutsabo_register_editors_pick_meta() {
	register_post_meta(
		'post',
		'_asutsabo_editors_pick',
		array(
			'show_in_rest'      => true,
			'single'            => true,
			'type'              => 'boolean',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
			'sanitize_callback' => 'rest_sanitize_boolean',
		)
	);
}
add_action( 'init', 'asutsabo_register_editors_pick_meta' );

/**
 * Add meta box in post editor for Editor's Pick.
 */
function asutsabo_add_editors_pick_meta_box() {
	add_meta_box(
		'asutsabo_editors_pick_box',
		__( "Editor's Pick", 'asutsabo' ),
		'asutsabo_render_editors_pick_meta_box',
		'post',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'asutsabo_add_editors_pick_meta_box' );

/**
 * Render the Editor's Pick meta box.
 *
 * @param WP_Post $post Current post object.
 */
function asutsabo_render_editors_pick_meta_box( $post ) {
	wp_nonce_field( 'asutsabo_editors_pick_nonce_action', 'asutsabo_editors_pick_nonce' );
	$is_pick = (bool) get_post_meta( $post->ID, '_asutsabo_editors_pick', true );
	?>
	<p>
		<label>
			<input type="checkbox" name="asutsabo_editors_pick" value="1" <?php checked( $is_pick, true ); ?> />
			<strong><?php esc_html_e( 'Feature as Editor\'s Pick', 'asutsabo' ); ?></strong>
		</label>
	</p>
	<p class="description">
		<?php esc_html_e( 'Displays this article in the Editor\'s Picks showcase on the homepage.', 'asutsabo' ); ?>
	</p>
	<?php
}

/**
 * Save the Editor's Pick meta box value.
 *
 * @param int $post_id Post ID.
 */
function asutsabo_save_editors_pick_meta_box( $post_id ) {
	if ( ! isset( $_POST['asutsabo_editors_pick_nonce'] ) ||
	     ! wp_verify_nonce( $_POST['asutsabo_editors_pick_nonce'], 'asutsabo_editors_pick_nonce_action' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$is_pick = ! empty( $_POST['asutsabo_editors_pick'] ) ? 1 : 0;
	update_post_meta( $post_id, '_asutsabo_editors_pick', $is_pick );
}
add_action( 'save_post', 'asutsabo_save_editors_pick_meta_box' );

/**
 * Add meta box in post editor for Post Subtitle / Summary.
 */
function asutsabo_add_subtitle_meta_box() {
	add_meta_box(
		'asutsabo_subtitle_box',
		__( 'Post Subtitle / Summary', 'asutsabo' ),
		'asutsabo_render_subtitle_meta_box',
		'post',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'asutsabo_add_subtitle_meta_box' );

/**
 * Render the Post Subtitle / Summary meta box.
 *
 * @param WP_Post $post Current post object.
 */
function asutsabo_render_subtitle_meta_box( $post ) {
	wp_nonce_field( 'asutsabo_subtitle_nonce_action', 'asutsabo_subtitle_nonce' );
	$subtitle = get_post_meta( $post->ID, '_asutsabo_subtitle', true );
	?>
	<div class="asutsabo-meta-box-wrap" style="padding: 6px 0;">
		<p style="margin: 0 0 8px 0;">
			<label for="asutsabo_subtitle" style="font-weight: 600; font-size: 13px; display: block; margin-bottom: 4px;">
				<?php esc_html_e( 'Post Subtitle / Summary', 'asutsabo' ); ?>
			</label>
			<span class="description" style="color: #646970; font-size: 12px; display: block; margin-bottom: 8px;">
				<?php esc_html_e( 'Optional. Leave empty if you do not want a subtitle displayed below the title.', 'asutsabo' ); ?>
			</span>
		</p>
		<textarea name="asutsabo_subtitle" id="asutsabo_subtitle" rows="3" class="large-text" style="width:100%; border: 1px solid #8c8f94; border-radius: 4px; padding: 8px; font-size: 14px; line-height: 1.5;" placeholder="<?php esc_attr_e( 'Enter an optional article subtitle or editorial lead summary...', 'asutsabo' ); ?>"><?php echo esc_textarea( $subtitle ); ?></textarea>
	</div>
	<?php
}

/**
 * Save the Post Subtitle / Summary meta box value.
 *
 * @param int $post_id Post ID.
 */
function asutsabo_save_subtitle_meta_box( $post_id ) {
	if ( ! isset( $_POST['asutsabo_subtitle_nonce'] ) ||
	     ! wp_verify_nonce( $_POST['asutsabo_subtitle_nonce'], 'asutsabo_subtitle_nonce_action' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( isset( $_POST['asutsabo_subtitle'] ) ) {
		$subtitle = wp_kses_post( wp_unslash( $_POST['asutsabo_subtitle'] ) );
		$trimmed  = trim( wp_strip_all_tags( $subtitle ) );
		if ( '' !== $trimmed ) {
			update_post_meta( $post_id, '_asutsabo_subtitle', $subtitle );
		} else {
			delete_post_meta( $post_id, '_asutsabo_subtitle' );
		}
	}
}
add_action( 'save_post', 'asutsabo_save_subtitle_meta_box' );

/**
 * Filter avatar data to support local author avatars.
 *
 * @param array $args        Avatar arguments.
 * @param mixed $id_or_email User ID, email, or object.
 * @return array
 */
function asutsabo_filter_avatar_data( $args, $id_or_email ) {
	$user_id = 0;
	if ( is_numeric( $id_or_email ) ) {
		$user_id = (int) $id_or_email;
	} elseif ( is_string( $id_or_email ) && is_email( $id_or_email ) ) {
		$user = get_user_by( 'email', $id_or_email );
		if ( $user ) {
			$user_id = $user->ID;
		}
	} elseif ( is_object( $id_or_email ) ) {
		if ( ! empty( $id_or_email->user_id ) ) {
			$user_id = (int) $id_or_email->user_id;
		} elseif ( ! empty( $id_or_email->ID ) ) {
			$user_id = (int) $id_or_email->ID;
		}
	}

	if ( $user_id > 0 ) {
		$custom_avatar = get_user_meta( $user_id, 'asutsabo_avatar_url', true );
		if ( ! empty( $custom_avatar ) ) {
			$args['url']          = esc_url( $custom_avatar );
			$args['found_avatar'] = true;
		}
	}

	return $args;
}
add_filter( 'pre_get_avatar_data', 'asutsabo_filter_avatar_data', 10, 2 );

/**
 * Register post meta for editorial enhancements: correction note, audio dispatch, and layout override.
 */
function asutsabo_register_editorial_enhancements_meta() {
	register_post_meta(
		'post',
		'_asutsabo_editorial_correction',
		array(
			'show_in_rest'      => true,
			'single'            => true,
			'type'              => 'string',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
			'sanitize_callback' => 'wp_kses_post',
		)
	);

	register_post_meta(
		'post',
		'_asutsabo_audio_url',
		array(
			'show_in_rest'      => true,
			'single'            => true,
			'type'              => 'string',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
			'sanitize_callback' => 'esc_url_raw',
		)
	);

	register_post_meta(
		'post',
		'_asutsabo_audio_duration',
		array(
			'show_in_rest'      => true,
			'single'            => true,
			'type'              => 'string',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	register_post_meta(
		'post',
		'_asutsabo_layout',
		array(
			'show_in_rest'      => true,
			'single'            => true,
			'type'              => 'string',
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
			'sanitize_callback' => 'sanitize_key',
		)
	);

	// Display settings meta for posts and pages (TOC, Title, Byline, Featured Image, etc.)
	$display_keys = array(
		'_asutsabo_enable_toc'          => 'string',
		'_asutsabo_hide_title'          => 'boolean',
		'_asutsabo_hide_featured_image' => 'boolean',
		'_asutsabo_hide_byline'         => 'boolean',
		'_asutsabo_hide_share'          => 'boolean',
		'_asutsabo_hide_author_bio'     => 'boolean',
		'_asutsabo_hide_related'        => 'boolean',
	);

	foreach ( array( 'post', 'page' ) as $type ) {
		foreach ( $display_keys as $key => $meta_type ) {
			register_post_meta(
				$type,
				$key,
				array(
					'show_in_rest'      => true,
					'single'            => true,
					'type'              => $meta_type,
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
					'sanitize_callback' => ( 'boolean' === $meta_type ) ? 'rest_sanitize_boolean' : 'sanitize_key',
				)
			);
		}
	}
}
add_action( 'init', 'asutsabo_register_editorial_enhancements_meta' );

/**
 * Add editorial enhancements meta boxes (Display Settings, Correction, Audio, Layout) to post/page edit screen.
 */
function asutsabo_add_editorial_enhancements_meta_boxes() {
	// Display & Content settings (TOC, Hide Title, Hide Byline, etc.)
	add_meta_box(
		'asutsabo_display_settings_box',
		__( 'Display & Content Settings', 'asutsabo' ),
		'asutsabo_render_display_settings_meta_box',
		array( 'post', 'page' ),
		'side',
		'default'
	);

	// Sidebar layout override
	add_meta_box(
		'asutsabo_layout_box',
		__( 'Layout & Sidebar', 'asutsabo' ),
		'asutsabo_render_layout_meta_box',
		array( 'post', 'page' ),
		'side',
		'default'
	);

	// Audio dispatch player (posts only)
	add_meta_box(
		'asutsabo_audio_box',
		__( 'Audio Dispatch / "Listen to Story"', 'asutsabo' ),
		'asutsabo_render_audio_meta_box',
		'post',
		'normal',
		'default'
	);

	// Editorial correction (posts only)
	add_meta_box(
		'asutsabo_correction_box',
		__( 'Editorial Correction / Clarification', 'asutsabo' ),
		'asutsabo_render_correction_meta_box',
		'post',
		'normal',
		'low'
	);
}
add_action( 'add_meta_boxes', 'asutsabo_add_editorial_enhancements_meta_boxes' );

/**
 * Render Display & Content Settings meta box (TOC, Hide Title, Hide Byline, etc.).
 *
 * @param WP_Post $post Current post or page object.
 */
function asutsabo_render_display_settings_meta_box( $post ) {
	wp_nonce_field( 'asutsabo_display_settings_nonce_action', 'asutsabo_display_settings_nonce' );

	$enable_toc    = get_post_meta( $post->ID, '_asutsabo_enable_toc', true );
	if ( empty( $enable_toc ) ) {
		$enable_toc = 'default';
	}
	$hide_title    = (bool) get_post_meta( $post->ID, '_asutsabo_hide_title', true );
	$hide_thumb    = (bool) get_post_meta( $post->ID, '_asutsabo_hide_featured_image', true );
	$hide_byline   = (bool) get_post_meta( $post->ID, '_asutsabo_hide_byline', true );
	$hide_share    = (bool) get_post_meta( $post->ID, '_asutsabo_hide_share', true );
	$hide_bio      = (bool) get_post_meta( $post->ID, '_asutsabo_hide_author_bio', true );
	$hide_related  = (bool) get_post_meta( $post->ID, '_asutsabo_hide_related', true );
	?>
	<div class="asutsabo-meta-box-wrap" style="padding:4px 0;">
		<!-- Table of Contents Toggle -->
		<p style="margin:0 0 12px 0;">
			<label for="asutsabo_enable_toc" style="font-weight:600;font-size:13px;display:block;margin-bottom:4px;">
				<?php esc_html_e( 'Table of Contents (TOC)', 'asutsabo' ); ?>
			</label>
			<select name="asutsabo_enable_toc" id="asutsabo_enable_toc" style="width:100%;">
				<option value="default" <?php selected( $enable_toc, 'default' ); ?>><?php esc_html_e( 'Theme Default (from Customizer)', 'asutsabo' ); ?></option>
				<option value="enable" <?php selected( $enable_toc, 'enable' ); ?>><?php esc_html_e( 'Always Enable TOC on this item', 'asutsabo' ); ?></option>
				<option value="disable" <?php selected( $enable_toc, 'disable' ); ?>><?php esc_html_e( 'Disable TOC on this item', 'asutsabo' ); ?></option>
			</select>
			<span class="description" style="font-size:11px;color:#646970;display:block;margin-top:2px;">
				<?php esc_html_e( 'Auto-parses H2/H3 headings when enabled.', 'asutsabo' ); ?>
			</span>
		</p>

		<hr style="border:0;border-top:1px solid #dcdcde;margin:10px 0;" />

		<!-- Title & Media Visibility -->
		<p style="margin:0 0 8px 0;">
			<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
				<input type="checkbox" name="asutsabo_hide_title" value="1" <?php checked( $hide_title, true ); ?> />
				<strong><?php esc_html_e( 'Hide Page / Post Title', 'asutsabo' ); ?></strong>
			</label>
			<span class="description" style="font-size:11px;color:#646970;display:block;margin-left:22px;">
				<?php esc_html_e( 'Suppresses the main headline on the page/post view.', 'asutsabo' ); ?>
			</span>
		</p>

		<p style="margin:0 0 8px 0;">
			<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
				<input type="checkbox" name="asutsabo_hide_featured_image" value="1" <?php checked( $hide_thumb, true ); ?> />
				<span><?php esc_html_e( 'Hide Featured Image at top', 'asutsabo' ); ?></span>
			</label>
		</p>

		<?php if ( 'post' === $post->post_type ) : ?>
			<hr style="border:0;border-top:1px solid #dcdcde;margin:10px 0;" />

			<p style="margin:0 0 8px 0;">
				<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
					<input type="checkbox" name="asutsabo_hide_byline" value="1" <?php checked( $hide_byline, true ); ?> />
					<span><?php esc_html_e( 'Hide Byline Bar (author, date, read time)', 'asutsabo' ); ?></span>
				</label>
			</p>

			<p style="margin:0 0 8px 0;">
				<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
					<input type="checkbox" name="asutsabo_hide_share" value="1" <?php checked( $hide_share, true ); ?> />
					<span><?php esc_html_e( 'Hide Social Share Buttons', 'asutsabo' ); ?></span>
				</label>
			</p>

			<p style="margin:0 0 8px 0;">
				<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
					<input type="checkbox" name="asutsabo_hide_author_bio" value="1" <?php checked( $hide_bio, true ); ?> />
					<span><?php esc_html_e( 'Hide Author Bio Card', 'asutsabo' ); ?></span>
				</label>
			</p>

			<p style="margin:0;">
				<label style="display:flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;">
					<input type="checkbox" name="asutsabo_hide_related" value="1" <?php checked( $hide_related, true ); ?> />
					<span><?php esc_html_e( 'Hide Related Coverage', 'asutsabo' ); ?></span>
				</label>
			</p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Render the Layout & Sidebar override meta box.
 *
 * @param WP_Post $post Current post or page object.
 */
function asutsabo_render_layout_meta_box( $post ) {
	wp_nonce_field( 'asutsabo_layout_nonce_action', 'asutsabo_layout_nonce' );
	$layout = get_post_meta( $post->ID, '_asutsabo_layout', true );
	if ( empty( $layout ) ) {
		$layout = 'default';
	}
	?>
	<p>
		<label for="asutsabo_layout" style="font-weight:600;font-size:13px;display:block;margin-bottom:4px;">
			<?php esc_html_e( 'Article Layout', 'asutsabo' ); ?>
		</label>
		<select name="asutsabo_layout" id="asutsabo_layout" style="width:100%;">
			<option value="default" <?php selected( $layout, 'default' ); ?>><?php esc_html_e( 'Theme Default (from Customizer)', 'asutsabo' ); ?></option>
			<option value="right-sidebar" <?php selected( $layout, 'right-sidebar' ); ?>><?php esc_html_e( 'Right Sidebar', 'asutsabo' ); ?></option>
			<option value="no-sidebar" <?php selected( $layout, 'no-sidebar' ); ?>><?php esc_html_e( 'No Sidebar (Centered)', 'asutsabo' ); ?></option>
		</select>
	</p>
	<p class="description" style="font-size:12px;color:#646970;">
		<?php esc_html_e( 'Override the default sidebar display for this specific post or page.', 'asutsabo' ); ?>
	</p>
	<?php
}

/**
 * Render the Audio Dispatch meta box.
 *
 * @param WP_Post $post Current post object.
 */
function asutsabo_render_audio_meta_box( $post ) {
	wp_nonce_field( 'asutsabo_audio_nonce_action', 'asutsabo_audio_nonce' );
	$audio_url      = get_post_meta( $post->ID, '_asutsabo_audio_url', true );
	$audio_duration = get_post_meta( $post->ID, '_asutsabo_audio_duration', true );
	?>
	<div class="asutsabo-meta-box-wrap" style="padding:6px 0;">
		<p style="margin:0 0 10px 0;">
			<label for="asutsabo_audio_url" style="font-weight:600;font-size:13px;display:block;margin-bottom:4px;">
				<?php esc_html_e( 'Audio File URL (MP3 / Podcast / Voice Dispatch)', 'asutsabo' ); ?>
			</label>
			<input type="url" name="asutsabo_audio_url" id="asutsabo_audio_url" value="<?php echo esc_url( $audio_url ); ?>" class="large-text" style="width:100%;" placeholder="https://example.com/audio/dispatch.mp3" />
			<span class="description" style="font-size:12px;color:#646970;">
				<?php esc_html_e( 'Displays an editorial "Listen to Article" player above the story.', 'asutsabo' ); ?>
			</span>
		</p>
		<p style="margin:0;">
			<label for="asutsabo_audio_duration" style="font-weight:600;font-size:13px;display:block;margin-bottom:4px;">
				<?php esc_html_e( 'Audio Duration (optional, e.g. "8 min" or "07:45")', 'asutsabo' ); ?>
			</label>
			<input type="text" name="asutsabo_audio_duration" id="asutsabo_audio_duration" value="<?php echo esc_attr( $audio_duration ); ?>" style="width:200px;" placeholder="8 min" />
		</p>
	</div>
	<?php
}

/**
 * Render the Editorial Correction meta box.
 *
 * @param WP_Post $post Current post object.
 */
function asutsabo_render_correction_meta_box( $post ) {
	wp_nonce_field( 'asutsabo_correction_nonce_action', 'asutsabo_correction_nonce' );
	$correction = get_post_meta( $post->ID, '_asutsabo_editorial_correction', true );
	?>
	<div class="asutsabo-meta-box-wrap" style="padding:6px 0;">
		<p style="margin:0 0 6px 0;">
			<label for="asutsabo_editorial_correction" style="font-weight:600;font-size:13px;display:block;margin-bottom:4px;">
				<?php esc_html_e( 'Correction or Clarification Note', 'asutsabo' ); ?>
			</label>
			<span class="description" style="font-size:12px;color:#646970;display:block;margin-bottom:6px;">
				<?php esc_html_e( 'Enter a notice regarding updates, post-publication corrections, or clarifications.', 'asutsabo' ); ?>
			</span>
		</p>
		<textarea name="asutsabo_editorial_correction" id="asutsabo_editorial_correction" rows="3" class="large-text" style="width:100%;" placeholder="<?php esc_attr_e( 'Correction (Oct 12, 2026): An earlier version of this report misstated...', 'asutsabo' ); ?>"><?php echo esc_textarea( $correction ); ?></textarea>
	</div>
	<?php
}

/**
 * Save additional editorial enhancements post meta.
 *
 * @param int $post_id Post ID.
 */
function asutsabo_save_editorial_enhancements_meta( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// Display Settings (TOC, Title, Featured Image, Byline, Share, Bio, Related)
	if ( isset( $_POST['asutsabo_display_settings_nonce'] ) && wp_verify_nonce( $_POST['asutsabo_display_settings_nonce'], 'asutsabo_display_settings_nonce_action' ) ) {
		if ( isset( $_POST['asutsabo_enable_toc'] ) ) {
			$toc_val = sanitize_key( $_POST['asutsabo_enable_toc'] );
			if ( in_array( $toc_val, array( 'default', 'enable', 'disable' ), true ) ) {
				update_post_meta( $post_id, '_asutsabo_enable_toc', $toc_val );
			}
		}

		$checkbox_keys = array(
			'asutsabo_hide_title'          => '_asutsabo_hide_title',
			'asutsabo_hide_featured_image' => '_asutsabo_hide_featured_image',
			'asutsabo_hide_byline'         => '_asutsabo_hide_byline',
			'asutsabo_hide_share'          => '_asutsabo_hide_share',
			'asutsabo_hide_author_bio'     => '_asutsabo_hide_author_bio',
			'asutsabo_hide_related'        => '_asutsabo_hide_related',
		);

		foreach ( $checkbox_keys as $post_key => $meta_key ) {
			if ( ! empty( $_POST[ $post_key ] ) ) {
				update_post_meta( $post_id, $meta_key, 1 );
			} else {
				delete_post_meta( $post_id, $meta_key );
			}
		}
	}

	// Layout
	if ( isset( $_POST['asutsabo_layout_nonce'] ) && wp_verify_nonce( $_POST['asutsabo_layout_nonce'], 'asutsabo_layout_nonce_action' ) ) {
		if ( isset( $_POST['asutsabo_layout'] ) ) {
			$layout = sanitize_key( $_POST['asutsabo_layout'] );
			if ( in_array( $layout, array( 'default', 'right-sidebar', 'no-sidebar' ), true ) ) {
				update_post_meta( $post_id, '_asutsabo_layout', $layout );
			}
		}
	}

	// Audio
	if ( isset( $_POST['asutsabo_audio_nonce'] ) && wp_verify_nonce( $_POST['asutsabo_audio_nonce'], 'asutsabo_audio_nonce_action' ) ) {
		if ( isset( $_POST['asutsabo_audio_url'] ) ) {
			$audio_url = esc_url_raw( trim( $_POST['asutsabo_audio_url'] ) );
			if ( ! empty( $audio_url ) ) {
				update_post_meta( $post_id, '_asutsabo_audio_url', $audio_url );
			} else {
				delete_post_meta( $post_id, '_asutsabo_audio_url' );
			}
		}
		if ( isset( $_POST['asutsabo_audio_duration'] ) ) {
			$duration = sanitize_text_field( trim( $_POST['asutsabo_audio_duration'] ) );
			if ( ! empty( $duration ) ) {
				update_post_meta( $post_id, '_asutsabo_audio_duration', $duration );
			} else {
				delete_post_meta( $post_id, '_asutsabo_audio_duration' );
			}
		}
	}

	// Correction
	if ( isset( $_POST['asutsabo_correction_nonce'] ) && wp_verify_nonce( $_POST['asutsabo_correction_nonce'], 'asutsabo_correction_nonce_action' ) ) {
		if ( isset( $_POST['asutsabo_editorial_correction'] ) ) {
			$correction = wp_kses_post( wp_unslash( $_POST['asutsabo_editorial_correction'] ) );
			if ( '' !== trim( wp_strip_all_tags( $correction ) ) ) {
				update_post_meta( $post_id, '_asutsabo_editorial_correction', $correction );
			} else {
				delete_post_meta( $post_id, '_asutsabo_editorial_correction' );
			}
		}
	}
}
add_action( 'save_post', 'asutsabo_save_editorial_enhancements_meta' );

/**
 * Add custom contact methods and editorial staff fields to user profile.
 *
 * @param array $methods Existing contact methods.
 * @return array
 */
function asutsabo_user_contactmethods( $methods ) {
	$methods['asutsabo_job_title'] = __( 'Editorial Role / Beat (e.g. Senior Foreign Correspondent)', 'asutsabo' );
	$methods['asutsabo_twitter']   = __( 'X (Twitter) Profile URL or @handle', 'asutsabo' );
	$methods['asutsabo_linkedin']  = __( 'LinkedIn Profile URL', 'asutsabo' );
	$methods['asutsabo_bluesky']   = __( 'Bluesky Profile URL or @handle', 'asutsabo' );
	return $methods;
}
add_filter( 'user_contactmethods', 'asutsabo_user_contactmethods' );

