<?php
/**
 * Asutsabo Block Style Variations.
 *
 * Registers native block styles for editorial publishing.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register custom block style variations.
 */
function asutsabo_register_block_styles() {
	// Kicker for Paragraphs.
	register_block_style(
		'core/paragraph',
		array(
			'name'  => 'asutsabo-kicker',
			'label' => __( 'Kicker', 'asutsabo' ),
		)
	);

	// Section Label for Headings.
	register_block_style(
		'core/heading',
		array(
			'name'  => 'asutsabo-section-label',
			'label' => __( 'Section Label', 'asutsabo' ),
		)
	);

	// Byline for Paragraphs.
	register_block_style(
		'core/paragraph',
		array(
			'name'  => 'asutsabo-byline',
			'label' => __( 'Byline', 'asutsabo' ),
		)
	);

	// Metadata for Paragraphs.
	register_block_style(
		'core/paragraph',
		array(
			'name'  => 'asutsabo-metadata',
			'label' => __( 'Metadata', 'asutsabo' ),
		)
	);

	// Featured Headline for Headings.
	register_block_style(
		'core/heading',
		array(
			'name'  => 'asutsabo-featured-headline',
			'label' => __( 'Featured Headline', 'asutsabo' ),
		)
	);

	// Editorial Image with thin border and caption styling.
	register_block_style(
		'core/image',
		array(
			'name'  => 'asutsabo-editorial-image',
			'label' => __( 'Editorial Image', 'asutsabo' ),
		)
	);

	// Editorial Pull Quote.
	register_block_style(
		'core/pullquote',
		array(
			'name'  => 'asutsabo-editorial-pullquote',
			'label' => __( 'Editorial Pull Quote', 'asutsabo' ),
		)
	);

	// Editorial Caption for Paragraphs.
	register_block_style(
		'core/paragraph',
		array(
			'name'  => 'asutsabo-caption',
			'label' => __( 'Editorial Caption', 'asutsabo' ),
		)
	);

	// Thick Divider for Separator.
	register_block_style(
		'core/separator',
		array(
			'name'  => 'asutsabo-divider-thick',
			'label' => __( 'Thick Rule', 'asutsabo' ),
		)
	);

	// Double Divider for Separator.
	register_block_style(
		'core/separator',
		array(
			'name'  => 'asutsabo-divider-double',
			'label' => __( 'Double Rule', 'asutsabo' ),
		)
	);
}
add_action( 'init', 'asutsabo_register_block_styles' );
