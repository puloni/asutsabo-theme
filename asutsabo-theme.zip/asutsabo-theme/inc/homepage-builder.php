<?php
/**
 * Asutsabo Homepage Builder & Section Management.
 *
 * Provides a dedicated, responsive admin screen under Appearance -> Homepage Builder
 * to reorder, configure, enable/disable, and edit all homepage magazine sections.
 * Ensures section titles are 100% independent of category sources.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns available layout choices for homepage sections.
 *
 * @return array Layout key => display name.
 */
function asutsabo_get_available_layouts() {
	return array(
		'feature-list'     => __( 'Featured + List (Lead Card + Side Story List)', 'asutsabo' ),
		'feature-slider'   => __( 'Carousel / Featured Slider', 'asutsabo' ),
		'cards-2'          => __( '2-Column Grid (Cards)', 'asutsabo' ),
		'grid-3'           => __( '3-Column Editorial Grid', 'asutsabo' ),
		'grid-4'           => __( '4-Column Card Grid', 'asutsabo' ),
		'grid'             => __( 'Custom Grid (Configurable Columns)', 'asutsabo' ),
		'list'             => __( 'List (Compact List with Thumbnails)', 'asutsabo' ),
		'wire-ticker'      => __( 'Compact Headline List / Fast Wire', 'asutsabo' ),
		'horizontal-cards' => __( 'Horizontal Cards', 'asutsabo' ),
		'vertical-cards'   => __( 'Vertical Cards', 'asutsabo' ),
		'magazine'         => __( 'Magazine Layout (Lead Feature + Stories Grid)', 'asutsabo' ),
		'split-column'     => __( 'Desk Column (Half Width / Paired)', 'asutsabo' ),
		'hero-dispatches'  => __( 'Hero Lead + Top Dispatches', 'asutsabo' ),
		'opinion-columns'  => __( 'Opinion Columnists Grid', 'asutsabo' ),
		'video-showcase'   => __( 'Multimedia & Video Showcase', 'asutsabo' ),
		'trending'         => __( 'Trending / Most Read Stories', 'asutsabo' ),
		'briefing'         => __( 'Editorial Briefing / Newsletter Box', 'asutsabo' ),
		'ad-banner'        => __( 'Advertisement Leaderboard Banner', 'asutsabo' ),
	);
}

/**
 * Returns default configuration of homepage sections.
 * Bridges seamlessly with any existing theme_mods.
 *
 * @return array Default section definitions.
 */
function asutsabo_get_default_homepage_sections() {
	$site_name = get_bloginfo( 'name' );
	$default_briefing_desc = sprintf(
		/* translators: %s: site name */
		__( 'Subscribe to receive %s\'s independent reporting, investigative dispatches, and cultural critique directly in your inbox.', 'asutsabo' ),
		esc_html( $site_name )
	);

	return array(
		// 1. Latest News (Zunheboto)
		'latest_news' => array(
			'id'                  => 'latest_news',
			'type'                => 'desk',
			'title'               => __( 'Latest News', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'latest-news',
			'categories'          => array( 'latest-news' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 3,
			'layout'              => 'feature-list',
			'enabled'             => true,
			'order'               => 1,
			'badge'               => 'ZUNHEBOTO',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Featured story with category badge & headline overlay + 2 compact side stories.', 'asutsabo' ),
		),
		// 2. Nagaland
		'nagaland' => array(
			'id'                  => 'nagaland',
			'type'                => 'desk',
			'title'               => __( 'Nagaland', 'asutsabo' ),
			'show_title'          => true,
			'description'         => __( 'Stories, people, places and developments from across Nagaland.', 'asutsabo' ),
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'nagaland',
			'categories'          => array( 'nagaland' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 5,
			'layout'              => 'feature-list',
			'enabled'             => true,
			'order'               => 2,
			'badge'               => 'NAGALAND',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Featured story with headline overlay + 4 stories list with dividers.', 'asutsabo' ),
		),
		// 3. India
		'india' => array(
			'id'                  => 'india',
			'type'                => 'desk',
			'title'               => __( 'India', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'india',
			'categories'          => array( 'india' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 4,
			'layout'              => 'list',
			'enabled'             => true,
			'order'               => 3,
			'badge'               => '',
			'show_badge'          => false,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Compact 4-story list with thumbnails and divider lines.', 'asutsabo' ),
		),
		// 4. Sports
		'sports' => array(
			'id'                  => 'sports',
			'type'                => 'desk',
			'title'               => __( 'Sports', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'sports',
			'categories'          => array( 'sports' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 4,
			'layout'              => 'cards-2',
			'enabled'             => true,
			'order'               => 4,
			'badge'               => '',
			'show_badge'          => false,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( '2-column story cards grid with top photography.', 'asutsabo' ),
		),
		// 5. Entertainment
		'entertainment' => array(
			'id'                  => 'entertainment',
			'type'                => 'desk',
			'title'               => __( 'Entertainment', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'entertainment',
			'categories'          => array( 'entertainment' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 6,
			'layout'              => 'feature-slider',
			'enabled'             => true,
			'order'               => 5,
			'badge'               => 'ENTERTAINMENT',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Featured slider carousel card with navigation controls + side stories list.', 'asutsabo' ),
		),
		// 6. Politics
		'politics' => array(
			'id'                  => 'politics',
			'type'                => 'desk',
			'title'               => __( 'Politics', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'politics',
			'categories'          => array( 'politics' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 4,
			'layout'              => 'feature-list',
			'enabled'             => true,
			'order'               => 6,
			'badge'               => 'POLITICS',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Featured story with category pill & headline overlay + 3 side stories list.', 'asutsabo' ),
		),
		// 7. Science & Tech
		'technology' => array(
			'id'                  => 'technology',
			'type'                => 'desk',
			'title'               => __( 'Science & Tech', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'technology',
			'categories'          => array( 'technology' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 4,
			'layout'              => 'feature-list',
			'enabled'             => true,
			'order'               => 7,
			'badge'               => 'SCIENCE & TECH',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Featured story with category pill & headline overlay + 3 side stories list.', 'asutsabo' ),
		),
		// Secondary available sections
		'fast_wire' => array(
			'id'                  => 'fast_wire',
			'type'                => 'wire',
			'title'               => get_theme_mod( 'asutsabo_fast_wire_title', __( 'Fast Wire', 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => false,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'latest',
			'category'            => get_theme_mod( 'asutsabo_fast_wire_category', '' ),
			'categories'          => array(),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_fast_wire_count', 6 ) ),
			'layout'              => 'wire-ticker',
			'enabled'             => false,
			'order'               => 8,
			'badge'               => '',
			'show_badge'          => false,
			'show_date'           => true,
			'show_author'         => false,
			'show_excerpt'        => false,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Fast Wire ticker bar with timestamps and breaking dispatches.', 'asutsabo' ),
		),
		'hero' => array(
			'id'                  => 'hero',
			'type'                => 'hero',
			'title'               => get_theme_mod( 'asutsabo_top_dispatches_title', __( 'Top Dispatches', 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => false,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'latest',
			'category'            => get_theme_mod( 'asutsabo_top_dispatches_category', '' ),
			'categories'          => array(),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_top_dispatches_count', 3 ) ),
			'layout'              => 'hero-dispatches',
			'enabled'             => false,
			'order'               => 9,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Lead hero story on left with secondary top dispatches list on right.', 'asutsabo' ),
		),
		'editors_picks' => array(
			'id'                  => 'editors_picks',
			'type'                => 'picks',
			'title'               => get_theme_mod( 'asutsabo_editors_picks_title', __( "Editor's Picks", 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => get_theme_mod( 'asutsabo_editors_picks_category', 'editors-picks' ),
			'categories'          => array( 'editors-picks' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_editors_picks_count', 3 ) ),
			'layout'              => 'grid-3',
			'enabled'             => false,
			'order'               => 10,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 3,
			'aspect_ratio'        => '3-2',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Showcases hand-picked editorial articles or category features.', 'asutsabo' ),
		),
		'national' => array(
			'id'                  => 'national',
			'type'                => 'desk',
			'title'               => get_theme_mod( 'asutsabo_national_title', __( 'National', 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => get_theme_mod( 'asutsabo_national_category', 'national' ),
			'categories'          => array( 'national' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_national_count', 2 ) ),
			'layout'              => 'split-column',
			'enabled'             => false,
			'order'               => 11,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'National news desk stories with featured photography.', 'asutsabo' ),
		),
		'world' => array(
			'id'                  => 'world',
			'type'                => 'desk',
			'title'               => get_theme_mod( 'asutsabo_world_title', __( 'World', 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => get_theme_mod( 'asutsabo_world_category', 'world' ),
			'categories'          => array( 'world' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_world_count', 2 ) ),
			'layout'              => 'split-column',
			'enabled'             => false,
			'order'               => 12,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Global affairs and international dispatches.', 'asutsabo' ),
		),
		'business' => array(
			'id'                  => 'business',
			'type'                => 'desk',
			'title'               => get_theme_mod( 'asutsabo_business_title', __( 'Business', 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => get_theme_mod( 'asutsabo_business_category', 'business' ),
			'categories'          => array( 'business' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_business_count', 2 ) ),
			'layout'              => 'split-column',
			'enabled'             => false,
			'order'               => 13,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Finance, markets, and economic developments.', 'asutsabo' ),
		),
		'ad_banner' => array(
			'id'                  => 'ad_banner',
			'type'                => 'ad',
			'title'               => __( 'Advertisement Leaderboard', 'asutsabo' ),
			'show_title'          => false,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => false,
			'view_all_text'       => '',
			'view_all_url'        => '',
			'source'              => 'ad',
			'category'            => '',
			'categories'          => array(),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 0,
			'layout'              => 'ad-banner',
			'enabled'             => false,
			'order'               => 14,
			'badge'               => '',
			'show_badge'          => false,
			'show_date'           => false,
			'show_author'         => false,
			'show_excerpt'        => false,
			'columns'             => 1,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'ad_code'             => '',
			'description_info'    => __( 'Responsive 970x90 / 728x90 leaderboard ad placement.', 'asutsabo' ),
		),
		'culture' => array(
			'id'                  => 'culture',
			'type'                => 'desk',
			'title'               => get_theme_mod( 'asutsabo_culture_title', __( 'Culture', 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => get_theme_mod( 'asutsabo_culture_category', 'culture' ),
			'categories'          => array( 'culture' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_culture_count', 2 ) ),
			'layout'              => 'split-column',
			'enabled'             => false,
			'order'               => 15,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Arts, literature, philosophy, and social critique.', 'asutsabo' ),
		),
		'lifestyle' => array(
			'id'                  => 'lifestyle',
			'type'                => 'desk',
			'title'               => get_theme_mod( 'asutsabo_lifestyle_title', __( 'Lifestyle', 'asutsabo' ) ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => get_theme_mod( 'asutsabo_lifestyle_category', 'lifestyle' ),
			'categories'          => array( 'lifestyle' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => absint( get_theme_mod( 'asutsabo_lifestyle_count', 2 ) ),
			'layout'              => 'split-column',
			'enabled'             => false,
			'order'               => 16,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 2,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Living, travel, design, wellness, and dining.', 'asutsabo' ),
		),
		'opinion' => array(
			'id'                  => 'opinion',
			'type'                => 'opinion',
			'title'               => __( 'Opinion • The Columnists', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'category',
			'category'            => 'opinion',
			'categories'          => array( 'opinion' ),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 3,
			'layout'              => 'opinion-columns',
			'enabled'             => false,
			'order'               => 17,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 3,
			'aspect_ratio'        => '16-9',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( 'Columnist columns with author avatars and editorial commentary.', 'asutsabo' ),
		),
		'more_news' => array(
			'id'                  => 'more_news',
			'type'                => 'archive',
			'title'               => __( 'More News & In-Depth Reporting', 'asutsabo' ),
			'show_title'          => true,
			'description'         => '',
			'show_desc'           => false,
			'show_view_all'       => true,
			'view_all_text'       => __( 'View all', 'asutsabo' ),
			'view_all_url'        => '',
			'source'              => 'latest',
			'category'            => '',
			'categories'          => array(),
			'tags'                => '',
			'manual_ids'          => '',
			'count'               => 6,
			'layout'              => 'grid-3',
			'enabled'             => false,
			'order'               => 18,
			'badge'               => '',
			'show_badge'          => true,
			'show_date'           => true,
			'show_author'         => true,
			'show_excerpt'        => true,
			'columns'             => 3,
			'aspect_ratio'        => '3-2',
			'carousel_autoplay'   => false,
			'carousel_speed'      => 4000,
			'carousel_arrows'     => true,
			'carousel_dots'       => true,
			'carousel_visible'    => 1,
			'description_info'    => __( '3-column archive card grid for comprehensive news coverage.', 'asutsabo' ),
		),
		'briefing' => array(
			'id'                    => 'briefing',
			'type'                  => 'cta',
			'title'                 => __( 'The Daily Intelligence / Join Free Briefing', 'asutsabo' ),
			'show_title'            => true,
			'description'           => '',
			'show_desc'             => false,
			'show_view_all'         => false,
			'view_all_text'         => '',
			'view_all_url'          => '',
			'source'                => 'cta',
			'category'              => '',
			'categories'            => array(),
			'tags'                  => '',
			'manual_ids'            => '',
			'count'                 => 0,
			'layout'                => 'briefing',
			'enabled'               => false,
			'order'                 => 19,
			'badge'                 => '',
			'show_badge'            => false,
			'show_date'             => false,
			'show_author'           => false,
			'show_excerpt'          => false,
			'columns'               => 1,
			'aspect_ratio'          => '16-9',
			'carousel_autoplay'     => false,
			'carousel_speed'        => 4000,
			'carousel_arrows'       => true,
			'carousel_dots'         => true,
			'carousel_visible'      => 1,
			'newsletter_eyebrow'    => get_theme_mod( 'asutsabo_newsletter_eyebrow', 'THE DAILY INTELLIGENCE' ),
			'newsletter_headline'   => get_theme_mod( 'asutsabo_newsletter_headline', __( 'Essential journalism, direct to your inbox.', 'asutsabo' ) ),
			'newsletter_desc'       => get_theme_mod( 'asutsabo_newsletter_description', $default_briefing_desc ),
			'newsletter_btn_text'   => get_theme_mod( 'asutsabo_newsletter_button_text', __( 'Join Free Briefing', 'asutsabo' ) ),
			'newsletter_btn_url'    => get_theme_mod( 'asutsabo_newsletter_button_url', '#subscribe' ),
			'newsletter_disclaimer' => get_theme_mod( 'asutsabo_newsletter_disclaimer', 'NO SPAM. ONE-CLICK UNSUBSCRIBE AT ANY TIME.' ),
			'description_info'      => __( 'Full-width newsletter subscription callout box.', 'asutsabo' ),
		),
	);
}

/**
 * Retrieves the homepage sections sorted by order.
 *
 * @return array List of sections sorted by order index.
 */
function asutsabo_get_homepage_sections() {
	$saved = get_option( 'asutsabo_homepage_sections' );
	$defaults = asutsabo_get_default_homepage_sections();

	if ( ! is_array( $saved ) || empty( $saved ) ) {
		$sections = $defaults;
	} else {
		$sections = array();
		foreach ( $saved as $id => $data ) {
			if ( isset( $defaults[ $id ] ) ) {
				$sections[ $id ] = wp_parse_args( $data, $defaults[ $id ] );
			} else {
				$sections[ $id ] = $data;
			}
		}
	}

	// Sort sections by their 'order' index.
	uasort(
		$sections,
		function ( $a, $b ) {
			$order_a = isset( $a['order'] ) ? (int) $a['order'] : 999;
			$order_b = isset( $b['order'] ) ? (int) $b['order'] : 999;
			if ( $order_a === $order_b ) {
				return 0;
			}
			return ( $order_a < $order_b ) ? -1 : 1;
		}
	);

	return $sections;
}

/**
 * Returns default items for Footer Column 2 (Sections Menu).
 *
 * @return array
 */
function asutsabo_get_default_sections_menu_items() {
	return array(
		array(
			'title'  => __( 'Business', 'asutsabo' ),
			'url'    => home_url( '/category/business/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Culture', 'asutsabo' ),
			'url'    => home_url( '/category/culture/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( "Editor's Picks", 'asutsabo' ),
			'url'    => home_url( '/category/editors-picks/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Entertainment', 'asutsabo' ),
			'url'    => home_url( '/category/entertainment/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Lifestyle', 'asutsabo' ),
			'url'    => home_url( '/category/lifestyle/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'National', 'asutsabo' ),
			'url'    => home_url( '/category/national/' ),
			'hidden' => false,
		),
	);
}

/**
 * Retrieves the Sections Menu items.
 *
 * @return array
 */
function asutsabo_get_sections_menu_items() {
	$saved = get_option( 'asutsabo_sections_menu_items' );
	if ( ! is_array( $saved ) || empty( $saved ) ) {
		return asutsabo_get_default_sections_menu_items();
	}
	return $saved;
}

/**
 * Returns default items for Footer Column 3 (Standards Menu).
 *
 * @return array
 */
function asutsabo_get_default_standards_menu_items() {
	return array(
		array(
			'title'  => __( 'About Unheard', 'asutsabo' ),
			'url'    => home_url( '/about/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Advertise With Unheard', 'asutsabo' ),
			'url'    => home_url( '/advertise/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Contact the Newsroom', 'asutsabo' ),
			'url'    => home_url( '/contact/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Corrections Policy & Public Record', 'asutsabo' ),
			'url'    => home_url( '/corrections/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Editorial Disclaimer', 'asutsabo' ),
			'url'    => home_url( '/disclaimer/' ),
			'hidden' => false,
		),
		array(
			'title'  => __( 'Editorial Standards & Code of Ethics', 'asutsabo' ),
			'url'    => home_url( '/editorial-standards/' ),
			'hidden' => false,
		),
	);
}

/**
 * Retrieves the Standards Menu items.
 *
 * @return array
 */
function asutsabo_get_standards_menu_items() {
	$saved = get_option( 'asutsabo_standards_menu_items' );
	if ( ! is_array( $saved ) || empty( $saved ) ) {
		return asutsabo_get_default_standards_menu_items();
	}
	return $saved;
}

/**
 * Sanitize homepage sections array or JSON string.
 *
 * @param mixed $input JSON string or array of sections.
 * @return array Sanitized sections.
 */
function asutsabo_sanitize_homepage_sections_data( $input ) {
	if ( is_string( $input ) ) {
		$decoded = json_decode( wp_unslash( $input ), true );
		if ( is_array( $decoded ) ) {
			$input = $decoded;
		}
	}

	if ( ! is_array( $input ) ) {
		return asutsabo_get_default_homepage_sections();
	}

	$sanitized = array();
	$order = 1;

	foreach ( $input as $key => $sec ) {
		if ( ! is_array( $sec ) ) {
			continue;
		}

		$id = ! empty( $sec['id'] ) ? sanitize_key( $sec['id'] ) : 'section_' . $order;

		$sanitized[ $id ] = array(
			'id'                  => $id,
			'type'                => ! empty( $sec['type'] ) ? sanitize_key( $sec['type'] ) : 'desk',
			'title'               => isset( $sec['title'] ) ? sanitize_text_field( $sec['title'] ) : '',
			'show_title'          => isset( $sec['show_title'] ) ? (bool) $sec['show_title'] : true,
			'description'         => isset( $sec['description'] ) ? sanitize_textarea_field( $sec['description'] ) : '',
			'show_desc'           => ! empty( $sec['show_desc'] ),
			'show_view_all'       => isset( $sec['show_view_all'] ) ? (bool) $sec['show_view_all'] : true,
			'view_all_text'       => ! empty( $sec['view_all_text'] ) ? sanitize_text_field( $sec['view_all_text'] ) : __( 'View all', 'asutsabo' ),
			'view_all_url'        => ! empty( $sec['view_all_url'] ) ? esc_url_raw( $sec['view_all_url'] ) : '',
			'source'              => ! empty( $sec['source'] ) ? sanitize_key( $sec['source'] ) : 'category',
			'category'            => ! empty( $sec['category'] ) ? sanitize_title( $sec['category'] ) : '',
			'categories'          => ! empty( $sec['categories'] ) ? ( is_array( $sec['categories'] ) ? array_map( 'sanitize_title', $sec['categories'] ) : sanitize_text_field( $sec['categories'] ) ) : '',
			'tags'                => ! empty( $sec['tags'] ) ? sanitize_text_field( $sec['tags'] ) : '',
			'manual_ids'          => ! empty( $sec['manual_ids'] ) ? sanitize_text_field( $sec['manual_ids'] ) : '',
			'count'               => isset( $sec['count'] ) ? absint( $sec['count'] ) : 4,
			'layout'              => ! empty( $sec['layout'] ) ? sanitize_key( $sec['layout'] ) : 'feature-list',
			'enabled'             => isset( $sec['enabled'] ) ? (bool) $sec['enabled'] : true,
			'order'               => isset( $sec['order'] ) ? (int) $sec['order'] : $order,
			'badge'               => isset( $sec['badge'] ) ? sanitize_text_field( $sec['badge'] ) : '',
			'show_badge'          => isset( $sec['show_badge'] ) ? (bool) $sec['show_badge'] : true,
			'show_date'           => isset( $sec['show_date'] ) ? (bool) $sec['show_date'] : true,
			'show_author'         => isset( $sec['show_author'] ) ? (bool) $sec['show_author'] : true,
			'show_excerpt'        => isset( $sec['show_excerpt'] ) ? (bool) $sec['show_excerpt'] : true,
			'columns'             => isset( $sec['columns'] ) ? absint( $sec['columns'] ) : 2,
			'aspect_ratio'        => ! empty( $sec['aspect_ratio'] ) ? sanitize_key( $sec['aspect_ratio'] ) : '16-9',
			'carousel_autoplay'   => ! empty( $sec['carousel_autoplay'] ),
			'carousel_speed'      => isset( $sec['carousel_speed'] ) ? absint( $sec['carousel_speed'] ) : 4000,
			'carousel_arrows'     => isset( $sec['carousel_arrows'] ) ? (bool) $sec['carousel_arrows'] : true,
			'carousel_dots'       => isset( $sec['carousel_dots'] ) ? (bool) $sec['carousel_dots'] : true,
			'carousel_visible'    => isset( $sec['carousel_visible'] ) ? absint( $sec['carousel_visible'] ) : 1,
			'ad_code'             => isset( $sec['ad_code'] ) ? wp_kses_post( $sec['ad_code'] ) : '',
			'newsletter_eyebrow'  => isset( $sec['newsletter_eyebrow'] ) ? sanitize_text_field( $sec['newsletter_eyebrow'] ) : '',
			'newsletter_headline' => isset( $sec['newsletter_headline'] ) ? sanitize_text_field( $sec['newsletter_headline'] ) : '',
			'newsletter_desc'     => isset( $sec['newsletter_desc'] ) ? sanitize_textarea_field( $sec['newsletter_desc'] ) : '',
			'newsletter_btn_text' => isset( $sec['newsletter_btn_text'] ) ? sanitize_text_field( $sec['newsletter_btn_text'] ) : '',
			'newsletter_btn_url'  => isset( $sec['newsletter_btn_url'] ) ? esc_url_raw( $sec['newsletter_btn_url'] ) : '',
		);
		$order++;
	}

	return $sanitized;
}

/**
 * Sanitize navigation list data (for Sections and Standards menus).
 *
 * @param mixed $input Array or JSON string of items.
 * @return array Sanitized list of items.
 */
function asutsabo_sanitize_nav_list_data( $input ) {
	if ( is_string( $input ) ) {
		$decoded = json_decode( wp_unslash( $input ), true );
		if ( is_array( $decoded ) ) {
			$input = $decoded;
		}
	}

	if ( ! is_array( $input ) ) {
		return array();
	}

	$sanitized = array();
	foreach ( $input as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}
		$sanitized[] = array(
			'title'  => isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '',
			'url'    => isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '',
			'hidden' => ! empty( $item['hidden'] ),
		);
	}

	return $sanitized;
}

/**
 * Register Appearance -> Homepage Builder admin menu.
 */
function asutsabo_register_homepage_builder_menu() {
	add_theme_page(
		__( 'Homepage Builder', 'asutsabo' ),
		__( 'Homepage Builder', 'asutsabo' ),
		'edit_theme_options',
		'asutsabo-homepage-builder',
		'asutsabo_render_homepage_builder_page'
	);
}
add_action( 'admin_menu', 'asutsabo_register_homepage_builder_menu' );

/**
 * Enqueue scripts and styles for Homepage Builder admin page.
 *
 * @param string $hook Admin page hook suffix.
 */
function asutsabo_homepage_builder_admin_assets( $hook ) {
	if ( 'appearance_page_asutsabo-homepage-builder' !== $hook ) {
		return;
	}

	wp_enqueue_script( 'jquery-ui-sortable' );

	$custom_css = '
		.asutsabo-hb-wrap { max-width: 1200px; margin: 20px 20px 40px 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; }
		.asutsabo-hb-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #c3c4c7; }
		.asutsabo-hb-header h1 { margin: 0; font-size: 24px; font-weight: 700; color: #1d2327; }
		.asutsabo-hb-header p { margin: 4px 0 0 0; color: #50575e; font-size: 13px; }
		.asutsabo-hb-actions { display: flex; gap: 10px; align-items: center; }
		.asutsabo-hb-list { list-style: none; margin: 0; padding: 0; }
		.asutsabo-hb-card { background: #fff; border: 1px solid #c3c4c7; border-radius: 4px; margin-bottom: 15px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); transition: border-color 0.15s ease, box-shadow 0.15s ease; }
		.asutsabo-hb-card.is-disabled { opacity: 0.65; background: #f6f7f7; }
		.asutsabo-hb-card.ui-sortable-helper { box-shadow: 0 8px 20px rgba(0,0,0,0.15); border-color: #2271b1; }
		.asutsabo-hb-card-header { display: flex; align-items: center; justify-content: space-between; padding: 12px 18px; background: #f8f9fa; border-bottom: 1px solid #e2e4e7; border-radius: 3px 3px 0 0; cursor: move; }
		.asutsabo-hb-card-title-group { display: flex; align-items: center; gap: 12px; }
		.asutsabo-hb-drag-handle { color: #8c8f94; font-size: 18px; line-height: 1; cursor: grab; user-select: none; }
		.asutsabo-hb-order-badge { background: #2271b1; color: #fff; font-weight: 700; font-size: 11px; padding: 2px 8px; border-radius: 12px; }
		.asutsabo-hb-card-name { font-weight: 600; font-size: 14px; color: #1d2327; margin: 0; }
		.asutsabo-hb-card-type { font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; background: #e0e0e0; color: #444; padding: 2px 6px; border-radius: 3px; font-weight: 600; }
		.asutsabo-hb-card-toggle { display: flex; align-items: center; gap: 10px; }
		.asutsabo-hb-order-btns { display: flex; gap: 4px; }
		.asutsabo-hb-order-btn { background: #fff; border: 1px solid #c3c4c7; border-radius: 3px; cursor: pointer; padding: 3px 8px; font-size: 11px; line-height: 1; color: #50575e; }
		.asutsabo-hb-order-btn:hover { background: #f0f0f1; color: #1d2327; border-color: #8c8f94; }
		.asutsabo-hb-card-body { padding: 18px; }
		.asutsabo-hb-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
		@media (max-width: 820px) { .asutsabo-hb-grid { grid-template-columns: 1fr; } }
		.asutsabo-hb-panel { background: #fcfcfc; border: 1px solid #e2e4e7; border-radius: 4px; padding: 14px 16px; }
		.asutsabo-hb-panel-title { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #2271b1; margin: 0 0 12px 0; padding-bottom: 6px; border-bottom: 1px solid #eee; }
		.asutsabo-hb-field { margin-bottom: 12px; }
		.asutsabo-hb-field:last-child { margin-bottom: 0; }
		.asutsabo-hb-field label { display: block; font-weight: 600; font-size: 12px; margin-bottom: 4px; color: #1d2327; }
		.asutsabo-hb-field .description { display: block; font-size: 11px; color: #646970; margin-top: 3px; }
		.asutsabo-hb-field input[type="text"], .asutsabo-hb-field input[type="number"], .asutsabo-hb-field select, .asutsabo-hb-field textarea { width: 100%; border: 1px solid #8c8f94; border-radius: 3px; padding: 6px 8px; font-size: 13px; box-sizing: border-box; }
		.asutsabo-hb-field input[type="text"]:focus, .asutsabo-hb-field input[type="number"]:focus, .asutsabo-hb-field select:focus, .asutsabo-hb-field textarea:focus { border-color: #2271b1; outline: none; box-shadow: 0 0 0 1px #2271b1; }
		.asutsabo-hb-footer-actions { display: flex; justify-content: space-between; align-items: center; margin-top: 25px; padding-top: 18px; border-top: 1px solid #c3c4c7; }
		.asutsabo-hb-order-input { width: 55px !important; text-align: center; }
	';
	wp_add_inline_style( 'wp-admin', $custom_css );

	$custom_js = "
		jQuery(document).ready(function($) {
			var \$list = $('#asutsabo-sections-list');

			function updateOrderBadges() {
				\$list.find('.asutsabo-hb-card').each(function(index) {
					var pos = index + 1;
					$(this).find('.asutsabo-hb-order-badge').text('#' + pos);
					$(this).find('.asutsabo-hb-order-input').val(pos);
				});
			}

			if ($.fn.sortable) {
				\$list.sortable({
					handle: '.asutsabo-hb-card-header',
					placeholder: 'asutsabo-hb-card ui-state-highlight',
					forcePlaceholderSize: true,
					axis: 'y',
					update: function() {
						updateOrderBadges();
					}
				});
			}

			// Move Up button
			\$list.on('click', '.js-move-up', function(e) {
				e.preventDefault();
				var \$card = $(this).closest('.asutsabo-hb-card');
				var \$prev = \$card.prev('.asutsabo-hb-card');
				if (\$prev.length) {
					\$card.insertBefore(\$prev);
					updateOrderBadges();
				}
			});

			// Move Down button
			\$list.on('click', '.js-move-down', function(e) {
				e.preventDefault();
				var \$card = $(this).closest('.asutsabo-hb-card');
				var \$next = \$card.next('.asutsabo-hb-card');
				if (\$next.length) {
					\$card.insertAfter(\$next);
					updateOrderBadges();
				}
			});

			// Toggle enabled visual style
			\$list.on('change', '.js-section-enable-toggle', function() {
				var \$card = $(this).closest('.asutsabo-hb-card');
				if ($(this).is(':checked')) {
					\$card.removeClass('is-disabled');
				} else {
					\$card.addClass('is-disabled');
				}
			});
		});
	";
	wp_add_inline_script( 'jquery-ui-sortable', $custom_js );
}
add_action( 'admin_enqueue_scripts', 'asutsabo_homepage_builder_admin_assets' );

/**
 * Renders the Homepage Builder admin page and handles form submissions.
 */
function asutsabo_render_homepage_builder_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to edit homepage settings.', 'asutsabo' ) );
	}

	$notices = array();

	// Handle Reset
	if ( isset( $_POST['asutsabo_reset_homepage_defaults'] ) &&
	     check_admin_referer( 'asutsabo_homepage_builder_save', 'asutsabo_homepage_builder_nonce' ) ) {
		delete_option( 'asutsabo_homepage_sections' );
		$notices[] = array(
			'type'    => 'success',
			'message' => __( 'Homepage sections have been reset to default magazine settings.', 'asutsabo' ),
		);
	}

	// Handle Save
	if ( isset( $_POST['asutsabo_save_homepage_sections'] ) &&
	     check_admin_referer( 'asutsabo_homepage_builder_save', 'asutsabo_homepage_builder_nonce' ) ) {

		$posted_sections = isset( $_POST['asutsabo_sections'] ) && is_array( $_POST['asutsabo_sections'] )
			? $_POST['asutsabo_sections']
			: array();

		$current_sections = asutsabo_get_homepage_sections();
		$sanitized_sections = array();

		foreach ( $posted_sections as $id => $data ) {
			$sec_id = sanitize_key( $id );
			if ( empty( $sec_id ) ) {
				continue;
			}

			$defaults_for_id = isset( $current_sections[ $sec_id ] ) ? $current_sections[ $sec_id ] : array();

			$clean = array(
				'id'          => $sec_id,
				'type'        => isset( $defaults_for_id['type'] ) ? sanitize_key( $defaults_for_id['type'] ) : 'desk',
				'title'       => isset( $data['title'] ) ? sanitize_text_field( wp_unslash( $data['title'] ) ) : '',
				'category'    => isset( $data['category'] ) ? sanitize_title( wp_unslash( $data['category'] ) ) : '',
				'count'       => isset( $data['count'] ) ? max( 1, absint( $data['count'] ) ) : 2,
				'layout'      => isset( $data['layout'] ) ? sanitize_key( $data['layout'] ) : 'split-column',
				'enabled'     => ! empty( $data['enabled'] ) ? true : false,
				'order'       => isset( $data['order'] ) ? absint( $data['order'] ) : 99,
				'badge'       => isset( $data['badge'] ) ? sanitize_text_field( wp_unslash( $data['badge'] ) ) : ( isset( $defaults_for_id['badge'] ) ? $defaults_for_id['badge'] : '' ),
				'description' => isset( $defaults_for_id['description'] ) ? $defaults_for_id['description'] : '',
			);

			// Special fields for briefing
			if ( 'briefing' === $sec_id ) {
				$clean['newsletter_eyebrow']    = isset( $data['newsletter_eyebrow'] ) ? sanitize_text_field( wp_unslash( $data['newsletter_eyebrow'] ) ) : 'THE DAILY INTELLIGENCE';
				$clean['newsletter_headline']   = isset( $data['newsletter_headline'] ) ? sanitize_text_field( wp_unslash( $data['newsletter_headline'] ) ) : '';
				$clean['newsletter_desc']       = isset( $data['newsletter_desc'] ) ? sanitize_textarea_field( wp_unslash( $data['newsletter_desc'] ) ) : '';
				$clean['newsletter_btn_text']   = isset( $data['newsletter_btn_text'] ) ? sanitize_text_field( wp_unslash( $data['newsletter_btn_text'] ) ) : 'Join Free Briefing';
				$clean['newsletter_btn_url']    = isset( $data['newsletter_btn_url'] ) ? sanitize_text_field( wp_unslash( $data['newsletter_btn_url'] ) ) : '#subscribe';
				$clean['newsletter_disclaimer'] = isset( $data['newsletter_disclaimer'] ) ? sanitize_text_field( wp_unslash( $data['newsletter_disclaimer'] ) ) : '';
			}

			// Special fields for ad_banner
			if ( 'ad_banner' === $sec_id ) {
				$clean['ad_code'] = isset( $data['ad_code'] ) ? wp_kses_post( wp_unslash( $data['ad_code'] ) ) : '';
			}

			$sanitized_sections[ $sec_id ] = $clean;

			// Sync with theme_mods for backward compatibility
			if ( 'briefing' === $sec_id ) {
				set_theme_mod( 'asutsabo_show_newsletter', $clean['enabled'] );
				set_theme_mod( 'asutsabo_newsletter_eyebrow', $clean['newsletter_eyebrow'] );
				set_theme_mod( 'asutsabo_newsletter_headline', $clean['newsletter_headline'] );
				set_theme_mod( 'asutsabo_newsletter_description', $clean['newsletter_desc'] );
				set_theme_mod( 'asutsabo_newsletter_button_text', $clean['newsletter_btn_text'] );
				set_theme_mod( 'asutsabo_newsletter_button_url', $clean['newsletter_btn_url'] );
				set_theme_mod( 'asutsabo_newsletter_disclaimer', $clean['newsletter_disclaimer'] );
			} elseif ( 'fast_wire' === $sec_id ) {
				set_theme_mod( 'asutsabo_fast_wire_title', $clean['title'] );
				set_theme_mod( 'asutsabo_fast_wire_category', $clean['category'] );
				set_theme_mod( 'asutsabo_fast_wire_count', $clean['count'] );
			} elseif ( 'hero' === $sec_id ) {
				set_theme_mod( 'asutsabo_top_dispatches_title', $clean['title'] );
				set_theme_mod( 'asutsabo_top_dispatches_category', $clean['category'] );
				set_theme_mod( 'asutsabo_top_dispatches_count', $clean['count'] );
			} elseif ( 'editors_picks' === $sec_id ) {
				set_theme_mod( 'asutsabo_editors_picks_title', $clean['title'] );
				set_theme_mod( 'asutsabo_editors_picks_category', $clean['category'] );
				set_theme_mod( 'asutsabo_editors_picks_count', $clean['count'] );
			} else {
				// Standard category desks
				set_theme_mod( "asutsabo_{$sec_id}_enable", $clean['enabled'] );
				set_theme_mod( "asutsabo_{$sec_id}_title", $clean['title'] );
				set_theme_mod( "asutsabo_{$sec_id}_category", $clean['category'] );
				set_theme_mod( "asutsabo_{$sec_id}_count", $clean['count'] );
			}
		}

		// Sort by order
		uasort(
			$sanitized_sections,
			function ( $a, $b ) {
				$order_a = isset( $a['order'] ) ? (int) $a['order'] : 999;
				$order_b = isset( $b['order'] ) ? (int) $b['order'] : 999;
				if ( $order_a === $order_b ) {
					return 0;
				}
				return ( $order_a < $order_b ) ? -1 : 1;
			}
		);

		// Re-index order 1..N
		$idx = 1;
		foreach ( $sanitized_sections as $k => $v ) {
			$sanitized_sections[ $k ]['order'] = $idx++;
		}

		update_option( 'asutsabo_homepage_sections', $sanitized_sections );

		$notices[] = array(
			'type'    => 'success',
			'message' => __( 'Homepage layout and section settings saved successfully. The frontend homepage has been updated.', 'asutsabo' ),
		);
	}

	$sections = asutsabo_get_homepage_sections();
	$categories = get_categories( array( 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
	$layouts = asutsabo_get_available_layouts();
	?>

	<div class="wrap asutsabo-hb-wrap">
		<div class="asutsabo-hb-header">
			<div>
				<h1><?php esc_html_e( 'Homepage Section Builder', 'asutsabo' ); ?></h1>
				<p><?php esc_html_e( 'Configure, rename, reorder, and toggle content sections on the front page. Section titles are completely independent of category sources.', 'asutsabo' ); ?></p>
			</div>
			<div class="asutsabo-hb-actions">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="button" target="_blank">
					<?php esc_html_e( 'View Front Page ↗', 'asutsabo' ); ?>
				</a>
				<button type="submit" form="asutsabo-homepage-builder-form" name="asutsabo_save_homepage_sections" class="button button-primary button-large">
					<?php esc_html_e( 'Save Changes', 'asutsabo' ); ?>
				</button>
			</div>
		</div>

		<?php foreach ( $notices as $notice ) : ?>
			<div class="notice notice-<?php echo esc_attr( $notice['type'] ); ?> is-dismissible">
				<p><strong><?php echo esc_html( $notice['message'] ); ?></strong></p>
			</div>
		<?php endforeach; ?>

		<form id="asutsabo-homepage-builder-form" method="post" action="">
			<?php wp_nonce_field( 'asutsabo_homepage_builder_save', 'asutsabo_homepage_builder_nonce' ); ?>

			<ul id="asutsabo-sections-list" class="asutsabo-hb-list">
				<?php
				$display_idx = 1;
				foreach ( $sections as $sec_id => $sec ) :
					$is_enabled = ! empty( $sec['enabled'] );
					$order_val  = isset( $sec['order'] ) ? absint( $sec['order'] ) : $display_idx;
					$layout_val = isset( $sec['layout'] ) ? $sec['layout'] : 'split-column';
					$count_val  = isset( $sec['count'] ) ? absint( $sec['count'] ) : 2;
					$cat_val    = isset( $sec['category'] ) ? $sec['category'] : '';
					$title_val  = isset( $sec['title'] ) ? $sec['title'] : '';
					?>
					<li class="asutsabo-hb-card <?php echo ! $is_enabled ? 'is-disabled' : ''; ?>" data-section-id="<?php echo esc_attr( $sec_id ); ?>">
						<input type="hidden" class="asutsabo-hb-order-input" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][order]" value="<?php echo esc_attr( $order_val ); ?>" />

						<!-- Card Header (Drag handle, Order badge, Title, Move up/down, Enable Toggle) -->
						<div class="asutsabo-hb-card-header">
							<div class="asutsabo-hb-card-title-group">
								<span class="asutsabo-hb-drag-handle" title="<?php esc_attr_e( 'Drag to reorder section', 'asutsabo' ); ?>">☰</span>
								<span class="asutsabo-hb-order-badge">#<?php echo esc_html( $display_idx ); ?></span>
								<h3 class="asutsabo-hb-card-name"><?php echo esc_html( ! empty( $title_val ) ? $title_val : $sec_id ); ?></h3>
								<span class="asutsabo-hb-card-type"><?php echo esc_html( strtoupper( str_replace( '_', ' ', $sec['type'] ) ) ); ?></span>
							</div>

							<div class="asutsabo-hb-card-toggle">
								<div class="asutsabo-hb-order-btns">
									<button type="button" class="asutsabo-hb-order-btn js-move-up" title="<?php esc_attr_e( 'Move Up', 'asutsabo' ); ?>">▲</button>
									<button type="button" class="asutsabo-hb-order-btn js-move-down" title="<?php esc_attr_e( 'Move Down', 'asutsabo' ); ?>">▼</button>
								</div>

								<label style="font-weight: 600; font-size: 13px; cursor: pointer; display: flex; align-items: center; gap: 6px;">
									<input type="checkbox" class="js-section-enable-toggle" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][enabled]" value="1" <?php checked( $is_enabled, true ); ?> />
									<?php esc_html_e( 'Enabled', 'asutsabo' ); ?>
								</label>
							</div>
						</div>

						<!-- Card Body (Distinct Section Settings vs Category Settings) -->
						<div class="asutsabo-hb-card-body">
							<?php if ( 'briefing' === $sec_id ) : ?>
								<!-- SPECIAL BRIEFING / NEWSLETTER CONTROLS -->
								<div class="asutsabo-hb-panel" style="background:#fdfefe; border-left:4px solid #2271b1;">
									<h4 class="asutsabo-hb-panel-title"><?php esc_html_e( 'Editorial Briefing Block Settings', 'asutsabo' ); ?></h4>
									<div class="asutsabo-hb-grid">
										<div>
											<div class="asutsabo-hb-field">
												<label for="<?php echo esc_attr( $sec_id ); ?>_eyebrow"><?php esc_html_e( 'Eyebrow Text (Top Red Tag)', 'asutsabo' ); ?></label>
												<input type="text" id="<?php echo esc_attr( $sec_id ); ?>_eyebrow" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][newsletter_eyebrow]" value="<?php echo esc_attr( isset( $sec['newsletter_eyebrow'] ) ? $sec['newsletter_eyebrow'] : 'THE DAILY INTELLIGENCE' ); ?>" />
											</div>
											<div class="asutsabo-hb-field">
												<label for="<?php echo esc_attr( $sec_id ); ?>_headline"><?php esc_html_e( 'Main Headline', 'asutsabo' ); ?></label>
												<input type="text" id="<?php echo esc_attr( $sec_id ); ?>_headline" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][newsletter_headline]" value="<?php echo esc_attr( isset( $sec['newsletter_headline'] ) ? $sec['newsletter_headline'] : 'Essential journalism, direct to your inbox.' ); ?>" />
											</div>
											<div class="asutsabo-hb-field">
												<label for="<?php echo esc_attr( $sec_id ); ?>_desc"><?php esc_html_e( 'Description / Subtext', 'asutsabo' ); ?></label>
												<textarea id="<?php echo esc_attr( $sec_id ); ?>_desc" rows="3" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][newsletter_desc]"><?php echo esc_textarea( isset( $sec['newsletter_desc'] ) ? $sec['newsletter_desc'] : '' ); ?></textarea>
											</div>
										</div>
										<div>
											<div class="asutsabo-hb-field">
												<label for="<?php echo esc_attr( $sec_id ); ?>_btn_text"><?php esc_html_e( 'Button Label', 'asutsabo' ); ?></label>
												<input type="text" id="<?php echo esc_attr( $sec_id ); ?>_btn_text" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][newsletter_btn_text]" value="<?php echo esc_attr( isset( $sec['newsletter_btn_text'] ) ? $sec['newsletter_btn_text'] : 'Join Free Briefing' ); ?>" />
											</div>
											<div class="asutsabo-hb-field">
												<label for="<?php echo esc_attr( $sec_id ); ?>_btn_url"><?php esc_html_e( 'Button Destination Link / Action URL', 'asutsabo' ); ?></label>
												<input type="text" id="<?php echo esc_attr( $sec_id ); ?>_btn_url" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][newsletter_btn_url]" value="<?php echo esc_attr( isset( $sec['newsletter_btn_url'] ) ? $sec['newsletter_btn_url'] : '#subscribe' ); ?>" />
											</div>
											<div class="asutsabo-hb-field">
												<label for="<?php echo esc_attr( $sec_id ); ?>_note"><?php esc_html_e( 'Disclaimer / Note Text', 'asutsabo' ); ?></label>
												<input type="text" id="<?php echo esc_attr( $sec_id ); ?>_note" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][newsletter_disclaimer]" value="<?php echo esc_attr( isset( $sec['newsletter_disclaimer'] ) ? $sec['newsletter_disclaimer'] : 'NO SPAM. ONE-CLICK UNSUBSCRIBE AT ANY TIME.' ); ?>" />
											</div>
										</div>
									</div>
								</div>

							<?php elseif ( 'ad_banner' === $sec_id ) : ?>
								<!-- SPECIAL ADVERTISEMENT CONTROLS -->
								<div class="asutsabo-hb-panel">
									<h4 class="asutsabo-hb-panel-title"><?php esc_html_e( 'Leaderboard Ad Placement', 'asutsabo' ); ?></h4>
									<div class="asutsabo-hb-field">
										<label for="<?php echo esc_attr( $sec_id ); ?>_ad_code"><?php esc_html_e( 'Custom Ad Code, HTML, or Shortcode (Optional)', 'asutsabo' ); ?></label>
										<textarea id="<?php echo esc_attr( $sec_id ); ?>_ad_code" rows="3" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][ad_code]" placeholder="<?php esc_attr_e( 'Leave empty to display default 970x90 / 728x90 advertisement placeholder.', 'asutsabo' ); ?>"><?php echo esc_textarea( isset( $sec['ad_code'] ) ? $sec['ad_code'] : '' ); ?></textarea>
										<span class="description"><?php esc_html_e( 'Supports AdSense scripts, custom banners, or ad manager shortcodes.', 'asutsabo' ); ?></span>
									</div>
								</div>

							<?php else : ?>
								<!-- STANDARD CONTENT DESK SECTION -->
								<div class="asutsabo-hb-grid">
									<!-- PANEL 1: SECTION SETTINGS -->
									<div class="asutsabo-hb-panel">
										<h4 class="asutsabo-hb-panel-title"><?php esc_html_e( '1. Section Settings (Editorial & Layout)', 'asutsabo' ); ?></h4>

										<div class="asutsabo-hb-field">
											<label for="<?php echo esc_attr( $sec_id ); ?>_title"><?php esc_html_e( 'Section Title (Heading Displayed on Frontend)', 'asutsabo' ); ?></label>
											<input type="text" id="<?php echo esc_attr( $sec_id ); ?>_title" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][title]" value="<?php echo esc_attr( $title_val ); ?>" />
											<span class="description"><?php esc_html_e( 'Purely editorial heading. Completely independent from the category chosen on the right.', 'asutsabo' ); ?></span>
										</div>

										<div class="asutsabo-hb-field">
											<label for="<?php echo esc_attr( $sec_id ); ?>_badge"><?php esc_html_e( 'Category Badge Pill (Optional)', 'asutsabo' ); ?></label>
											<input type="text" id="<?php echo esc_attr( $sec_id ); ?>_badge" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][badge]" value="<?php echo esc_attr( isset( $sec['badge'] ) ? $sec['badge'] : '' ); ?>" placeholder="<?php esc_attr_e( 'e.g. ZUNHEBOTO', 'asutsabo' ); ?>" />
											<span class="description"><?php esc_html_e( 'Displayed in the red pill badge over featured lead images.', 'asutsabo' ); ?></span>
										</div>

										<div class="asutsabo-hb-field">
											<label for="<?php echo esc_attr( $sec_id ); ?>_layout"><?php esc_html_e( 'Layout Style / Variant', 'asutsabo' ); ?></label>
											<select id="<?php echo esc_attr( $sec_id ); ?>_layout" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][layout]">
												<?php foreach ( $layouts as $l_key => $l_name ) : ?>
													<option value="<?php echo esc_attr( $l_key ); ?>" <?php selected( $layout_val, $l_key ); ?>>
														<?php echo esc_html( $l_name ); ?>
													</option>
												<?php endforeach; ?>
											</select>
										</div>

										<div class="asutsabo-hb-field">
											<label for="<?php echo esc_attr( $sec_id ); ?>_count"><?php esc_html_e( 'Number of Posts to Display', 'asutsabo' ); ?></label>
											<input type="number" id="<?php echo esc_attr( $sec_id ); ?>_count" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][count]" value="<?php echo esc_attr( $count_val ); ?>" min="1" max="20" />
										</div>
									</div>

									<!-- PANEL 2: CATEGORY SETTINGS -->
									<div class="asutsabo-hb-panel">
										<h4 class="asutsabo-hb-panel-title"><?php esc_html_e( '2. Category Settings (Content Source)', 'asutsabo' ); ?></h4>

										<div class="asutsabo-hb-field">
											<label for="<?php echo esc_attr( $sec_id ); ?>_cat"><?php esc_html_e( 'Category Source', 'asutsabo' ); ?></label>
											<select id="<?php echo esc_attr( $sec_id ); ?>_cat" name="asutsabo_sections[<?php echo esc_attr( $sec_id ); ?>][category]">
												<option value="" <?php selected( $cat_val, '' ); ?>>
													<?php esc_html_e( '— All Categories / Recent Dispatches —', 'asutsabo' ); ?>
												</option>
												<?php foreach ( $categories as $cat ) : ?>
													<option value="<?php echo esc_attr( $cat->slug ); ?>" <?php selected( $cat_val, $cat->slug ); ?>>
														<?php echo esc_html( $cat->name ); ?> (<?php echo esc_html( $cat->count ); ?>)
													</option>
												<?php endforeach; ?>
											</select>
											<span class="description"><?php esc_html_e( 'Determines which articles populate this section. This category name will NOT overwrite the section title.', 'asutsabo' ); ?></span>
										</div>

										<div style="margin-top: 14px; padding: 10px 12px; background: #f0f4f8; border-radius: 4px; font-size: 11px; color: #2c3e50; line-height: 1.4;">
											<strong><?php esc_html_e( 'Editorial Independence Guarantee:', 'asutsabo' ); ?></strong><br />
											<?php esc_html_e( 'You can freely set Section Title to "What\'s Happening" and Category to "Culture". The frontend will display "What\'s Happening" without prepending or displaying the category name.', 'asutsabo' ); ?>
										</div>
									</div>
								</div>
							<?php endif; ?>
						</div>
					</li>
					<?php
					$display_idx++;
				endforeach;
				?>
			</ul>

			<div class="asutsabo-hb-footer-actions">
				<button type="submit" name="asutsabo_reset_homepage_defaults" class="button button-link-delete" onclick="return confirm('<?php esc_attr_e( 'Reset all homepage sections to default magazine settings? Any custom order and names will be reset.', 'asutsabo' ); ?>');">
					<?php esc_html_e( 'Reset to Default Settings', 'asutsabo' ); ?>
				</button>

				<button type="submit" name="asutsabo_save_homepage_sections" class="button button-primary button-large">
					<?php esc_html_e( 'Save Changes', 'asutsabo' ); ?>
				</button>
			</div>
		</form>
	</div>
	<?php
}
