<?php
/**
 * Asutsabo Custom Template Tags & Editorial Helpers.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculate estimated reading time for a given post.
 *
 * @param int|null $post_id Optional post ID.
 * @return string Estimated reading time string, e.g. "4 min read".
 */
function asutsabo_get_reading_time( $post_id = null ) {
	$post = get_post( $post_id );
	if ( ! $post ) {
		return '';
	}

	$content       = $post->post_content;
	$clean_content = wp_strip_all_tags( strip_shortcodes( $content ) );
	$word_count    = str_word_count( $clean_content );

	// Average reading speed: 200 words per minute.
	$minutes = ceil( $word_count / 200 );
	$minutes = max( 1, (int) $minutes );

	/* translators: %d: number of minutes to read */
	return sprintf( _n( '%d min read', '%d min read', $minutes, 'asutsabo' ), $minutes );
}

/**
 * Filter to provide reading time shortcode or template insertion.
 */
function asutsabo_reading_time_shortcode() {
	return '<span class="asutsabo-reading-time">' . esc_html( asutsabo_get_reading_time() ) . '</span>';
}
add_shortcode( 'asutsabo_reading_time', 'asutsabo_reading_time_shortcode' );

/**
 * Prints HTML with meta information for the current post-date/time.
 */
function asutsabo_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated screen-reader-text" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf(
		$time_string,
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( DATE_W3C ) ),
		esc_html( get_the_modified_date() )
	);

	echo '<span class="posted-on is-style-asutsabo-metadata">' . $time_string . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Prints HTML with meta information for the current author.
 */
function asutsabo_posted_by( $include_avatar = false, $avatar_size = 32 ) {
	$byline = '';
	if ( $include_avatar ) {
		$byline .= '<span class="author-avatar">' . get_avatar( get_the_author_meta( 'ID' ), $avatar_size ) . '</span>';
	}
	$byline .= '<span class="byline is-style-asutsabo-byline"> ' . esc_html__( 'By', 'asutsabo' ) . ' <span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span></span>';

	echo $byline; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

/**
 * Output or return primary category kicker for a post.
 *
 * @param int|null $post_id Post ID.
 * @param bool     $echo    Whether to echo or return.
 * @return string
 */
function asutsabo_category_kicker( $post_id = null, $echo = true ) {
	$categories = get_the_category( $post_id );
	if ( empty( $categories ) ) {
		return '';
	}

	$primary_cat = $categories[0];
	$kicker_html = '<a href="' . esc_url( get_category_link( $primary_cat->term_id ) ) . '" class="is-style-asutsabo-kicker">' . esc_html( $primary_cat->name ) . '</a>';

	if ( $echo ) {
		echo $kicker_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	return $kicker_html;
}

/**
 * Render accessible social share row with Web Share API and copy link.
 */
function asutsabo_share_buttons() {
	$post_url   = get_permalink();
	$post_title = get_the_title();
	?>
	<div class="asutsabo-share-row" aria-label="<?php esc_attr_e( 'Share this story', 'asutsabo' ); ?>">
		<span class="asutsabo-share-label"><?php esc_html_e( 'Share Story:', 'asutsabo' ); ?></span>

		<button type="button" class="asutsabo-share-btn asutsabo-share-native" aria-label="<?php esc_attr_e( 'Share article via system dialog', 'asutsabo' ); ?>">
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92z"/></svg>
			<span><?php esc_html_e( 'Share', 'asutsabo' ); ?></span>
		</button>

		<a href="<?php echo esc_url( 'https://twitter.com/intent/tweet?url=' . rawurlencode( $post_url ) . '&text=' . rawurlencode( $post_title ) ); ?>" target="_blank" rel="noopener noreferrer" class="asutsabo-share-btn asutsabo-share-x" aria-label="<?php esc_attr_e( 'Share on X', 'asutsabo' ); ?>">
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
			<span>X</span>
		</a>

		<a href="<?php echo esc_url( 'https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( $post_url ) ); ?>" target="_blank" rel="noopener noreferrer" class="asutsabo-share-btn asutsabo-share-fb" aria-label="<?php esc_attr_e( 'Share on Facebook', 'asutsabo' ); ?>">
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
			<span>Facebook</span>
		</a>

		<a href="<?php echo esc_url( 'https://www.linkedin.com/sharing/share-offsite/?url=' . rawurlencode( $post_url ) ); ?>" target="_blank" rel="noopener noreferrer" class="asutsabo-share-btn asutsabo-share-li" aria-label="<?php esc_attr_e( 'Share on LinkedIn', 'asutsabo' ); ?>">
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451c.979 0 1.778-.773 1.778-1.729V1.73C24 .774 23.205 0 22.225 0z"/></svg>
			<span>LinkedIn</span>
		</a>

		<button type="button" class="asutsabo-share-btn asutsabo-share-copy" data-url="<?php echo esc_url( $post_url ); ?>" aria-label="<?php esc_attr_e( 'Copy link to clipboard', 'asutsabo' ); ?>">
			<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"/></svg>
			<span><?php esc_html_e( 'Copy Link', 'asutsabo' ); ?></span>
		</button>
		<span class="asutsabo-share-feedback" aria-live="polite"></span>
	</div>
	<?php
}

/**
 * Output author bio card.
 *
 * @param int|null $author_id Author user ID.
 */
function asutsabo_author_bio( $author_id = null ) {
	if ( ! $author_id ) {
		$author_id = get_the_author_meta( 'ID' );
	}
	$author_desc  = get_the_author_meta( 'description', $author_id );
	$author_name  = get_the_author_meta( 'display_name', $author_id );
	$author_title = get_the_author_meta( 'asutsabo_job_title', $author_id );
	$twitter      = get_the_author_meta( 'asutsabo_twitter', $author_id );
	$linkedin     = get_the_author_meta( 'asutsabo_linkedin', $author_id );
	$bluesky      = get_the_author_meta( 'asutsabo_bluesky', $author_id );
	$user_url     = get_the_author_meta( 'user_url', $author_id );
	?>
	<div class="asutsabo-author-bio-card">
		<?php echo get_avatar( $author_id, 80, '', '', array( 'class' => 'asutsabo-author-avatar-img' ) ); ?>
		<div class="asutsabo-author-bio-details">
			<div style="display:flex;justify-content:space-between;align-items:baseline;flex-wrap:wrap;gap:0.5rem;">
				<span class="is-style-asutsabo-kicker"><?php esc_html_e( 'About the Author', 'asutsabo' ); ?></span>
				<?php if ( ! empty( $author_title ) ) : ?>
					<span class="is-style-asutsabo-metadata asutsabo-author-role" style="font-weight:600;color:var(--wp--preset--color--secondary, #474542);"><?php echo esc_html( $author_title ); ?></span>
				<?php endif; ?>
			</div>

			<h4 class="asutsabo-author-name">
				<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>"><?php echo esc_html( $author_name ); ?></a>
			</h4>

			<?php if ( ! empty( $author_desc ) ) : ?>
				<p class="asutsabo-author-desc"><?php echo esc_html( $author_desc ); ?></p>
			<?php endif; ?>

			<?php if ( ! empty( $twitter ) || ! empty( $linkedin ) || ! empty( $bluesky ) || ! empty( $user_url ) ) : ?>
				<div class="asutsabo-author-social-links" style="display:flex;align-items:center;gap:0.75rem;margin-top:0.75rem;font-size:0.8125rem;">
					<span style="font-weight:700;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.75rem;text-transform:uppercase;letter-spacing:0.05em;color:var(--wp--preset--color--muted, #6E6B65);"><?php esc_html_e( 'Connect:', 'asutsabo' ); ?></span>
					<?php if ( ! empty( $twitter ) ) :
						$t_url = ( strpos( $twitter, 'http' ) === 0 ) ? $twitter : 'https://x.com/' . ltrim( $twitter, '@' );
					?>
						<a href="<?php echo esc_url( $t_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'Twitter / X Profile', 'asutsabo' ); ?>">
							<?php echo asutsabo_get_social_icon_svg( 'twitter' ); ?>
							<span>X</span>
						</a>
					<?php endif; ?>

					<?php if ( ! empty( $linkedin ) ) :
						$li_url = ( strpos( $linkedin, 'http' ) === 0 ) ? $linkedin : 'https://linkedin.com/in/' . $linkedin;
					?>
						<a href="<?php echo esc_url( $li_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'LinkedIn Profile', 'asutsabo' ); ?>">
							<?php echo asutsabo_get_social_icon_svg( 'linkedin' ); ?>
							<span>LinkedIn</span>
						</a>
					<?php endif; ?>

					<?php if ( ! empty( $bluesky ) ) :
						$bsky_url = ( strpos( $bluesky, 'http' ) === 0 ) ? $bluesky : 'https://bsky.app/profile/' . ltrim( $bluesky, '@' );
					?>
						<a href="<?php echo esc_url( $bsky_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'Bluesky Profile', 'asutsabo' ); ?>">
							<?php echo asutsabo_get_social_icon_svg( 'bluesky' ); ?>
							<span>Bluesky</span>
						</a>
					<?php endif; ?>

					<?php if ( ! empty( $user_url ) ) : ?>
						<a href="<?php echo esc_url( $user_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'Author Website', 'asutsabo' ); ?>">
							<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>
							<span><?php esc_html_e( 'Website', 'asutsabo' ); ?></span>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

/**
 * Output related posts from the current post's category.
 *
 * @param int $count Number of related posts.
 */
function asutsabo_related_posts( $count = 3 ) {
	$post_id    = get_the_ID();
	$categories = wp_get_post_categories( $post_id );

	if ( empty( $categories ) ) {
		return;
	}

	$related_args = array(
		'category__in'        => $categories,
		'post__not_in'        => array( $post_id ),
		'posts_per_page'      => $count,
		'ignore_sticky_posts' => 1,
	);

	$related_query = new WP_Query( $related_args );

	if ( $related_query->have_posts() ) :
		?>
		<div class="asutsabo-related-posts" style="margin-top:2.5rem;padding-top:2rem;border-top:2px solid var(--wp--preset--color--primary, #181716);">
			<h3 class="is-style-asutsabo-section-label"><?php esc_html_e( 'Related Coverage', 'asutsabo' ); ?></h3>
			<div class="asutsabo-grid asutsabo-grid-3">
				<?php
				while ( $related_query->have_posts() ) :
					$related_query->the_post();
					?>
					<article class="asutsabo-card">
						<?php if ( has_post_thumbnail() ) : ?>
							<a href="<?php the_permalink(); ?>" class="asutsabo-card-image" style="display:block;margin-bottom:0.75rem;">
								<?php the_post_thumbnail( 'asutsabo-editorial-grid', array( 'style' => 'width:100%;height:auto;aspect-ratio:3/2;object-fit:cover;' ) ); ?>
							</a>
						<?php endif; ?>
						<?php asutsabo_category_kicker(); ?>
						<h4 class="asutsabo-card-title" style="font-size:1.15rem;line-height:1.25;margin:0.25rem 0 0.5rem 0;">
							<a href="<?php the_permalink(); ?>" style="text-decoration:none;color:inherit;"><?php the_title(); ?></a>
						</h4>
						<div class="is-style-asutsabo-metadata">
							<?php asutsabo_posted_on(); ?>
						</div>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		</div>
		<?php
	endif;
}

/**
 * Output post tags.
 */
function asutsabo_entry_footer() {
	if ( 'post' === get_post_type() ) {
		$tags_list = get_the_tag_list( '', ' ' );
		if ( $tags_list ) {
			/* translators: 1: list of tags */
			echo '<div class="asutsabo-tags-links is-style-asutsabo-metadata" style="margin-bottom:1.5rem;"><span class="tags-label" style="font-weight:700;margin-right:0.5rem;">' . esc_html__( 'Tags:', 'asutsabo' ) . '</span>' . $tags_list . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}

/**
 * Returns inline SVG icon for social platforms.
 *
 * @param string $platform Social platform identifier.
 * @return string Inline SVG element markup.
 */
function asutsabo_get_social_icon_svg( $platform ) {
	switch ( $platform ) {
		case 'twitter':
			return '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>';
		case 'facebook':
			return '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>';
		case 'youtube':
			return '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>';
		case 'linkedin':
			return '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>';
		case 'instagram':
			return '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>';
		case 'bluesky':
			return '<svg viewBox="0 0 568 501" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M123.12 35.77c57.21 42.92 118.8 130.08 160.88 183.16 42.08-53.08 103.67-140.24 160.88-183.16C485.44-0.45 568-30.82 568 76.55c0 21.5-12.3 181.76-19.53 207.61-25.04 89.47-116.32 112.34-196.93 98.41 140.85 23.99 176.62 103.3 99.23 182.26-146.99 150-202.9-74.83-206.77-124.93-3.87 50.1-59.78 274.93-206.77 124.93-77.39-78.96-41.62-158.27 99.23-182.26-80.61 13.93-171.89-8.94-196.93-98.41C12.3 258.31 0 98.05 0 76.55 0-30.82 82.56-0.45 123.12 35.77z"/></svg>';
		case 'rss':
			return '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M6.503 20.752c0 1.794-1.456 3.248-3.251 3.248-1.796 0-3.252-1.454-3.252-3.248 0-1.794 1.456-3.248 3.252-3.248 1.795.001 3.251 1.454 3.251 3.248zm-6.503-12.572v4.811c6.05 0 10.96 4.91 10.96 10.96h4.811c0-8.7-7.071-15.771-15.771-15.771zm0-8.18v4.811c10.565 0 19.141 8.575 19.141 19.14h4.811c0-13.218-10.733-23.951-23.952-23.951z"/></svg>';
		default:
			return '';
	}
}

/**
 * Output the footer social links strip.
 */
function asutsabo_render_footer_social() {
	$platforms = array(
		'twitter'   => array( 'label' => 'Twitter / X', 'url' => get_theme_mod( 'asutsabo_social_twitter', '' ) ),
		'facebook'  => array( 'label' => 'Facebook',    'url' => get_theme_mod( 'asutsabo_social_facebook', '' ) ),
		'youtube'   => array( 'label' => 'YouTube',     'url' => get_theme_mod( 'asutsabo_social_youtube', '' ) ),
		'linkedin'  => array( 'label' => 'LinkedIn',    'url' => get_theme_mod( 'asutsabo_social_linkedin', '' ) ),
		'instagram' => array( 'label' => 'Instagram',   'url' => get_theme_mod( 'asutsabo_social_instagram', '' ) ),
		'rss'       => array( 'label' => 'RSS Feed',    'url' => get_theme_mod( 'asutsabo_social_rss', get_bloginfo( 'rss2_url' ) ) ),
	);

	$has_social = false;
	foreach ( $platforms as $p ) {
		if ( ! empty( $p['url'] ) ) {
			$has_social = true;
			break;
		}
	}

	if ( ! $has_social && ! is_customize_preview() ) {
		return;
	}

	echo '<div class="asutsabo-footer-social" aria-label="' . esc_attr__( 'Social Media Links', 'asutsabo' ) . '">';
	foreach ( $platforms as $slug => $data ) {
		if ( empty( $data['url'] ) && ! is_customize_preview() ) {
			continue;
		}
		$url = ! empty( $data['url'] ) ? esc_url( $data['url'] ) : '#';
		echo '<a href="' . $url . '" class="asutsabo-social-link asutsabo-social-' . esc_attr( $slug ) . '" aria-label="' . esc_attr( $data['label'] ) . '" target="_blank" rel="noopener noreferrer">';
		echo asutsabo_get_social_icon_svg( $slug ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</a>';
	}
	echo '</div>';
}

/**
 * Output the copyright statement with {year} and {site_title} token parsing.
 */
function asutsabo_render_copyright() {
	$default    = '&copy; {year} {site_title}. All rights reserved.';
	$template   = get_theme_mod( 'asutsabo_copyright_text', $default );
	$year       = wp_date( 'Y' );
	$site_title = get_bloginfo( 'name' );
	$rendered   = str_replace( array( '{year}', '{site_title}' ), array( $year, $site_title ), $template );

	echo '<div class="asutsabo-copyright"><p style="margin:0;">' . wp_kses_post( $rendered ) . '</p></div>';
}

/**
 * Determine the current layout (e.g. 'right-sidebar' or 'no-sidebar').
 *
 * @param int|null $post_id Optional post ID for singular items.
 * @return string 'right-sidebar' or 'no-sidebar'.
 */
function asutsabo_get_layout( $post_id = null ) {
	if ( ! is_active_sidebar( 'primary-sidebar' ) ) {
		return 'no-sidebar';
	}

	// Explicit page template check
	if ( is_page_template( 'template-full-width.php' ) ) {
		return 'no-sidebar';
	}
	if ( is_page_template( 'template-with-sidebar.php' ) ) {
		return 'right-sidebar';
	}

	// Singular post or page layout override meta
	if ( is_singular() ) {
		if ( ! $post_id ) {
			$post_id = get_the_ID();
		}
		$post_layout = get_post_meta( $post_id, '_asutsabo_layout', true );
		if ( ! empty( $post_layout ) && 'default' !== $post_layout ) {
			return $post_layout;
		}

		if ( is_single() ) {
			$single_sidebar = get_theme_mod( 'asutsabo_single_sidebar', true );
			return $single_sidebar ? 'right-sidebar' : 'no-sidebar';
		}

		if ( is_page() ) {
			$page_sidebar = get_theme_mod( 'asutsabo_page_sidebar', false );
			return $page_sidebar ? 'right-sidebar' : 'no-sidebar';
		}
	}

	// Archive / search / index pages
	if ( is_archive() || is_home() || is_search() ) {
		$archive_sidebar = get_theme_mod( 'asutsabo_archive_sidebar', true );
		return $archive_sidebar ? 'right-sidebar' : 'no-sidebar';
	}

	return get_theme_mod( 'asutsabo_default_layout', 'right-sidebar' );
}

/**
 * Render reading progress bar at top of window.
 */
function asutsabo_render_reading_progress_bar() {
	if ( ! is_single() || ! get_theme_mod( 'asutsabo_enable_reading_progress', true ) ) {
		return;
	}
	?>
	<div class="asutsabo-reading-progress" id="asutsabo-reading-progress" aria-hidden="true">
		<div class="asutsabo-reading-progress-fill"></div>
	</div>
	<?php
}

/**
 * Render reader controls toolbar: font size toggle and theme mode (light/sepia/dark).
 */
function asutsabo_render_reader_controls() {
	if ( ! is_single() || ! get_theme_mod( 'asutsabo_enable_reader_controls', true ) ) {
		return;
	}
	?>
	<div class="asutsabo-reader-toolbar" role="toolbar" aria-label="<?php esc_attr_e( 'Reading preferences', 'asutsabo' ); ?>">
		<div class="asutsabo-font-resizer" aria-label="<?php esc_attr_e( 'Font size controls', 'asutsabo' ); ?>">
			<span class="asutsabo-toolbar-label"><?php esc_html_e( 'Text Size:', 'asutsabo' ); ?></span>
			<button type="button" class="asutsabo-font-btn" data-action="font-dec" aria-label="<?php esc_attr_e( 'Decrease text size', 'asutsabo' ); ?>">A−</button>
			<button type="button" class="asutsabo-font-btn" data-action="font-reset" aria-label="<?php esc_attr_e( 'Reset text size', 'asutsabo' ); ?>">A</button>
			<button type="button" class="asutsabo-font-btn" data-action="font-inc" aria-label="<?php esc_attr_e( 'Increase text size', 'asutsabo' ); ?>">A+</button>
		</div>

		<div class="asutsabo-theme-switcher" aria-label="<?php esc_attr_e( 'Reader theme mode', 'asutsabo' ); ?>">
			<span class="asutsabo-toolbar-label"><?php esc_html_e( 'Theme:', 'asutsabo' ); ?></span>
			<button type="button" class="asutsabo-theme-btn" data-theme="light" aria-label="<?php esc_attr_e( 'Light reader mode', 'asutsabo' ); ?>"><?php esc_html_e( 'Light', 'asutsabo' ); ?></button>
			<button type="button" class="asutsabo-theme-btn" data-theme="sepia" aria-label="<?php esc_attr_e( 'Sepia reader mode', 'asutsabo' ); ?>"><?php esc_html_e( 'Sepia', 'asutsabo' ); ?></button>
			<button type="button" class="asutsabo-theme-btn" data-theme="dark" aria-label="<?php esc_attr_e( 'Dark reader mode', 'asutsabo' ); ?>"><?php esc_html_e( 'Dark', 'asutsabo' ); ?></button>
		</div>
	</div>
	<?php
}

/**
 * Render Audio Dispatch ("Listen to Story") player if audio URL is set.
 *
 * @param int|null $post_id Post ID.
 */
function asutsabo_render_audio_player( $post_id = null ) {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$audio_url = get_post_meta( $post_id, '_asutsabo_audio_url', true );
	if ( empty( $audio_url ) ) {
		return;
	}

	$duration = get_post_meta( $post_id, '_asutsabo_audio_duration', true );
	?>
	<div class="asutsabo-audio-dispatch-player" aria-label="<?php esc_attr_e( 'Audio narration for this article', 'asutsabo' ); ?>">
		<div class="asutsabo-audio-header">
			<div class="asutsabo-audio-badge">
				<span class="asutsabo-audio-pulse" aria-hidden="true">&#9658;</span>
				<strong><?php esc_html_e( 'Listen to Article', 'asutsabo' ); ?></strong>
			</div>
			<?php if ( ! empty( $duration ) ) : ?>
				<span class="is-style-asutsabo-metadata asutsabo-audio-duration"><?php echo esc_html( $duration ); ?></span>
			<?php endif; ?>
		</div>
		<audio controls preload="metadata" style="width:100%;margin-top:0.6rem;">
			<source src="<?php echo esc_url( $audio_url ); ?>">
			<?php esc_html_e( 'Your browser does not support the audio element.', 'asutsabo' ); ?>
		</audio>
	</div>
	<?php
}

/**
 * Render Editorial Correction / Clarification Box.
 *
 * @param int|null $post_id Post ID.
 */
function asutsabo_render_editorial_correction( $post_id = null ) {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$correction = get_post_meta( $post_id, '_asutsabo_editorial_correction', true );
	if ( empty( $correction ) || '' === trim( wp_strip_all_tags( $correction ) ) ) {
		return;
	}
	?>
	<aside class="asutsabo-correction-box" aria-label="<?php esc_attr_e( 'Editorial Notice & Correction', 'asutsabo' ); ?>">
		<div class="asutsabo-correction-badge">
			<span class="asutsabo-correction-icon" aria-hidden="true">&#9888;</span>
			<strong><?php esc_html_e( 'Editorial Notice / Correction', 'asutsabo' ); ?></strong>
		</div>
		<div class="asutsabo-correction-text">
			<?php echo wp_kses_post( $correction ); ?>
		</div>
	</aside>
	<?php
}

/**
 * Render Table of Contents for long-form articles if 2 or more H2/H3 headings exist.
 *
 * @param int|null $post_id Post ID.
 */
function asutsabo_render_table_of_contents( $post_id = null ) {
	if ( ! $post_id ) {
		$post_id = get_the_ID();
	}

	$meta_toc = get_post_meta( $post_id, '_asutsabo_enable_toc', true );
	if ( 'disable' === $meta_toc ) {
		return;
	}

	if ( 'enable' !== $meta_toc ) {
		if ( ! get_theme_mod( 'asutsabo_enable_toc', true ) ) {
			return;
		}
	}

	$post = get_post( $post_id );
	if ( ! $post ) {
		return;
	}

	// Match <h2> and <h3> tags
	if ( ! preg_match_all( '/<h([2-3])[^>]*>(.*?)<\/h[2-3]>/is', $post->post_content, $matches, PREG_SET_ORDER ) ) {
		return;
	}

	if ( count( $matches ) < 2 ) {
		return;
	}
	?>
	<nav class="asutsabo-toc-box" aria-label="<?php esc_attr_e( 'Table of Contents', 'asutsabo' ); ?>">
		<div class="asutsabo-toc-header">
			<h4 class="asutsabo-toc-title"><?php esc_html_e( 'Article Contents & Key Sections', 'asutsabo' ); ?></h4>
			<button type="button" class="asutsabo-toc-toggle" aria-expanded="true" aria-label="<?php esc_attr_e( 'Toggle Table of Contents', 'asutsabo' ); ?>">
				<span class="asutsabo-toc-toggle-text"><?php esc_html_e( 'Hide', 'asutsabo' ); ?></span>
			</button>
		</div>
		<ol class="asutsabo-toc-list">
			<?php
			$idx = 0;
			foreach ( $matches as $match ) {
				$idx++;
				$level = (int) $match[1];
				$title = wp_strip_all_tags( $match[2] );
				$slug  = sanitize_title( $title );
				if ( empty( $slug ) ) {
					$slug = 'section-' . $idx;
				}
				$class = ( 3 === $level ) ? 'asutsabo-toc-sub' : 'asutsabo-toc-main';
				?>
				<li class="<?php echo esc_attr( $class ); ?>">
					<a href="#<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $title ); ?></a>
				</li>
				<?php
			}
			?>
		</ol>
	</nav>
	<?php
}

/**
 * Filter the content on single posts to inject anchor IDs into <h2> and <h3> headings for TOC.
 *
 * @param string $content Post content.
 * @return string
 */
function asutsabo_add_toc_heading_anchors( $content ) {
	if ( ! is_singular() || is_admin() ) {
		return $content;
	}

	$post_id  = get_the_ID();
	$meta_toc = get_post_meta( $post_id, '_asutsabo_enable_toc', true );
	if ( 'disable' === $meta_toc ) {
		return $content;
	}
	if ( 'enable' !== $meta_toc && ! get_theme_mod( 'asutsabo_enable_toc', true ) ) {
		return $content;
	}

	$idx = 0;
	return preg_replace_callback(
		'/<h([2-3])([^>]*)>(.*?)<\/h\1>/is',
		function ( $matches ) use ( &$idx ) {
			$idx++;
			$level      = $matches[1];
			$attributes = $matches[2];
			$inner_text = $matches[3];
			$title      = wp_strip_all_tags( $inner_text );
			$slug       = sanitize_title( $title );
			if ( empty( $slug ) ) {
				$slug = 'section-' . $idx;
			}

			// If id already exists, keep it
			if ( preg_match( '/\sid=["\'](.*?)["\']/i', $attributes ) ) {
				return "<h{$level}{$attributes}>{$inner_text}</h{$level}>";
			}

			return "<h{$level} id=\"{$slug}\"{$attributes}>{$inner_text}</h{$level}>";
		},
		$content
	);
}
add_filter( 'the_content', 'asutsabo_add_toc_heading_anchors', 20 );

/**
 * Render Back to Top floating button.
 */
function asutsabo_render_back_to_top() {
	if ( ! get_theme_mod( 'asutsabo_enable_back_to_top', true ) ) {
		return;
	}
	?>
	<button type="button" class="asutsabo-back-to-top" id="asutsabo-back-to-top" aria-label="<?php esc_attr_e( 'Back to top of page', 'asutsabo' ); ?>">
		<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 4l-8 8h5v8h6v-8h5z"/></svg>
	</button>
	<?php
}


