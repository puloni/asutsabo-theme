<?php
/**
 * Asutsabo Demo Data Definitions.
 *
 * Defines the complete demo taxonomy, authors, articles, pages, and menus
 * for the one-click demo import system.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Returns demo categories.
 *
 * @return array
 */
function asutsabo_get_demo_categories() {
	return array(
		array(
			'name'        => 'Latest News',
			'slug'        => 'latest-news',
			'description' => 'Real-time regional breaking news, municipality announcements, and community dispatches.',
		),
		array(
			'name'        => 'Nagaland',
			'slug'        => 'nagaland',
			'description' => 'Regional heritage, state developments, arts, cultural festivals, and community initiatives.',
		),
		array(
			'name'        => 'India',
			'slug'        => 'india',
			'description' => 'National policy, parliamentary proceedings, infrastructure projects, and higher education.',
		),
		array(
			'name'        => 'Sports',
			'slug'        => 'sports',
			'description' => 'Endurance athletics, competitive sports science, sportsmanship, and youth training pathways.',
		),
		array(
			'name'        => 'Entertainment',
			'slug'        => 'entertainment',
			'description' => 'Independent cinema, acoustic preservation, broadcasting history, and performing arts.',
		),
		array(
			'name'        => 'Politics',
			'slug'        => 'politics',
			'description' => 'Parliamentary proceedings, electoral reform, constitutional jurisprudence, and public interest inquiries.',
		),
		array(
			'name'        => 'Science & Tech',
			'slug'        => 'technology',
			'description' => 'Computing innovation, AI advancements, space missions, semiconductor manufacturing, and digital infrastructure.',
		),
		array(
			'name'        => 'National',
			'slug'        => 'national',
			'description' => 'Domestic policy, infrastructure initiatives, civil governance, and regional reporting.',
		),
		array(
			'name'        => 'World',
			'slug'        => 'world',
			'description' => 'International diplomacy, global trade agreements, environmental treaties, and geopolitical analysis.',
		),
		array(
			'name'        => 'Business',
			'slug'        => 'business',
			'description' => 'Economic resilience, small enterprise innovation, monetary policy, and corporate governance.',
		),
		array(
			'name'        => 'Culture',
			'slug'        => 'culture',
			'description' => 'Architectural preservation, literary criticism, post-war design, and public heritage.',
		),
		array(
			'name'        => 'Lifestyle',
			'slug'        => 'lifestyle',
			'description' => 'Botanical culinary traditions, ergonomic workspace architecture, and restorative living.',
		),
		array(
			'name'        => 'Opinion',
			'slug'        => 'opinion',
			'description' => 'Critical commentary, editorial columns, ethical inquiries, and cultural philosophical essays.',
		),
		array(
			'name'        => "Editor's Picks",
			'slug'        => 'editors-picks',
			'description' => 'Curated investigative reports and distinguished long-form journalism handpicked by the newsroom.',
		),
	);
}

/**
 * Returns demo authors.
 *
 * @return array
 */
function asutsabo_get_demo_authors() {
	return array(
		array(
			'user_login'   => 'elena_rostova',
			'display_name' => 'Elena Rostova',
			'first_name'   => 'Elena',
			'last_name'    => 'Rostova',
			'user_email'   => 'elena.rostova@unheard.local',
			'description'  => 'Senior investigative correspondent specializing in international governance, civic infrastructure, and legislative policy. Formerly diplomatic correspondent for European Review.',
			'avatar'       => 'author-elena.png',
		),
		array(
			'user_login'   => 'marcus_vance',
			'display_name' => 'Marcus Vance',
			'first_name'   => 'Marcus',
			'last_name'    => 'Vance',
			'user_email'   => 'marcus.vance@unheard.local',
			'description'  => 'Technology and economics editor examining semiconductor supply chains, cryptographic privacy frameworks, and algorithmic market structures.',
			'avatar'       => 'author-marcus.png',
		),
		array(
			'user_login'   => 'priya_nair',
			'display_name' => 'Priya Nair',
			'first_name'   => 'Priya',
			'last_name'    => 'Nair',
			'user_email'   => 'priya.nair@unheard.local',
			'description'  => 'Cultural critic and essayist covering architectural preservation, analog cinematography, and contemporary literary movements.',
			'avatar'       => 'author-priya.png',
		),
	);
}

/**
 * Returns demo articles.
 *
 * @return array
 */
function asutsabo_get_demo_articles() {
	return array(
		// ---------------------------------------------------------------------
		// 1. LATEST NEWS (Zunheboto)
		// ---------------------------------------------------------------------
		array(
			'title'             => 'Zunheboto gears up for annual town festival',
			'slug'              => 'zunheboto-gears-up-for-annual-town-festival',
			'category'          => 'latest-news',
			'badge'             => 'ZUNHEBOTO',
			'tags'              => array( 'Zunheboto', 'Festival', 'Heritage' ),
			'author'            => 'elena_rostova',
			'image'             => 'world-summit.png',
			'days_ago'          => 0,
			'excerpt'           => 'Preparations are in full swing across Zunheboto as citizens and local organizations prepare for cultural dances, music, and community feasts.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Preparations are in full swing across Zunheboto as citizens and local organizations gear up for the annual town festival, showcasing centuries of rich folklore and community celebration.</p><p>Civic groups and traditional performers have been rehearsing traditional songs, folk dances, and indigenous crafts exhibitions to welcome visitors from across the region.</p>',
		),
		array(
			'title'             => 'Traditional heritage showcased at local event',
			'slug'              => 'traditional-heritage-showcased-at-local-event',
			'category'          => 'latest-news',
			'badge'             => 'ZUNHEBOTO',
			'tags'              => array( 'Culture', 'Zunheboto', 'Art' ),
			'author'            => 'priya_nair',
			'image'             => 'culture-publishing.png',
			'days_ago'          => 1,
			'excerpt'           => 'Elders and youth gather to demonstrate age-old textile weaving, spear making, and oral storytelling traditions.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">The indigenous heritage exhibition opened this morning with vibrant displays of traditional handloom textiles, oral histories, and community craftsmanship.</p><p>Organizers stressed the importance of youth engagement in documenting folklore and sustaining regional language traditions.</p>',
		),
		array(
			'title'             => 'Key road project in Zunheboto makes progress',
			'slug'              => 'key-road-project-in-zunheboto-makes-progress',
			'category'          => 'latest-news',
			'badge'             => 'ZUNHEBOTO',
			'tags'              => array( 'Infrastructure', 'Zunheboto', 'Transport' ),
			'author'            => 'marcus_vance',
			'image'             => 'national-transport.png',
			'days_ago'          => 2,
			'excerpt'           => 'Upgrades along major arterial transit corridors reach a new milestone ahead of the upcoming seasonal rains.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Infrastructure engineers have confirmed significant progress along arterial road corridors in Zunheboto, paving the way for safer transit and better market connectivity.</p><p>The expansion improves access for surrounding rural villages, reducing travel times and supporting regional commerce.</p>',
		),

		// ---------------------------------------------------------------------
		// 2. NAGALAND
		// ---------------------------------------------------------------------
		array(
			'title'             => 'Nagaland celebrates rich heritage through vibrant cultural festival',
			'slug'              => 'nagaland-celebrates-rich-heritage-cultural-festival',
			'category'          => 'nagaland',
			'badge'             => 'NAGALAND',
			'tags'              => array( 'Nagaland', 'Festival', 'Culture' ),
			'author'            => 'priya_nair',
			'image'             => 'culture-architecture.png',
			'days_ago'          => 0,
			'excerpt'           => 'Delegates from diverse communities converge for ceremonial honors, folk rhythms, and timeless indigenous rituals.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">A magnificent celebration of unity, artistry, and historic heritage unfolded today across ceremonial grounds, drawing thousands of participants and observers.</p><p>Cultural leaders highlighted the timeless values of communal harmony, seasonal gratitude, and intergenerational storytelling.</p>',
		),
		array(
			'title'             => 'Development projects bring new opportunities to Nagaland',
			'slug'              => 'development-projects-bring-new-opportunities-nagaland',
			'category'          => 'nagaland',
			'tags'              => array( 'Economy', 'Nagaland', 'Development' ),
			'author'            => 'marcus_vance',
			'image'             => 'business-banking.png',
			'days_ago'          => 1,
			'excerpt'           => 'New economic corridors and digital infrastructure initiatives create sustainable livelihoods for regional youth.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">State development initiatives are opening fresh pathways for entrepreneurship, vocational training, and cooperative commerce across Nagaland.</p><p>Local enterprise incubators have already seen record participation from rural artisans and tech startups.</p>',
		),
		array(
			'title'             => 'Naga artisans keep traditional crafts alive',
			'slug'              => 'naga-artisans-keep-traditional-crafts-alive',
			'category'          => 'nagaland',
			'tags'              => array( 'Crafts', 'Heritage', 'Artisans' ),
			'author'            => 'priya_nair',
			'image'             => 'lifestyle-botanical.png',
			'days_ago'          => 2,
			'excerpt'           => 'Master weavers and wood carvers preserve ancestral techniques while mentoring the next generation of creative craftsmen.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Across rural workshops, master weavers and artisans continue to practice specialized wood carving and intricate loin loom textile creation.</p><p>Their efforts ensure that ancestral motifs and sustainable craft traditions remain vibrant in modern society.</p>',
		),
		array(
			'title'             => 'Tourism in Nagaland sees steady growth',
			'slug'              => 'tourism-in-nagaland-sees-steady-growth',
			'category'          => 'nagaland',
			'tags'              => array( 'Tourism', 'Travel', 'Nagaland' ),
			'author'            => 'elena_rostova',
			'image'             => 'world-maritime.png',
			'days_ago'          => 3,
			'excerpt'           => 'Eco-tourism, trekking trails, and heritage village homestays attract domestic and international travelers.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Community-led eco-tourism initiatives and homestays are experiencing steady growth, providing sustainable income to rural households.</p><p>Visitors praise the pristine landscapes, biodiverse valleys, and warm hospitality of local host communities.</p>',
		),
		array(
			'title'             => 'Youth take the lead in community initiatives',
			'slug'              => 'youth-take-the-lead-in-community-initiatives',
			'category'          => 'nagaland',
			'tags'              => array( 'Youth', 'Community', 'Civics' ),
			'author'            => 'elena_rostova',
			'image'             => 'sports-athletics.png',
			'days_ago'          => 4,
			'excerpt'           => 'Student unions and young social workers pioneer environmental cleanups, tree planting, and digital literacy drives.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Youth-led volunteer groups are leading environmental cleanups, public health campaigns, and educational mentoring programs across towns and villages.</p><p>Community leaders have lauded their commitment to civic duty and grassroots leadership.</p>',
		),

		// ---------------------------------------------------------------------
		// 3. INDIA
		// ---------------------------------------------------------------------
		array(
			'title'             => 'Government unveils new scheme to boost rural development',
			'slug'              => 'government-unveils-new-scheme-to-boost-rural-development',
			'category'          => 'india',
			'tags'              => array( 'Policy', 'Rural', 'India' ),
			'author'            => 'marcus_vance',
			'image'             => 'politics-assembly.png',
			'days_ago'          => 0,
			'excerpt'           => 'Comprehensive welfare and farm modernization packages aim to empower agricultural communities nationwide.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">A sweeping rural development program has been announced, targeting rural road electrification, cold storage logistics, and farmer credit expansion.</p><p>The policy focuses on strengthening rural grassroots institutions and providing direct financial support.</p>',
		),
		array(
			'title'             => 'Key bills set to be discussed in upcoming Parliament session',
			'slug'              => 'key-bills-set-to-be-discussed-in-parliament-session',
			'category'          => 'india',
			'secondary_cat'     => 'politics',
			'badge'             => 'POLITICS',
			'tags'              => array( 'Parliament', 'Law', 'Politics' ),
			'author'            => 'elena_rostova',
			'image'             => 'politics-parliament.png',
			'days_ago'          => 1,
			'excerpt'           => 'Lawmakers prepare for crucial debates on data protection, energy transition, and consumer welfare legislation.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">The upcoming parliamentary session is slated to review historic reform bills addressing digital commerce, consumer rights, and green energy incentives.</p><p>Party leaders are holding preparatory meetings to establish common legislative priorities.</p>',
		),
		array(
			'title'             => 'Indian Railways announces new services for Northeast region',
			'slug'              => 'indian-railways-announces-new-services-northeast-region',
			'category'          => 'india',
			'tags'              => array( 'Railways', 'Northeast', 'Transport' ),
			'author'            => 'marcus_vance',
			'image'             => 'national-transport.png',
			'days_ago'          => 2,
			'excerpt'           => 'High-speed semi-express corridors and enhanced freight connectivity link regional hubs to national networks.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Indian Railways has unveiled direct high-speed passenger services and dedicated freight terminals connecting the Northeast with major industrial capitals.</p><p>The improved connectivity is expected to sharply cut transit times for passengers and fresh agricultural produce.</p>',
		),
		array(
			'title'             => 'Higher education enrolment sees rise across India',
			'slug'              => 'higher-education-enrolment-sees-rise-across-india',
			'category'          => 'india',
			'tags'              => array( 'Education', 'Universities', 'India' ),
			'author'            => 'priya_nair',
			'image'             => 'national-telehealth.png',
			'days_ago'          => 3,
			'excerpt'           => 'University registries report unprecedented growth in science, technology, humanities, and research admissions.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">National academic surveys indicate a substantial surge in college and university admissions, particularly among female students and rural scholars.</p><p>Expanded scholarship schemes and digital learning initiatives have significantly broadened higher education access.</p>',
		),

		// ---------------------------------------------------------------------
		// 4. SPORTS
		// ---------------------------------------------------------------------
		array(
			'title'             => 'Northeast United look to build momentum in new season',
			'slug'              => 'northeast-united-look-to-build-momentum-in-new-season',
			'category'          => 'sports',
			'tags'              => array( 'Football', 'Sports', 'Northeast' ),
			'author'            => 'marcus_vance',
			'image'             => 'sports-marathon.png',
			'days_ago'          => 0,
			'excerpt'           => 'Intensive pre-season training, tactical reinforcements, and passionate fan support set the stage for an ambitious campaign.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Northeast United FC has wrapped up its rigorous pre-season conditioning camp with coaches expressing high confidence ahead of the league opener.</p><p>With a balanced roster of seasoned professionals and gifted homegrown youngsters, the squad aims for top-tier contention.</p>',
		),
		array(
			'title'             => 'India set for crucial series ahead of World Cup',
			'slug'              => 'india-set-for-crucial-series-ahead-of-world-cup',
			'category'          => 'sports',
			'tags'              => array( 'Cricket', 'World Cup', 'Sports' ),
			'author'            => 'elena_rostova',
			'image'             => 'sports-athletics.png',
			'days_ago'          => 1,
			'excerpt'           => 'The national squad finalizes bowling combinations and batting depth in a high-stakes multi-match tournament.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Team India steps onto the pitch for an essential bilateral series serving as the final preparatory proving ground before the World Cup.</p><p>Captain and selectors are assessing middle-order consistency and death-over bowling execution under pressure.</p>',
		),
		array(
			'title'             => 'Naga shuttlers make mark in national championship',
			'slug'              => 'naga-shuttlers-make-mark-in-national-championship',
			'category'          => 'sports',
			'tags'              => array( 'Badminton', 'Sports', 'Nagaland' ),
			'author'            => 'priya_nair',
			'image'             => 'sports-marathon.png',
			'days_ago'          => 2,
			'excerpt'           => 'Young badminton prodigies clinch podium finishes in singles and doubles categories against seasoned opponents.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Emerging badminton champions from Nagaland delivered commanding performances at the national junior rankings, earning bronze and gold medals.</p><p>State sports officials celebrated the historic achievement, promising upgraded indoor training arenas.</p>',
		),
		array(
			'title'             => 'Local athletes shine at state meet',
			'slug'              => 'local-athletes-shine-at-state-meet',
			'category'          => 'sports',
			'tags'              => array( 'Athletics', 'Track', 'Sports' ),
			'author'            => 'marcus_vance',
			'image'             => 'sports-athletics.png',
			'days_ago'          => 3,
			'excerpt'           => 'Record-breaking sprint and relay times highlight an inspiring display of sportsmanship and youthful vigor.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">The annual State Athletics Championship concluded amidst jubilation as local track and field athletes set several new state records.</p><p>Coaches highlighted the dedication and disciplined training regimes of the participating athletes.</p>',
		),

		// ---------------------------------------------------------------------
		// 5. ENTERTAINMENT
		// ---------------------------------------------------------------------
		array(
			'title'             => 'Naga musician wins hearts with new single',
			'slug'              => 'naga-musician-wins-hearts-with-new-single',
			'category'          => 'entertainment',
			'badge'             => 'ENTERTAINMENT',
			'tags'              => array( 'Music', 'Entertainment', 'Culture' ),
			'author'            => 'priya_nair',
			'image'             => 'entertainment-cinema.png',
			'days_ago'          => 0,
			'excerpt'           => 'Soulful acoustic melodies combined with heartfelt folklore lyrics top digital streaming charts within hours of launch.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">The latest acoustic single from an acclaimed Naga singer-songwriter has captivated music lovers across the country, debuting at number one on indie charts.</p><p>The track blends traditional folk acoustic textures with contemporary melodic storytelling.</p>',
		),
		array(
			'title'             => 'Upcoming Naga film creates buzz online',
			'slug'              => 'upcoming-naga-film-creates-buzz-online',
			'category'          => 'entertainment',
			'tags'              => array( 'Film', 'Cinema', 'Entertainment' ),
			'author'            => 'priya_nair',
			'image'             => 'entertainment-archive.png',
			'days_ago'          => 1,
			'excerpt'           => 'The independent feature film teaser trailer garners glowing praise for cinematography, acting, and cultural authenticity.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">An eagerly anticipated independent Naga drama has generated widespread enthusiasm following its official trailer release at international festivals.</p><p>Critics praised the breathtaking hillside cinematography, authentic costume design, and compelling narrative arc.</p>',
		),
		array(
			'title'             => 'Music festival brings together top artists',
			'slug'              => 'music-festival-brings-together-top-artists',
			'category'          => 'entertainment',
			'tags'              => array( 'Concert', 'Festival', 'Music' ),
			'author'            => 'elena_rostova',
			'image'             => 'culture-architecture.png',
			'days_ago'          => 2,
			'excerpt'           => 'Over thirty bands, vocalists, and instrumentalists light up the open-air concert grounds in a landmark music weekend.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Music enthusiasts gathered under open skies as premier rock bands, vocalists, and folk artists headlined the three-day regional music fest.</p><p>The festival served as a vibrant platform for both emerging indie talent and veteran musicians.</p>',
		),
		array(
			'title'             => 'Local talent shines on national platform',
			'slug'              => 'local-talent-shines-on-national-platform',
			'category'          => 'entertainment',
			'tags'              => array( 'Talent', 'Performing Arts', 'Showcase' ),
			'author'            => 'priya_nair',
			'image'             => 'lifestyle-workspace.png',
			'days_ago'          => 3,
			'excerpt'           => 'Outstanding vocalists and theatrical performers receive standing ovations at prestigious cultural auditoriums in the capital.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Young vocalists and classical theatrical performers from the state received standing ovations during their national showcase performance in New Delhi.</p><p>Eminent cultural adjudicators commended their vocal mastery and poise.</p>',
		),

		// ---------------------------------------------------------------------
		// 6. POLITICS
		// ---------------------------------------------------------------------
		array(
			'title'             => 'Government unveils new policy to boost rural development',
			'slug'              => 'government-unveils-new-policy-to-boost-rural-politics',
			'category'          => 'politics',
			'tags'              => array( 'Politics', 'Governance', 'Policy' ),
			'author'            => 'marcus_vance',
			'image'             => 'politics-assembly.png',
			'days_ago'          => 1,
			'excerpt'           => 'Cabinet ministers present policy frameworks emphasizing decentralized administrative authority and rural investment.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Cabinet leadership has laid out an expansive governance blueprint focusing on rural decentralization, block-level funding, and civic transparency.</p><p>Legislative leaders from across political spectrums discussed collaborative rollout timelines.</p>',
		),
		array(
			'title'             => 'Opposition raises concerns over key amendments',
			'slug'              => 'opposition-raises-concerns-over-key-amendments',
			'category'          => 'politics',
			'tags'              => array( 'Opposition', 'Debate', 'Parliament' ),
			'author'            => 'elena_rostova',
			'image'             => 'opinion-trust.png',
			'days_ago'          => 2,
			'excerpt'           => 'Parliamentary floor leaders call for comprehensive committee reviews and stakeholder testimonies regarding regulatory changes.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Opposition parliamentarians held a joint conference outlining key questions regarding legislative clauses and calling for structured committee review.</p><p>Lawmakers stressed the need for thorough deliberation before statutory enactments.</p>',
		),
		array(
			'title'             => 'Northeast development takes centre stage in Delhi meeting',
			'slug'              => 'northeast-development-centre-stage-delhi-meeting',
			'category'          => 'politics',
			'tags'              => array( 'Northeast', 'Delhi', 'Politics' ),
			'author'            => 'marcus_vance',
			'image'             => 'politics-parliament.png',
			'days_ago'          => 3,
			'excerpt'           => 'Chief Ministers and union leaders deliberate on border commerce, industrial parks, and air connectivity expansions.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">A high-level conclave between regional leadership and central ministries concluded in the capital with agreements on road connectivity, aviation corridors, and border trade posts.</p><p>Leaders underscored the strategic role of Northeast economic infrastructure.</p>',
		),

		// ---------------------------------------------------------------------
		// 7. SCIENCE & TECH
		// ---------------------------------------------------------------------
		array(
			'title'             => 'New Windows update brings AI features to more users',
			'slug'              => 'new-windows-update-brings-ai-features-to-more-users',
			'category'          => 'technology',
			'badge'             => 'SCIENCE & TECH',
			'tags'              => array( 'Windows', 'AI', 'Software' ),
			'author'            => 'marcus_vance',
			'image'             => 'tech-semiconductor.png',
			'days_ago'          => 0,
			'excerpt'           => 'The latest operating system build rolls out integrated neural processing, smart search, and automated creative tools.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">The global operating system update delivers intelligent assistant integrations, automated summary features, and accelerated local neural processing across compatible hardware.</p><p>Software developers and enterprise users have welcomed the streamlined workflow and enhanced security protections.</p>',
		),
		array(
			'title'             => 'Latest smartphones offer smarter AI features',
			'slug'              => 'latest-smartphones-offer-smarter-ai-features',
			'category'          => 'technology',
			'tags'              => array( 'Mobile', 'AI', 'Gadgets' ),
			'author'            => 'priya_nair',
			'image'             => 'tech-security.png',
			'days_ago'          => 1,
			'excerpt'           => 'On-device machine learning chips power real-time speech translation, photo enhancement, and battery management.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Next-generation smartphones showcase dedicated silicon neural engines that perform real-time translation, generative editing, and privacy-preserving computing directly on the device.</p><p>Industry analysts project accelerated consumer adoption of AI-native handheld devices.</p>',
		),
		array(
			'title'             => 'India’s latest satellite mission marks a major milestone',
			'slug'              => 'indias-latest-satellite-mission-marks-major-milestone',
			'category'          => 'technology',
			'tags'              => array( 'Space', 'ISRO', 'Satellite' ),
			'author'            => 'marcus_vance',
			'image'             => 'tech-semiconductor.png',
			'days_ago'          => 2,
			'excerpt'           => 'The precision launch delivers Earth observation and oceanographic climate sensors into polar sun-synchronous orbit.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">The national space agency successfully placed its advanced ocean-monitoring observatory into polar orbit, marking another landmark triumph for indigenous space technology.</p><p>The payload provides crucial meteorological and disaster-warning telemetry for coastal defense and agricultural planning.</p>',
		),
		array(
			'title'             => 'How AI is changing everyday life in India',
			'slug'              => 'how-ai-is-changing-everyday-life-in-india',
			'category'          => 'technology',
			'tags'              => array( 'Artificial Intelligence', 'Society', 'Technology' ),
			'author'            => 'priya_nair',
			'image'             => 'tech-security.png',
			'days_ago'          => 3,
			'excerpt'           => 'From vernacular voice search in rural markets to diagnostic healthcare and digital payments, algorithmic tools become ubiquitous.',
			'content'           => '<p class="is-style-asutsabo-lead-paragraph">Artificial intelligence applications are transforming daily routines across urban and rural India, powering voice-first vernacular services, healthcare diagnostics, and streamlined public governance.</p><p>Experts emphasize that ethical deployment and indigenous language models are essential for inclusive technological progress.</p>',
		),

		// ---------------------------------------------------------------------
		// 8. ADDITIONAL EDITORIAL DISPATCHES
		// ---------------------------------------------------------------------
		array(
			'title'             => 'Cities Prepare for a New Wave of Public Transport Improvements',
			'slug'              => 'cities-prepare-public-transport-improvements',
			'category'          => 'national',
			'secondary_cat'     => 'editors-picks',
			'tags'              => array( 'Transit', 'Infrastructure', 'Urban Planning' ),
			'author'            => 'elena_rostova',
			'image'             => 'national-transport.png',
			'days_ago'          => 1,
			'excerpt'           => 'Municipal planners across major urban corridors are synchronizing rail schedules, electrifying bus rapid transit lines, and redesigning pedestrian thoroughfares to support unprecedented ridership expansion.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Municipal transit authorities across fifteen metropolitan regions have finalized unified modernization pacts intended to accelerate commuter transit frequency and integrate decarbonized transit corridors over the next decade.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">The initiative represents the largest coordinated public infrastructure investment in municipal transport since the mid-century expansion of intercity rail networks. With commuting habits permanently altered following recent labor reorganizations, transit directors are re-centering investment around circumferential routes rather than exclusively radial lines terminating in financial districts.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2} -->
<h2>Engineering Seamless Intermodal Hubs</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Central to the revitalization is the conversion of aging rail termini into mixed-use civic plazas where rapid bus services, light rail networks, and protected regional cycling highways converge under continuous weatherized canopies. Early pilot programs demonstrate a twenty-two percent reduction in average transfer times when ticketing and directional wayfinding are unified under single digital standards.</p>
<!-- /wp:paragraph -->

<!-- wp:pullquote {"className":"is-style-asutsabo-editorial-pullquote"} -->
<figure class="wp-block-pullquote is-style-asutsabo-editorial-pullquote"><blockquote><p>"The future of urban mobility does not depend solely on higher speeds, but on eliminating the friction between disparate transit modes."</p><cite>Chief Transport Engineer David Cho</cite></blockquote></figure>
<!-- /wp:pullquote -->

<!-- wp:heading {"level":3} -->
<h3>Financing and Regional Implementation</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Public-private coordination models developed during the planning phase ensure that surrounding land values generated by new transit access directly replenish municipal capital funds, preventing long-term operational deficits while securing dedicated funding for low-fare commuter passes.</p>
<!-- /wp:paragraph -->',
		),

		// 2. National 2
		array(
			'title'             => 'Rural Healthcare Networks Expand Telemedicine Access Across Coastal Regions',
			'slug'              => 'rural-healthcare-telemedicine-access-coastal',
			'category'          => 'national',
			'tags'              => array( 'Healthcare', 'Public Policy', 'Regional' ),
			'author'            => 'marcus_vance',
			'image'             => 'national-telehealth.png',
			'days_ago'          => 2,
			'excerpt'           => 'Specialized diagnostic clinics linked via low-latency satellite infrastructure bring subspecialty pediatric and cardiac consultations to isolated fishing harbors and island communities.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Coastal health consortiums have unveiled high-bandwidth remote examination pods that connect isolated maritime clinics directly to tertiary teaching hospitals in metropolitan medical centers.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">For decades, families living on remote archipelagos and coastal outposts confronted arduous ferry journeys and weather delays simply to obtain routine cardiology consultations or specialized neonatal screenings. The newly established network resolves this gap by equipping community nurse stations with real-time biometric telemetry equipment.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2} -->
<h2>Decentralized Diagnostics in Practice</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Nurse practitioners trained in diagnostic digital stethoscopes and mobile ultrasound wands now conduct examinations while surgical teams hundreds of miles away observe high-definition video feeds. Medical directors report that early detection rates for chronic cardiovascular markers have doubled across participating clinics during the initial six months of operation.</p>
<!-- /wp:paragraph -->',
		),

		// 3. World 1
		array(
			'title'             => 'Global Climate Accord Finalizes New Guidelines for Industrial Decarbonization',
			'slug'              => 'global-climate-accord-industrial-decarbonization',
			'category'          => 'world',
			'secondary_cat'     => 'editors-picks',
			'tags'              => array( 'Climate', 'Diplomacy', 'Energy' ),
			'author'            => 'priya_nair',
			'image'             => 'world-summit.png',
			'days_ago'          => 3,
			'excerpt'           => 'Delegates from forty nations have agreed on verifiable carbon accounting methodologies for heavy manufacturing, cement formulation, and maritime shipping fuels.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Following intense multilateral deliberations, representatives from forty industrial economies have concluded the Geneva Framework for heavy industrial emissions verification.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">Unlike previous international protocols that relied heavily on voluntary corporate disclosures and estimated baseline emissions, the new accord establishes standardized physical sensor verifications for blast furnaces, aluminum smelters, and commercial container fleets. Participating nations agree to harmonize border carbon adjustments based on transparent cryptographic logs.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2} -->
<h2>Standardizing Cross-Border Carbon Pricing</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The core breakthrough centers on a uniform audit methodology that accounts for emissions embedded in imported precursor materials. By removing legal ambiguities surrounding carbon accounting, international trade disputes regarding green subsidies are projected to decrease sharply.</p>
<!-- /wp:paragraph -->',
		),

		// 4. World 2
		array(
			'title'             => 'Maritime Trade Routes Adapt to Changing Arctic Navigation Protocols',
			'slug'              => 'maritime-trade-routes-arctic-navigation-protocols',
			'category'          => 'world',
			'tags'              => array( 'Maritime', 'Trade', 'Logistics' ),
			'author'            => 'marcus_vance',
			'image'             => 'world-maritime.png',
			'days_ago'          => 4,
			'excerpt'           => 'International hydrographic commissions establish strict vessel separation lanes and emergency environmental response depots across northern transit channels.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Commercial cargo carriers navigating newly open polar sea lanes face comprehensive environmental safety requirements designed to prevent fuel oil spills in delicate northern biomes.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">As reduced seasonal ice cover opens shipping shortcuts between European ports and East Asian logistics centers, international shipping bodies have enacted mandatory double-hull polar certificates and restricted heavy fuel oil usage north of sixty-six degrees latitude.</p>
<!-- /wp:paragraph -->',
		),

		// 5. Politics 1
		array(
			'title'             => 'Parliamentary Inquiry Weighs Transparency Rules for Campaign Financing',
			'slug'              => 'parliamentary-inquiry-campaign-finance-transparency',
			'category'          => 'politics',
			'secondary_cat'     => 'editors-picks',
			'tags'              => array( 'Governance', 'Elections', 'Law' ),
			'author'            => 'elena_rostova',
			'image'             => 'politics-parliament.png',
			'days_ago'          => 5,
			'excerpt'           => 'Legislative committees review proposals to mandate real-time 48-hour online disclosures for all contributions surpassing municipal reporting thresholds.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">A bipartisan parliamentary committee has commenced public hearings on sweeping amendments to electoral disclosure statutes, aiming to close multi-tier donor shielding loopholes.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">Testimony from investigative watchdogs and constitutional scholars highlighted the increasing prevalence of opaque legal entities contributing to contested parliamentary races. The proposed legislation requires independent expenditure committees to disclose beneficial ownership records prior to advertising broadcast deadlines.</p>
<!-- /wp:paragraph -->',
		),

		// 6. Politics 2
		array(
			'title'             => 'Municipal Assemblies Grant Citizens Direct Oversight on Infrastructure Spending',
			'slug'              => 'municipal-assemblies-direct-citizen-oversight',
			'category'          => 'politics',
			'tags'              => array( 'Democracy', 'Local Government', 'Civic' ),
			'author'            => 'elena_rostova',
			'image'             => 'politics-assembly.png',
			'days_ago'          => 6,
			'excerpt'           => 'Participatory budgeting models gain momentum as city councils assign ten percent of capital maintenance funds to neighborhood referendum assemblies.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Civic assemblies in seven mid-sized cities have concluded their first fiscal cycle under participatory capital charters, resulting in community-selected street calming and public park projects.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Independent auditors noted that participatory voting registered historic engagement levels among working-class renters and younger demographics who traditionally bypass municipal elections.</p>
<!-- /wp:paragraph -->',
		),

		// 7. Business 1
		array(
			'title'             => 'Small Businesses Turn to Digital Tools to Reach New Regional Customers',
			'slug'              => 'small-businesses-digital-tools-regional-customers',
			'category'          => 'business',
			'tags'              => array( 'Economy', 'Commerce', 'Technology' ),
			'author'            => 'marcus_vance',
			'image'             => 'business-commerce.png',
			'days_ago'          => 7,
			'excerpt'           => 'Independent manufacturing workshops and craft producers combine localized micro-warehouses with federated digital marketplaces to challenge national retail monopolies.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Regional business cooperatives are building cooperative digital platforms that enable small-scale fabricators and agricultural producers to pool fulfillment logistics without relying on predatory marketplace algorithms.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">By maintaining joint regional depots and adopting open inventory protocols, over three hundred independent artisans in the northern manufacturing belt have cut fulfillment overhead by thirty percent while preserving independent direct customer relationships.</p>
<!-- /wp:paragraph -->',
		),

		// 8. Business 2
		array(
			'title'             => 'Central Banks Navigate Inflation Pressures Amid Shifting Supply Chains',
			'slug'              => 'central-banks-inflation-pressures-supply-chains',
			'category'          => 'business',
			'tags'              => array( 'Banking', 'Finance', 'Markets' ),
			'author'            => 'marcus_vance',
			'image'             => 'business-banking.png',
			'days_ago'          => 8,
			'excerpt'           => 'Monetary policymakers weigh interest rate adjustments against structural shifts in semiconductor manufacturing and regional energy independence investments.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Economic ministers and monetary authorities concluded quarterly symposiums in Basel emphasizing that interest rate tools alone cannot resolve logistical bottlenecks in specialized precision engineering components.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The resulting communiqu&eacute; urges fiscal authorities to pair monetary stabilization with strategic sovereign loan guarantees for domestic raw materials refining.</p>
<!-- /wp:paragraph -->',
		),

		// 9. Technology 1
		array(
			'title'             => 'The New Generation of Open Hardware Foundries Reshaping Semiconductor Innovation',
			'slug'              => 'open-hardware-foundries-semiconductor-innovation',
			'category'          => 'technology',
			'secondary_cat'     => 'editors-picks',
			'tags'              => array( 'Semiconductors', 'Engineering', 'Open Source' ),
			'author'            => 'marcus_vance',
			'image'             => 'tech-semiconductor.png',
			'days_ago'          => 9,
			'excerpt'           => 'Community-driven wafer fabs and open-source silicon instruction architectures democratize microchip prototyping for university laboratories and independent research institutions.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">A quiet revolution in modular photolithography equipment is allowing cooperative research fabs to produce verified open-source microcontrollers without paying proprietary licensing royalties.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">Just as open software fundamentally restructured server computing twenty-five years ago, open silicon designs based on RISC-V architectures are lowering the barrier to custom integrated circuit fabrication. Emerging hardware engineers can now submit chip designs to pooled fabrication runs for a fraction of historical costs.</p>
<!-- /wp:paragraph -->',
		),

		// 10. Technology 2
		array(
			'title'             => 'Next-Generation Encryption Standards Adopted to Shield Critical Public Infrastructure',
			'slug'              => 'next-generation-encryption-critical-infrastructure',
			'category'          => 'technology',
			'tags'              => array( 'Cybersecurity', 'Privacy', 'Software' ),
			'author'            => 'marcus_vance',
			'image'             => 'tech-security.png',
			'days_ago'          => 10,
			'excerpt'           => 'National cyber defense centers mandate quantum-resistant cryptographic algorithms across municipal electrical grids, water treatment controls, and civilian telecommunication backbones.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Public utilities have completed the first phase of migration to post-quantum lattice-based cryptographic protocols, securing municipal supervisory control networks against prospective adversarial decryption.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The multi-year upgrade represents a pre-emptive defense against harvest-now, decrypt-later intelligence collection tactics, ensuring that civilian grid telemetry remains mathematically secure.</p>
<!-- /wp:paragraph -->',
		),

		// 11. Sports 1
		array(
			'title'             => 'Young Athletes Find New Pathways Into Competitive Athletics',
			'slug'              => 'young-athletes-pathways-competitive-athletics',
			'category'          => 'sports',
			'tags'              => array( 'Athletics', 'Youth', 'Competition' ),
			'author'            => 'priya_nair',
			'image'             => 'sports-athletics.png',
			'days_ago'          => 11,
			'excerpt'           => 'Community sports clubs establish peer-coaching academies and open biometric performance clinics to eliminate pay-to-play barriers for aspiring track and field runners.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Grassroots athletics clubs across regional sports districts are dismantling fee-based development academies in favor of publicly endowed coaching programs focused on injury prevention and long-term athletic health.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">For decades, the path to national competitive athletics was increasingly gated by private academy fees and expensive travel team itineraries. The new community athletic cooperative pairs retired Olympians with public school physical education departments to scout and mentor promising athletes regardless of socioeconomic background.</p>
<!-- /wp:paragraph -->',
		),

		// 12. Sports 2
		array(
			'title'             => 'The Science of High-Altitude Conditioning in Endurance Marathons',
			'slug'              => 'science-high-altitude-conditioning-marathons',
			'category'          => 'sports',
			'tags'              => array( 'Sports Science', 'Physiology', 'Training' ),
			'author'            => 'priya_nair',
			'image'             => 'sports-marathon.png',
			'days_ago'          => 12,
			'excerpt'           => 'Sports physiologists reveal how intermittent hypobaric exposure and metabolic pacing protocols are pushing competitive marathon times closer to biological human limits.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">A pioneering longitudinal study of long-distance runners in alpine training centers sheds new light on cellular oxygen efficiency and glycogen preservation during the final six miles of elite marathon competition.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Researchers tracked metabolic blood markers across fifty marathoners training between 2,200 and 2,800 meters elevation, finding that micro-adjustments in stride mechanics reduce cumulative tendon fatigue by fifteen percent.</p>
<!-- /wp:paragraph -->',
		),

		// 13. Entertainment 1
		array(
			'title'             => 'Independent Film Collectives Reclaim the Art of Analog Cinematography',
			'slug'              => 'independent-film-collectives-analog-cinematography',
			'category'          => 'entertainment',
			'tags'              => array( 'Cinema', 'Film', 'Photography' ),
			'author'            => 'priya_nair',
			'image'             => 'entertainment-cinema.png',
			'days_ago'          => 13,
			'excerpt'           => 'Rejecting hyper-polished digital sensors, a new vanguard of independent directors embraces 16mm and 35mm celluloid stocks for organic visual texture and deliberate pacing.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">In converted industrial lofts across Berlin, Bristol, and Montreal, young documentary filmmakers are building collective darkrooms and hand-processing 16mm film stock to resist the homogenization of streaming platform aesthetics.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">The renaissance is not mere nostalgia. Cinematographers emphasize that the finite physical duration of a film magazine imposes a disciplined shooting ethos that encourages rehearsals, deliberate lighting choreography, and heightened actor chemistry that digital infinite recording often dilutes.</p>
<!-- /wp:paragraph -->',
		),

		// 14. Entertainment 2
		array(
			'title'             => 'Public Broadcasting Archives Digitize Century of Acoustic Recordings',
			'slug'              => 'broadcasting-archives-digitize-century-acoustic-recordings',
			'category'          => 'entertainment',
			'tags'              => array( 'Audio', 'Archival', 'Broadcasting' ),
			'author'            => 'priya_nair',
			'image'             => 'entertainment-archive.png',
			'days_ago'          => 14,
			'excerpt'           => 'Audio restorers use laser optical turntables and non-destructive imaging to recover irreplaceable wax cylinder folklore and early radio theater broadcasts.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">National sound archives have completed high-resolution digital remastering of fifty thousand historic shellac discs, making uncompressed master recordings freely accessible to musicologists worldwide.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>By employing non-contact optical scanning that reads groove depths without stylus friction, archivists have preserved delicate recordings that would have disintegrated under traditional playback needles.</p>
<!-- /wp:paragraph -->',
		),

		// 15. Culture 1
		array(
			'title'             => 'Modernist Architecture Rediscovered: Restoring Post-War Civic Structures',
			'slug'              => 'modernist-architecture-restoring-post-war-civic',
			'category'          => 'culture',
			'secondary_cat'     => 'editors-picks',
			'tags'              => array( 'Architecture', 'Design', 'Heritage' ),
			'author'            => 'priya_nair',
			'image'             => 'culture-architecture.png',
			'days_ago'          => 15,
			'excerpt'           => 'Preservation trusts and municipal councils collaborate to rehabilitate brutalist libraries, civic concert halls, and modernist community centers long threatened by demolition.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">A growing international preservation movement is demonstrating that post-war reinforced concrete buildings can be retrofitted for state-of-the-art thermal efficiency while honoring their bold egalitarian civic geometry.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">Rather than razing mid-century municipal complexes to erect glass curtain towers, forward-thinking cities are sandblasting weathered board-marked facades, replacing drafty fenestration with triple-glazed replica mullions, and installing geothermal heat loops beneath concrete plazas.</p>
<!-- /wp:paragraph -->',
		),

		// 16. Culture 2
		array(
			'title'             => 'The Rise of Micro-Publishing and the Resurgence of Literary Journals',
			'slug'              => 'micro-publishing-resurgence-literary-journals',
			'category'          => 'culture',
			'tags'              => array( 'Literature', 'Publishing', 'Books' ),
			'author'            => 'priya_nair',
			'image'             => 'culture-publishing.png',
			'days_ago'          => 16,
			'excerpt'           => 'Independent presses print limited-run quarterly reviews on letterpress equipment, finding enthusiastic readers seeking tangible editorial curation away from algorithmic feeds.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Far from rendering physical print obsolete, digital fatigue has fostered a thriving counter-economy of bespoke literary quarterlies printed on archival rag paper with hand-set lead type.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Editors report record print subscription renewals, demonstrating that discerning readers value tactile publication craftsmanship and curated long-form essays over evanescent digital commentary.</p>
<!-- /wp:paragraph -->',
		),

		// 17. Lifestyle 1
		array(
			'title'             => 'Urban Foraging and the Revival of Native Plant Culinary Traditions',
			'slug'              => 'urban-foraging-revival-native-plant-culinary',
			'category'          => 'lifestyle',
			'tags'              => array( 'Food', 'Nature', 'Wellness' ),
			'author'            => 'priya_nair',
			'image'             => 'lifestyle-botanical.png',
			'days_ago'          => 17,
			'excerpt'           => 'Botanists and experimental chefs partner with municipal parks departments to map edible native perennials and reintroduce forgotten regional flavor profiles.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Culinary workshops are introducing city dwellers to the rich gastronomy of indigenous berries, aromatic wild herbs, and acorn flour harvested responsibly from public commons and greenways.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">Advocates emphasize ethical harvesting codes and soil testing protocols, transforming neighborhood foraging walks into immersive ecological literacy education that deepens urban residents&rsquo; relationship to local plant biodiversity.</p>
<!-- /wp:paragraph -->',
		),

		// 18. Lifestyle 2
		array(
			'title'             => 'Architects Re-engineer Workspaces for Circadian Rhythm and Natural Daylight',
			'slug'              => 'architects-workspaces-circadian-rhythm-daylight',
			'category'          => 'lifestyle',
			'tags'              => array( 'Architecture', 'Wellness', 'Work' ),
			'author'            => 'marcus_vance',
			'image'             => 'lifestyle-workspace.png',
			'days_ago'          => 18,
			'excerpt'           => 'Innovative studio buildings incorporate central light wells, dynamic louvers, and spectrum-tuned ambient lighting to align office routines with natural human biological clocks.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">New commercial building codes and progressive design studios are abandoning fluorescent subterranean floorplans in favor of natural daylight corridors that synchronize hormonal sleep-wake cycles.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Employees in daylit test offices report measurable improvements in cognitive stamina, sustained focus, and self-reported sleep quality compared to counterparts working under static high-kelvin LEDs.</p>
<!-- /wp:paragraph -->',
		),

		// 19. Opinion 1
		array(
			'title'             => 'Why Modern Democracy Demands Public Trust in Primary Source Reporting',
			'slug'              => 'why-modern-democracy-demands-primary-source-reporting',
			'category'          => 'opinion',
			'tags'              => array( 'Journalism', 'Press Freedom', 'Democracy' ),
			'author'            => 'elena_rostova',
			'image'             => 'opinion-trust.png',
			'days_ago'          => 19,
			'excerpt'           => 'In an era overwhelmed by derivative commentary and machine-generated summaries, the survival of constitutional self-government rests on the rigorous labor of on-the-ground fact verification.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">The essential currency of a free society is not the volume of information in circulation, but the verifiable integrity of primary reporting conducted without fear, favor, or partisan allegiance.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">When newspapers retreat from courtrooms, city council chambers, and investigative archives, the vacuum is not left empty. It is inevitably occupied by manufactured grievance, speculative conjecture, and public cynicisms that corrode democratic institutions from within. Independent journalism must reaffirm its founding compact: to observe meticulously, corroborate relentlessly, and report the unvarnished truth.</p>
<!-- /wp:paragraph -->

<!-- wp:pullquote {"className":"is-style-asutsabo-editorial-pullquote"} -->
<figure class="wp-block-pullquote is-style-asutsabo-editorial-pullquote"><blockquote><p>"Without verified facts anchored in primary testimony, public debate ceases to be a search for wisdom and becomes merely a contest of volume."</p><cite>Elena Rostova</cite></blockquote></figure>
<!-- /wp:pullquote -->',
		),

		// 20. Opinion 2
		array(
			'title'             => 'The Illusion of Constant Frictionless Speed in Digital Culture',
			'slug'              => 'illusion-constant-frictionless-speed-digital-culture',
			'category'          => 'opinion',
			'tags'              => array( 'Philosophy', 'Technology', 'Society' ),
			'author'            => 'marcus_vance',
			'image'             => 'opinion-culture.png',
			'days_ago'          => 20,
			'excerpt'           => 'We have engineered tools that eliminate all latency, only to discover that wisdom, contemplation, and moral judgment require the very friction we so casually discarded.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">Every technological iteration of the past two decades has pursued a single dogma: the total elimination of friction. Yet in conquering latency, we have inadvertently diminished the cognitive pauses essential for contemplation.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">When thought is expected to be instantaneous, nuance is the first casualty. Deliberate prose, patient historical reflection, and thoughtful debate cannot survive in an ecosystem that treats a five-second pause as a commercial failure. Reclaiming our attention requires reintroducing intentional friction into our intellectual lives.</p>
<!-- /wp:paragraph -->',
		),

		// 21. Opinion 3
		array(
			'title'             => 'In Defense of Difficult Books in an Age of Instant Summaries',
			'slug'              => 'in-defense-of-difficult-books',
			'category'          => 'opinion',
			'tags'              => array( 'Literature', 'Criticism', 'Humanities' ),
			'author'            => 'priya_nair',
			'image'             => 'opinion-humanism.png',
			'days_ago'          => 21,
			'excerpt'           => 'Synthesizing complex literature down to bullet points strips prose of its true aesthetic power, moral ambivalence, and capacity to transform the reader.',
			'content'           => '<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
<p class="is-style-asutsabo-lead-paragraph">The modern appetite for executive book summaries promises mastery without surrender, offering the illusion of learning while stripping away the transformative struggle of authentic reading.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"hasDropCap":true} -->
<p class="has-drop-cap">Great literature does not merely deliver information to be efficiently digested; it reshapes the interior architecture of consciousness. When we bypass the cadence of complex sentences and the moral ambiguities of sprawling narratives, we sacrifice the profound aesthetic experience that only deep, unhurried immersion can provide.</p>
<!-- /wp:paragraph -->

<!-- wp:pullquote {"className":"is-style-asutsabo-editorial-pullquote"} -->
<figure class="wp-block-pullquote is-style-asutsabo-editorial-pullquote"><blockquote><p>"To reduce a novel to its plot points is to mistake the structural blueprint of a cathedral for the spiritual experience of standing beneath its vaults."</p><cite>Priya Nair</cite></blockquote></figure>
<!-- /wp:pullquote -->',
		),
	);
}

/**
 * Returns demo pages.
 *
 * @return array
 */
function asutsabo_get_demo_pages() {
	return array(
		array(
			'title'    => 'Home',
			'slug'     => 'home',
			'template' => 'front-page',
			'content'  => '',
		),
		array(
			'title'    => 'Latest News',
			'slug'     => 'news',
			'template' => 'home',
			'content'  => '<p>Chronological archive of all reporting, dispatches, and breaking news.</p>',
		),
		array(
			'title'    => 'About Unheard',
			'slug'     => 'about',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">Unheard was established with a singular conviction: that serious, nuanced reporting and honest critique are vital pillars of an informed society. We pursue facts without commercial compromise or political dogmatism.</p>
<hr class="wp-block-separator is-style-asutsabo-divider-thick" />
<div class="asutsabo-grid asutsabo-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;margin:2rem 0;">
	<div>
		<h3 class="is-style-asutsabo-section-label">Our Principles</h3>
		<p>We believe in verification before declaration. Our reporters work on the ground to investigate systemic issues, unearth overlooked stories, and challenge prevailing orthodoxy with evidence and intellect.</p>
	</div>
	<div>
		<h3 class="is-style-asutsabo-section-label">Editorial Independence</h3>
		<p>Our newsroom operates with total editorial autonomy. Neither commercial sponsors nor external partners influence our investigations, conclusions, or journalistic decisions.</p>
	</div>
</div>',
		),
		array(
			'title'    => 'Contact the Newsroom',
			'slug'     => 'contact',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">We welcome story tips, leaks of public interest, letters to the editor, and syndicate inquiries.</p>
<hr class="wp-block-separator is-style-asutsabo-divider-thick" />
<div class="asutsabo-grid asutsabo-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;margin:2rem 0;">
	<div>
		<h3 class="is-style-asutsabo-section-label">Confidential Tips</h3>
		<p>Have information that should be investigated? We protect confidential sources. Send encrypted correspondence via Signal or PGP-encrypted mail to our investigative team.</p>
		<p style="font-family:var(--wp--preset--font-family--mono, monospace);font-weight:700;">tips@unheard.me</p>
	</div>
	<div>
		<h3 class="is-style-asutsabo-section-label">Editorial Inquiries</h3>
		<p>For pitches, op-ed submissions, corrections, and general newsroom inquiries, please direct your communication to the relevant editorial desk.</p>
		<p style="font-family:var(--wp--preset--font-family--mono, monospace);font-weight:700;">editor@unheard.me</p>
	</div>
</div>',
		),
		array(
			'title'    => 'Editorial Standards & Code of Ethics',
			'slug'     => 'editorial-policy',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">Our journalism is guided by an unwavering commitment to truth, transparency, and public accountability.</p>
<hr class="wp-block-separator is-style-asutsabo-divider-thick" />
<h3 class="is-style-asutsabo-section-label">1. Verification &amp; Accuracy</h3>
<p>Every factual assertion published by Unheard is subject to rigorous corroboration. Our reporters seek primary documentation, on-the-record statements, and multiple corroborating sources before publication.</p>
<h3 class="is-style-asutsabo-section-label">2. Anonymous Sources</h3>
<p>Confidentiality is extended only when information of profound public interest cannot be obtained otherwise and the source faces genuine jeopardy. Anonymous sources must be vetted and approved by senior newsroom editors.</p>
<h3 class="is-style-asutsabo-section-label">3. Conflicts of Interest</h3>
<p>Reporters and editors must disclose any personal, political, or financial relationships that could present an actual or perceived conflict of interest. We accept no sponsored editorial coverage.</p>',
		),
		array(
			'title'    => 'Newsroom Leadership & Masthead',
			'slug'     => 'masthead',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">The editors, investigative correspondents, and critics responsible for Unheard dispatches.</p>
<hr class="wp-block-separator is-style-asutsabo-divider-thick" />
<h3 class="is-style-asutsabo-section-label">Editorial Leadership</h3>
<div class="asutsabo-grid asutsabo-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;margin:2rem 0;">
	<div>
		<p style="font-weight:700;margin-bottom:0.25rem;">Elena Rostova</p>
		<p class="is-style-asutsabo-metadata" style="margin-top:0;">Senior Investigative Correspondent</p>
		<p style="font-size:0.95rem;">Focuses on systemic accountability, public infrastructure, and government transparency.</p>
	</div>
	<div>
		<p style="font-weight:700;margin-bottom:0.25rem;">Marcus Vance</p>
		<p class="is-style-asutsabo-metadata" style="margin-top:0;">Chief Economics &amp; Policy Editor</p>
		<p style="font-size:0.95rem;">Covers macroeconomics, supply chain vulnerabilities, and geopolitical statecraft.</p>
	</div>
	<div>
		<p style="font-weight:700;margin-bottom:0.25rem;">Priya Nair</p>
		<p class="is-style-asutsabo-metadata" style="margin-top:0;">Cultural Critic &amp; Technology Columnist</p>
		<p style="font-size:0.95rem;">Writes on the intersection of digital networks, ethics, and contemporary society.</p>
	</div>
</div>',
		),
		array(
			'title'    => 'Corrections Policy & Public Record',
			'slug'     => 'corrections',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">Unheard is dedicated to publishing verified facts. When errors occur, we correct the record promptly, transparently, and unreservedly.</p>
<hr class="wp-block-separator is-style-asutsabo-divider-thick" />
<h3 class="is-style-asutsabo-section-label">How We Handle Corrections</h3>
<p>Substantive factual errors in articles are updated immediately in the text, accompanied by a clearly marked editorial correction note at the bottom or top of the piece detailing the date and nature of the revision.</p>
<h3 class="is-style-asutsabo-section-label">Requesting a Correction</h3>
<p>If you identify a factual error in our reporting, please contact the standards desk directly at <strong>corrections@unheard.me</strong> with the article URL, the specific passage, and supporting documentation.</p>',
		),
		array(
			'title'    => 'Advertise With Unheard',
			'slug'     => 'advertise',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">Connect with an influential, highly educated readership of policymakers, researchers, executives, cultural leaders, and engaged citizens.</p>
<hr class="wp-block-separator is-style-asutsabo-divider-thick" />
<div class="asutsabo-grid asutsabo-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;margin:2rem 0;">
	<div>
		<h3 class="is-style-asutsabo-section-label">Digital Display Placements</h3>
		<p>High-visibility, non-intrusive display sponsorships across desktop and mobile. Standard IAB leaderboard, medium rectangle, and half-page placements strictly separated from editorial copy.</p>
	</div>
	<div>
		<h3 class="is-style-asutsabo-section-label">Newsletter Sponsorship</h3>
		<p>Direct exposure in our morning briefing and weekly cultural dispatches delivered to verified engaged subscribers with industry-leading open rates.</p>
	</div>
</div>',
		),
		array(
			'title'    => 'Privacy Policy',
			'slug'     => 'privacy-policy',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">Unheard is committed to protecting the privacy of our readers and sources. We collect minimal telemetry necessary to deliver our journalism and never sell reader data to third-party commercial brokers.</p>
<h2>1. Data Minimization</h2>
<p>We do not employ cross-site tracking pixels or invasive behavioural analytics. Reader interaction metrics are aggregated and anonymized strictly for newsroom performance assessment.</p>
<h2>2. Source Protection</h2>
<p>Our servers maintain strict retention schedules for access logs, with unauthenticated IP records expunged every seven days to safeguard whistleblowers and confidential correspondence.</p>',
		),
		array(
			'title'    => 'Terms & Conditions',
			'slug'     => 'terms',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">These terms govern the use of Unheard digital publications and syndication services.</p>
<h2>Intellectual Property &amp; Fair Use</h2>
<p>All reporting, investigative photography, and cultural commentary published under the Unheard masthead are protected under international copyright law. Brief excerpts may be quoted with explicit attribution and direct hyperlink to the original dispatch.</p>',
		),
		array(
			'title'    => 'Editorial Disclaimer',
			'slug'     => 'disclaimer',
			'template' => 'page',
			'content'  => '<p class="is-style-asutsabo-lead-paragraph">Unheard publishes independent investigative journalism, cultural critique, and analytical commentary. All opinions expressed in bylined columns reflect the individual perspectives of the respective authors.</p>
<p>While our newsroom employs rigorous fact verification protocols across all reported stories, articles do not constitute legal, medical, or financial advisory services. Readers are encouraged to evaluate primary source documentation cited within our dispatches.</p>',
		),
	);
}

