<?php
/**
 * Asutsabo Demo Import Admin Interface.
 *
 * Renders the Appearance > Asutsabo Demo Import page and handles
 * administrative actions.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __FILE__ ) . '/class-asutsabo-demo-importer.php';

/**
 * Register Appearance submenu page.
 */
function asutsabo_register_demo_import_menu() {
	add_theme_page(
		__( 'Asutsabo Demo Import', 'asutsabo' ),
		__( 'Demo Import', 'asutsabo' ),
		'manage_options',
		'asutsabo-demo-import',
		'asutsabo_render_demo_import_page'
	);
}
add_action( 'admin_menu', 'asutsabo_register_demo_import_menu' );

/**
 * Admin notice suggesting demo import on fresh installation.
 */
function asutsabo_demo_import_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$screen = get_current_screen();
	if ( $screen && $screen->id === 'appearance_page_asutsabo-demo-import' ) {
		return;
	}

	if ( ! Asutsabo_Demo_Importer::is_imported() ) {
		$import_url = admin_url( 'themes.php?page=asutsabo-demo-import' );
		?>
		<div class="notice notice-info is-dismissible">
			<p>
				<strong><?php esc_html_e( 'Welcome to Asutsabo!', 'asutsabo' ); ?></strong>
				<?php esc_html_e( 'Transform your site into a fully populated digital newspaper in one click with our built-in demo content.', 'asutsabo' ); ?>
				<a href="<?php echo esc_url( $import_url ); ?>" class="button button-primary" style="margin-left:10px;">
					<?php esc_html_e( 'Import Demo Content', 'asutsabo' ); ?>
				</a>
			</p>
		</div>
		<?php
	}
}
add_action( 'admin_notices', 'asutsabo_demo_import_admin_notice' );

/**
 * Renders the Demo Import admin screen.
 */
function asutsabo_render_demo_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'asutsabo' ) );
	}

	$action_result = null;

	// Handle POST actions
	if ( isset( $_POST['asutsabo_action'] ) ) {
		check_admin_referer( 'asutsabo_demo_action', 'asutsabo_demo_nonce' );

		if ( $_POST['asutsabo_action'] === 'import' ) {
			$action_result = Asutsabo_Demo_Importer::run_import();
		} elseif ( $_POST['asutsabo_action'] === 'reset' ) {
			$action_result = Asutsabo_Demo_Importer::reset_demo_content();
		}
	}

	$is_imported = Asutsabo_Demo_Importer::is_imported();
	?>
	<div class="wrap asutsabo-demo-wrap" style="max-width:960px;margin-top:20px;">
		<div style="background:#ffffff;border:1px solid #ccd0d4;padding:30px;border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
			<div style="display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #141413;padding-bottom:15px;margin-bottom:25px;flex-wrap:wrap;gap:10px;">
				<div>
					<span style="font-family:sans-serif;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#94181e;"><?php esc_html_e( 'Editorial Theme Setup', 'asutsabo' ); ?></span>
					<h1 style="font-family:Georgia,serif;font-size:28px;font-weight:700;margin:5px 0 0 0;color:#141413;"><?php esc_html_e( 'Asutsabo One-Click Demo Import', 'asutsabo' ); ?></h1>
				</div>
				<div>
					<span style="background:#141413;color:#ffffff;padding:4px 10px;font-size:12px;font-weight:600;border-radius:2px;">v<?php echo esc_html( defined( 'ASUTSABO_VERSION' ) ? ASUTSABO_VERSION : '1.1.0' ); ?></span>
				</div>
			</div>

			<?php if ( $action_result ) : ?>
				<div class="notice notice-<?php echo $action_result['success'] ? 'success' : 'error'; ?> notice-alt" style="margin:20px 0;">
					<p><strong><?php echo esc_html( $action_result['message'] ); ?></strong></p>
					<?php if ( ! empty( $action_result['logs'] ) ) : ?>
						<ul style="list-style:disc;margin-left:25px;font-size:13px;">
							<?php foreach ( $action_result['logs'] as $log_line ) : ?>
								<li><?php echo esc_html( $log_line ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( $is_imported ) : ?>
				<div style="background:#f0f8f4;border-left:4px solid #46b450;padding:20px;margin-bottom:25px;">
					<h3 style="margin-top:0;color:#2e7d32;font-size:18px;">&check; <?php esc_html_e( 'Demo content has already been imported.', 'asutsabo' ); ?></h3>
					<p style="margin-bottom:15px;font-size:14px;line-height:1.5;"><?php esc_html_e( 'Your publication is populated with all editorial categories, demo articles, staff authors, essential pages, homepage builder sections, and navigation menus.', 'asutsabo' ); ?></p>
					<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="button button-primary button-hero" target="_blank">
							<?php esc_html_e( 'View Your Website', 'asutsabo' ); ?> &rarr;
						</a>
						<a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[panel]=asutsabo_homepage_builder_panel' ) ); ?>" class="button button-secondary button-hero">
							<?php esc_html_e( 'Customize Homepage Sections', 'asutsabo' ); ?>
						</a>
						<a href="<?php echo esc_url( admin_url( 'themes.php?page=asutsabo-homepage-builder' ) ); ?>" class="button button-secondary button-hero">
							<?php esc_html_e( 'Homepage Builder Screen', 'asutsabo' ); ?>
						</a>
					</div>
				</div>

				<div style="border-top:1px solid #eee;padding-top:20px;margin-top:25px;">
					<h4 style="color:#d63638;margin-bottom:10px;"><?php esc_html_e( 'Reset Demo Content', 'asutsabo' ); ?></h4>
					<p style="font-size:13px;color:#666;margin-bottom:15px;">
						<?php esc_html_e( 'Need a fresh start? This will safely remove only the demo posts, pages, and media created during the import, leaving your own articles completely untouched.', 'asutsabo' ); ?>
					</p>
					<form method="post" onsubmit="return confirm('Are you sure you want to reset all demo content? Your own original posts will not be affected.');">
						<?php wp_nonce_field( 'asutsabo_demo_action', 'asutsabo_demo_nonce' ); ?>
						<input type="hidden" name="asutsabo_action" value="reset">
						<input type="submit" class="button button-secondary" style="color:#d63638;border-color:#d63638;" value="<?php esc_attr_e( 'Reset Demo Content', 'asutsabo' ); ?>">
					</form>
				</div>
			<?php else : ?>
				<p style="font-size:15px;line-height:1.6;color:#333;">
					<?php esc_html_e( 'Importing the demo content will immediately set up a complete, professional digital newspaper environment on your site. No third-party plugins, page builders, or external subscriptions are required.', 'asutsabo' ); ?>
				</p>

				<div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr));gap:20px;margin:25px 0;">
					<div style="background:#f9f9f9;border:1px solid #e5e5e5;padding:15px 20px;border-radius:3px;">
						<h4 style="margin-top:0;font-size:14px;text-transform:uppercase;letter-spacing:0.5px;color:#141413;"><?php esc_html_e( 'What will be imported:', 'asutsabo' ); ?></h4>
						<ul style="list-style:disc;margin-left:20px;font-size:13px;line-height:1.6;color:#555;">
							<li><strong><?php esc_html_e( '14 Editorial Categories', 'asutsabo' ); ?></strong> (<?php esc_html_e( 'Latest News, Nagaland, India, Sports, Entertainment, Politics, Science & Tech, National, World, Business, Culture, Lifestyle, Opinion, Editor\'s Picks', 'asutsabo' ); ?>)</li>
							<li><strong><?php esc_html_e( '3 Staff Authors', 'asutsabo' ); ?></strong> <?php esc_html_e( 'with detailed newsroom bios and avatars', 'asutsabo' ); ?></li>
							<li><strong><?php esc_html_e( '48 Full Editorial Articles', 'asutsabo' ); ?></strong> <?php esc_html_e( 'with local featured images, badges & tags', 'asutsabo' ); ?></li>
							<li><strong><?php esc_html_e( '11 Essential Pages', 'asutsabo' ); ?></strong> (<?php esc_html_e( 'Home, Latest News, About, Contact, Standards, Masthead, Corrections, Advertise, Privacy, Terms, Disclaimer', 'asutsabo' ); ?>)</li>
						</ul>
					</div>

					<div style="background:#f9f9f9;border:1px solid #e5e5e5;padding:15px 20px;border-radius:3px;">
						<h4 style="margin-top:0;font-size:14px;text-transform:uppercase;letter-spacing:0.5px;color:#141413;"><?php esc_html_e( 'Automatic Configurations:', 'asutsabo' ); ?></h4>
						<ul style="list-style:disc;margin-left:20px;font-size:13px;line-height:1.6;color:#555;">
							<li><?php esc_html_e( 'Configures', 'asutsabo' ); ?> <strong><?php esc_html_e( 'Homepage Section Builder', 'asutsabo' ); ?></strong> <?php esc_html_e( 'with complete demo layout (Latest News, Nagaland, India, Sports, Entertainment, Politics, Science & Tech)', 'asutsabo' ); ?></li>
							<li><?php esc_html_e( 'Configures', 'asutsabo' ); ?> <strong><?php esc_html_e( 'Reading Settings', 'asutsabo' ); ?></strong> <?php esc_html_e( '(Front page displays Home, Posts page displays Latest News)', 'asutsabo' ); ?></li>
							<li><?php esc_html_e( 'Configures', 'asutsabo' ); ?> <strong><?php esc_html_e( 'Primary Navigation', 'asutsabo' ); ?></strong> <?php esc_html_e( 'with news categories in matching order', 'asutsabo' ); ?></li>
							<li><?php esc_html_e( 'Configures', 'asutsabo' ); ?> <strong><?php esc_html_e( 'Top Bar & Footer Navigation', 'asutsabo' ); ?></strong> <?php esc_html_e( 'with essential publication pages', 'asutsabo' ); ?></li>
							<li><?php esc_html_e( 'Zero duplicate homepage stories across sections', 'asutsabo' ); ?></li>
						</ul>
					</div>
				</div>

				<form method="post">
					<?php wp_nonce_field( 'asutsabo_demo_action', 'asutsabo_demo_nonce' ); ?>
					<input type="hidden" name="asutsabo_action" value="import">
					<p style="margin-top:25px;">
						<input type="submit" class="button button-primary button-hero" value="<?php esc_attr_e( 'Import Demo Content Now', 'asutsabo' ); ?>" style="font-size:16px;padding:10px 24px;">
					</p>
				</form>
			<?php endif; ?>
		</div>
	</div>
	<?php
}
