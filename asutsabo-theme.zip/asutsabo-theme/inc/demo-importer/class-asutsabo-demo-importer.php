<?php
/**
 * Asutsabo Demo Content Importer Engine.
 *
 * Implements a standalone, robust, zero-dependency demo importer using
 * WordPress core APIs. Handles categories, authors, local media attachments,
 * articles, pages, navigation, reading settings, and safe non-destructive reset.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __FILE__ ) . '/demo-data.php';

/**
 * Class Asutsabo_Demo_Importer
 */
class Asutsabo_Demo_Importer {

	/**
	 * Meta key used to identify demo content.
	 */
	const DEMO_META_KEY = '_asutsabo_demo_content';

	/**
	 * Check if demo content is currently imported.
	 *
	 * @return bool
	 */
	public static function is_imported() {
		return (bool) get_option( 'asutsabo_demo_imported', false );
	}

	/**
	 * Run the complete one-click demo import.
	 *
	 * @return array Status report with counts and logs.
	 */
	public static function run_import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'success' => false,
				'message' => __( 'Insufficient administrative permissions to run demo import.', 'asutsabo' ),
			);
		}

		// Prevent duplicate runs if already imported.
		if ( self::is_imported() ) {
			return array(
				'success' => false,
				'message' => __( 'Demo content has already been imported. Please reset demo content first if you wish to re-import.', 'asutsabo' ),
			);
		}

		$log = array();

		// 1. Import Categories
		$categories = asutsabo_get_demo_categories();
		$cat_map    = array(); // slug => term_id
		foreach ( $categories as $cat ) {
			$existing = get_category_by_slug( $cat['slug'] );
			if ( $existing && ! is_wp_error( $existing ) ) {
				if ( $existing->name !== $cat['name'] ) {
					wp_update_term( (int) $existing->term_id, 'category', array( 'name' => $cat['name'] ) );
				}
				$cat_map[ $cat['slug'] ] = (int) $existing->term_id;
			} else {
				$inserted = wp_insert_term(
					$cat['name'],
					'category',
					array(
						'slug'        => $cat['slug'],
						'description' => $cat['description'],
					)
				);
				if ( ! is_wp_error( $inserted ) ) {
					$term_id = (int) $inserted['term_id'];
					update_term_meta( $term_id, self::DEMO_META_KEY, 1 );
					$cat_map[ $cat['slug'] ] = $term_id;
				}
			}
		}
		$log[] = sprintf( 'Processed %d editorial categories.', count( $cat_map ) );

		// Assets directory
		$images_dir = dirname( __FILE__ ) . '/assets/images/';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// 2. Import Authors
		$authors    = asutsabo_get_demo_authors();
		$author_map = array(); // username => user_id
		foreach ( $authors as $author_data ) {
			$user_id = username_exists( $author_data['user_login'] );
			if ( ! $user_id ) {
				$user_id = wp_insert_user(
					array(
						'user_login'   => $author_data['user_login'],
						'user_pass'    => wp_generate_password( 24 ),
						'user_email'   => $author_data['user_email'],
						'display_name' => $author_data['display_name'],
						'first_name'   => $author_data['first_name'],
						'last_name'    => $author_data['last_name'],
						'description'  => $author_data['description'],
						'role'         => 'author',
					)
				);
			}

			if ( ! is_wp_error( $user_id ) && $user_id > 0 ) {
				update_user_meta( $user_id, self::DEMO_META_KEY, 1 );

				// Upload and assign custom avatar
				if ( ! empty( $author_data['avatar'] ) && file_exists( $images_dir . $author_data['avatar'] ) ) {
					$avatar_upload = wp_upload_bits( $author_data['avatar'], null, file_get_contents( $images_dir . $author_data['avatar'] ) );
					if ( empty( $avatar_upload['error'] ) ) {
						update_user_meta( $user_id, 'asutsabo_avatar_url', $avatar_upload['url'] );
					}
				}

				$author_map[ $author_data['user_login'] ] = (int) $user_id;
			}
		}
		$log[] = sprintf( 'Processed %d staff authors.', count( $author_map ) );

		// Default author fallback if any user creation was skipped
		$default_author_id = get_current_user_id();

		// 3. Import Media & Articles
		$articles       = asutsabo_get_demo_articles();
		$image_cache    = array(); // filename => attachment_id
		$imported_posts = 0;

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$images_dir = dirname( __FILE__ ) . '/assets/images/';

		foreach ( $articles as $article ) {
			// Check if post already exists
			$existing_post = get_page_by_path( $article['slug'], OBJECT, 'post' );
			if ( $existing_post ) {
				continue;
			}

			// Handle local featured image
			$attachment_id = 0;
			$image_name    = $article['image'];

			if ( ! empty( $image_name ) && file_exists( $images_dir . $image_name ) ) {
				if ( isset( $image_cache[ $image_name ] ) ) {
					$attachment_id = $image_cache[ $image_name ];
				} else {
					$file_path = $images_dir . $image_name;
					$file_type = wp_check_filetype( $image_name, null );

					// Copy to WordPress uploads directory
					$upload = wp_upload_bits( $image_name, null, file_get_contents( $file_path ) );
					if ( empty( $upload['error'] ) ) {
						$attachment = array(
							'guid'           => $upload['url'],
							'post_mime_type' => $file_type['type'] ? $file_type['type'] : 'image/png',
							'post_title'     => preg_replace( '/\.[^.]+$/', '', $image_name ),
							'post_content'   => '',
							'post_status'    => 'inherit',
						);

						$attachment_id = wp_insert_attachment( $attachment, $upload['file'] );
						if ( ! is_wp_error( $attachment_id ) && $attachment_id > 0 ) {
							$attach_data = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
							wp_update_attachment_metadata( $attachment_id, $attach_data );
							update_post_meta( $attachment_id, self::DEMO_META_KEY, 1 );
							$image_cache[ $image_name ] = $attachment_id;
						}
					}
				}
			}

			// Determine post author ID
			$author_id = $default_author_id;
			if ( ! empty( $article['author'] ) && isset( $author_map[ $article['author'] ] ) ) {
				$author_id = $author_map[ $article['author'] ];
			}

			// Categories
			$post_cats = array();
			if ( ! empty( $article['category'] ) && isset( $cat_map[ $article['category'] ] ) ) {
				$post_cats[] = $cat_map[ $article['category'] ];
			}
			if ( ! empty( $article['secondary_cat'] ) && isset( $cat_map[ $article['secondary_cat'] ] ) ) {
				$post_cats[] = $cat_map[ $article['secondary_cat'] ];
			}

			// Calculated date
			$days_ago  = isset( $article['days_ago'] ) ? (int) $article['days_ago'] : 1;
			$post_date = gmdate( 'Y-m-d H:i:s', time() - ( $days_ago * 86400 ) );

			$post_data = array(
				'post_title'    => $article['title'],
				'post_name'     => $article['slug'],
				'post_excerpt'  => $article['excerpt'],
				'post_content'  => $article['content'],
				'post_status'   => 'publish',
				'post_author'   => $author_id,
				'post_date'     => $post_date,
				'post_date_gmt' => $post_date,
				'post_type'     => 'post',
				'post_category' => $post_cats,
				'tags_input'    => $article['tags'],
			);

			$post_id = wp_insert_post( $post_data );
			if ( ! is_wp_error( $post_id ) && $post_id > 0 ) {
				update_post_meta( $post_id, self::DEMO_META_KEY, 1 );

				if ( ( ! empty( $article['secondary_cat'] ) && $article['secondary_cat'] === 'editors-picks' ) || ! empty( $article['editors_pick'] ) ) {
					update_post_meta( $post_id, '_asutsabo_editors_pick', 1 );
				}

				if ( ! empty( $article['badge'] ) ) {
					update_post_meta( $post_id, '_asutsabo_badge', sanitize_text_field( $article['badge'] ) );
				}

				if ( $attachment_id > 0 ) {
					set_post_thumbnail( $post_id, $attachment_id );
					update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $article['title'] ) );
				}

				$imported_posts++;
			}
		}
		$log[] = sprintf( 'Imported %d full editorial articles with local featured images.', $imported_posts );

		// 4. Import Essential Pages
		$pages         = asutsabo_get_demo_pages();
		$home_page_id  = 0;
		$news_page_id  = 0;
		$imported_pages = 0;

		foreach ( $pages as $p ) {
			$existing_page = get_page_by_path( $p['slug'], OBJECT, 'page' );
			$page_id       = 0;

			if ( $existing_page ) {
				$page_id = $existing_page->ID;
			} else {
				$page_data = array(
					'post_title'   => $p['title'],
					'post_name'    => $p['slug'],
					'post_content' => $p['content'],
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_author'  => $default_author_id,
				);

				$page_id = wp_insert_post( $page_data );
				if ( ! is_wp_error( $page_id ) && $page_id > 0 ) {
					update_post_meta( $page_id, self::DEMO_META_KEY, 1 );
					if ( ! empty( $p['template'] ) ) {
						update_post_meta( $page_id, '_wp_page_template', $p['template'] );
					}
					$imported_pages++;
				}
			}

			if ( $p['slug'] === 'home' ) {
				$home_page_id = $page_id;
			} elseif ( $p['slug'] === 'news' ) {
				$news_page_id = $page_id;
			}
		}
		$log[] = sprintf( 'Imported %d essential publication pages.', $imported_pages );

		// 5. Configure Reading Settings
		if ( $home_page_id > 0 ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $home_page_id );
			if ( $news_page_id > 0 ) {
				update_option( 'page_for_posts', $news_page_id );
			}
			$log[] = 'Configured Reading settings (Front page displays Home, Posts page displays Latest News).';
		}

		// 6. Create Navigation Menus (Block Navigation wp_navigation post type & classic menus)
		self::create_navigation_menus( $cat_map );
		$log[] = 'Created responsive primary and footer news navigation menus.';

		// 7. Configure Homepage Section Builder with demo layout matching screenshots
		if ( function_exists( 'asutsabo_get_default_homepage_sections' ) ) {
			update_option( 'asutsabo_homepage_sections', asutsabo_get_default_homepage_sections() );
			$log[] = 'Configured Homepage Section Builder layout matching demo front page.';
		}

		// Mark demo as imported
		update_option( 'asutsabo_demo_imported', true );
		update_option( 'asutsabo_demo_import_time', current_time( 'mysql' ) );

		return array(
			'success' => true,
			'message' => __( 'Demo content successfully imported! Your newspaper website is now fully populated.', 'asutsabo' ),
			'logs'    => $log,
		);
	}

	/**
	 * Create classic navigation menus and assign to theme locations.
	 *
	 * @param array $cat_map Category slug to ID map.
	 */
	private static function create_navigation_menus( $cat_map ) {
		$home_url = home_url( '/' );

		// 1. Primary Navigation Menu
		$main_menu_name = 'Asutsabo Primary Navigation';
		$main_menu_obj  = wp_get_nav_menu_object( $main_menu_name );
		$main_menu_id   = $main_menu_obj ? $main_menu_obj->term_id : 0;

		if ( ! $main_menu_id ) {
			$main_menu_id = wp_create_nav_menu( $main_menu_name );
		}

		if ( ! is_wp_error( $main_menu_id ) && $main_menu_id > 0 ) {
			update_term_meta( $main_menu_id, self::DEMO_META_KEY, 1 );

			// Add Home item
			wp_update_nav_menu_item(
				$main_menu_id,
				0,
				array(
					'menu-item-title'   => __( 'Home', 'asutsabo' ),
					'menu-item-url'     => $home_url,
					'menu-item-status'  => 'publish',
					'menu-item-type'    => 'custom',
				)
			);

			// Add categories in editorial order matching demo layout
			$categories_order = array( 'latest-news', 'nagaland', 'india', 'sports', 'entertainment', 'politics', 'technology', 'national', 'world', 'business', 'culture', 'opinion' );
			foreach ( $categories_order as $slug ) {
				if ( isset( $cat_map[ $slug ] ) ) {
					$cat_id  = (int) $cat_map[ $slug ];
					$cat_obj = get_category( $cat_id );
					$label   = $cat_obj ? $cat_obj->name : ucfirst( $slug );

					wp_update_nav_menu_item(
						$main_menu_id,
						0,
						array(
							'menu-item-title'     => $label,
							'menu-item-object-id' => $cat_id,
							'menu-item-object'    => 'category',
							'menu-item-type'      => 'taxonomy',
							'menu-item-status'    => 'publish',
						)
					);
				}
			}
		}

		// 2. Top Bar Navigation Menu
		$top_menu_name = 'Asutsabo Top Bar';
		$top_menu_obj  = wp_get_nav_menu_object( $top_menu_name );
		$top_menu_id   = $top_menu_obj ? $top_menu_obj->term_id : 0;

		if ( ! $top_menu_id ) {
			$top_menu_id = wp_create_nav_menu( $top_menu_name );
		}

		if ( ! is_wp_error( $top_menu_id ) && $top_menu_id > 0 ) {
			update_term_meta( $top_menu_id, self::DEMO_META_KEY, 1 );

			$top_pages = array( 'about' => 'About', 'editorial-policy' => 'Standards', 'contact' => 'Contact' );
			foreach ( $top_pages as $slug => $label ) {
				$page = get_page_by_path( $slug );
				if ( $page ) {
					wp_update_nav_menu_item(
						$top_menu_id,
						0,
						array(
							'menu-item-title'     => $label,
							'menu-item-object-id' => $page->ID,
							'menu-item-object'    => 'page',
							'menu-item-type'      => 'post_type',
							'menu-item-status'    => 'publish',
						)
					);
				}
			}
		}

		// 3. Footer Navigation Menu
		$footer_menu_name = 'Asutsabo Footer Navigation';
		$footer_menu_obj  = wp_get_nav_menu_object( $footer_menu_name );
		$footer_menu_id   = $footer_menu_obj ? $footer_menu_obj->term_id : 0;

		if ( ! $footer_menu_id ) {
			$footer_menu_id = wp_create_nav_menu( $footer_menu_name );
		}

		if ( ! is_wp_error( $footer_menu_id ) && $footer_menu_id > 0 ) {
			update_term_meta( $footer_menu_id, self::DEMO_META_KEY, 1 );

			$footer_pages = array(
				'about'            => 'About',
				'contact'          => 'Contact',
				'editorial-policy' => 'Editorial Policy',
				'masthead'         => 'Masthead',
				'corrections'      => 'Corrections',
				'advertise'        => 'Advertise',
				'privacy-policy'   => 'Privacy',
				'terms'            => 'Terms',
				'disclaimer'       => 'Disclaimer',
			);

			foreach ( $footer_pages as $slug => $label ) {
				$page = get_page_by_path( $slug );
				if ( $page ) {
					wp_update_nav_menu_item(
						$footer_menu_id,
						0,
						array(
							'menu-item-title'     => $label,
							'menu-item-object-id' => $page->ID,
							'menu-item-object'    => 'page',
							'menu-item-type'      => 'post_type',
							'menu-item-status'    => 'publish',
						)
					);
				}
			}
		}

		// 4. Assign Classic Nav Menu Locations
		$locations = get_theme_mod( 'nav_menu_locations', array() );
		if ( ! is_array( $locations ) ) {
			$locations = array();
		}
		if ( $main_menu_id > 0 ) {
			$locations['primary'] = (int) $main_menu_id;
		}
		if ( $top_menu_id > 0 ) {
			$locations['top-bar'] = (int) $top_menu_id;
		}
		if ( $footer_menu_id > 0 ) {
			$locations['footer'] = (int) $footer_menu_id;
		}
		set_theme_mod( 'nav_menu_locations', $locations );

		// Save menu IDs in options for clean reset
		update_option(
			'asutsabo_demo_menus',
			array(
				'primary' => (int) $main_menu_id,
				'top-bar' => (int) $top_menu_id,
				'footer'  => (int) $footer_menu_id,
			)
		);
	}

	/**
	 * Reset/remove all demo content safely without touching user content.
	 *
	 * @return array
	 */
	public static function reset_demo_content() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'success' => false,
				'message' => __( 'Insufficient administrative permissions to reset demo content.', 'asutsabo' ),
			);
		}

		$deleted_posts = 0;
		$deleted_media = 0;

		// 1. Delete Demo Posts and Pages
		$demo_posts = get_posts(
			array(
				'post_type'      => array( 'post', 'page' ),
				'post_status'    => 'any',
				'numberposts'    => -1,
				'meta_key'       => self::DEMO_META_KEY,
				'meta_value'     => 1,
			)
		);

		foreach ( $demo_posts as $p ) {
			wp_delete_post( $p->ID, true );
			$deleted_posts++;
		}

		// 2. Delete Demo Media
		$demo_media = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'numberposts'    => -1,
				'meta_key'       => self::DEMO_META_KEY,
				'meta_value'     => 1,
			)
		);

		foreach ( $demo_media as $m ) {
			wp_delete_attachment( $m->ID, true );
			$deleted_media++;
		}

		// 3. Delete Demo Classic Navigation Menus
		$demo_menus = get_option( 'asutsabo_demo_menus', array() );
		if ( ! empty( $demo_menus ) && is_array( $demo_menus ) ) {
			foreach ( $demo_menus as $menu_id ) {
				if ( $menu_id > 0 ) {
					wp_delete_nav_menu( (int) $menu_id );
				}
			}
		}
		delete_option( 'asutsabo_demo_menus' );

		// Clear menu locations
		$locations = get_theme_mod( 'nav_menu_locations', array() );
		if ( is_array( $locations ) ) {
			unset( $locations['primary'], $locations['top-bar'], $locations['footer'] );
			set_theme_mod( 'nav_menu_locations', $locations );
		}

		// 4. Reset Reading Settings
		update_option( 'show_on_front', 'posts' );
		delete_option( 'page_on_front' );
		delete_option( 'page_for_posts' );

		// 5. Reset Options
		delete_option( 'asutsabo_homepage_sections' );
		delete_option( 'asutsabo_demo_imported' );
		delete_option( 'asutsabo_demo_import_time' );

		return array(
			'success' => true,
			'message' => sprintf(
				/* translators: 1: number of posts, 2: number of media items */
				__( 'Demo content safely reset. Removed %1$d posts/pages and %2$d media attachments.', 'asutsabo' ),
				$deleted_posts,
				$deleted_media
			),
		);
	}
}
