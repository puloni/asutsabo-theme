<?php
/**
 * Asutsabo Theme Customizer Definitions & Controls.
 *
 * Provides comprehensive visual customization controls for Header,
 * Homepage Magazine Sections, and Footer with Selective Refresh support.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize checkbox inputs.
 *
 * @param mixed $checked Input value.
 * @return bool
 */
function asutsabo_sanitize_checkbox( $checked ) {
	return ( ( isset( $checked ) && true == $checked ) ? true : false );
}

/**
 * Sanitize category slug.
 *
 * @param string $input Category slug input.
 * @return string
 */
function asutsabo_sanitize_category_slug( $input ) {
	return sanitize_title( $input );
}

/**
 * Sanitize site title display mode.
 *
 * @param string $input Display choice.
 * @return string
 */
function asutsabo_sanitize_site_title_display( $input ) {
	$valid = array( 'all', 'logo_tagline', 'title_tagline', 'logo_only', 'title_only', 'custom' );
	if ( in_array( $input, $valid, true ) ) {
		return $input;
	}
	return 'all';
}

/**
 * Helper to retrieve category choices for select dropdowns.
 *
 * @return array Category choices mapping slug => display name.
 */
function asutsabo_get_category_choices() {
	$choices = array(
		'' => esc_html__( '&mdash; All / Recent Posts &mdash;', 'asutsabo' ),
	);

	$categories = get_categories(
		array(
			'hide_empty' => false,
			'orderby'    => 'name',
			'order'      => 'ASC',
		)
	);

	if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
		foreach ( $categories as $cat ) {
			$choices[ $cat->slug ] = sprintf( '%s (%d)', $cat->name, $cat->count );
		}
	}

	return $choices;
}

if ( class_exists( 'WP_Customize_Control' ) ) {
	/**
	 * Customizer Control for the Master Homepage Sections Builder.
	 */
	class Asutsabo_Homepage_Builder_Control extends WP_Customize_Control {
		public $type = 'asutsabo_homepage_builder';

		public function render_content() {
			$sections          = function_exists( 'asutsabo_get_homepage_sections' ) ? asutsabo_get_homepage_sections() : array();
			$available_layouts = function_exists( 'asutsabo_get_available_layouts' ) ? asutsabo_get_available_layouts() : array();
			$category_choices  = function_exists( 'asutsabo_get_category_choices' ) ? asutsabo_get_category_choices() : array();
			?>
			<div class="asutsabo-hb-manager-wrap" id="asutsabo-hb-manager-wrap">
				<div class="asutsabo-hb-top-bar">
					<button type="button" class="button button-primary asutsabo-hb-add-section-btn">+ <?php esc_html_e( 'Add Homepage Section', 'asutsabo' ); ?></button>
					<div class="asutsabo-hb-expand-collapse-links">
						<button type="button" class="button button-secondary asutsabo-hb-expand-all"><?php esc_html_e( 'Expand All', 'asutsabo' ); ?></button>
						<button type="button" class="button button-secondary asutsabo-hb-collapse-all"><?php esc_html_e( 'Collapse All', 'asutsabo' ); ?></button>
					</div>
				</div>

				<div class="asutsabo-hb-cards-container" id="asutsabo-hb-cards-container">
					<?php
					$order_idx = 1;
					foreach ( $sections as $sec_id => $sec ) :
						$enabled     = ! empty( $sec['enabled'] );
						$title       = ! empty( $sec['title'] ) ? $sec['title'] : '';
						$layout      = ! empty( $sec['layout'] ) ? $sec['layout'] : 'feature-list';
						$layout_name = isset( $available_layouts[ $layout ] ) ? $available_layouts[ $layout ] : $layout;
						$source      = ! empty( $sec['source'] ) ? $sec['source'] : 'category';
						$count       = isset( $sec['count'] ) ? absint( $sec['count'] ) : 4;
						$show_title  = ! isset( $sec['show_title'] ) || ! empty( $sec['show_title'] );
						$show_desc   = ! empty( $sec['show_desc'] );
						$show_va     = ! isset( $sec['show_view_all'] ) || ! empty( $sec['show_view_all'] );
						$va_text     = ! empty( $sec['view_all_text'] ) ? $sec['view_all_text'] : __( 'View all', 'asutsabo' );
						$va_url      = ! empty( $sec['view_all_url'] ) ? $sec['view_all_url'] : '';
						?>
						<div class="asutsabo-hb-card <?php echo $enabled ? '' : 'is-disabled'; ?>" data-id="<?php echo esc_attr( $sec_id ); ?>">
							<div class="asutsabo-hb-card-header">
								<span class="asutsabo-hb-drag-handle dashicons dashicons-menu" title="<?php esc_attr_e( 'Drag to reorder', 'asutsabo' ); ?>"></span>
								<label class="asutsabo-hb-toggle-switch" title="<?php esc_attr_e( 'Show / Hide Section', 'asutsabo' ); ?>">
									<input type="checkbox" class="asutsabo-hb-field asutsabo-hb-enabled-toggle" data-key="enabled" <?php checked( $enabled ); ?> />
									<span class="asutsabo-hb-slider"></span>
								</label>
								<span class="asutsabo-hb-card-title-text"><?php echo esc_html( ! empty( $title ) ? $title : __( '(Untitled Section)', 'asutsabo' ) ); ?></span>
								<span class="asutsabo-hb-layout-badge"><?php echo esc_html( $layout_name ); ?></span>
								<button type="button" class="asutsabo-hb-btn-action asutsabo-hb-move-up dashicons dashicons-arrow-up-alt2" title="<?php esc_attr_e( 'Move Up', 'asutsabo' ); ?>"></button>
								<button type="button" class="asutsabo-hb-btn-action asutsabo-hb-move-down dashicons dashicons-arrow-down-alt2" title="<?php esc_attr_e( 'Move Down', 'asutsabo' ); ?>"></button>
								<button type="button" class="asutsabo-hb-btn-action asutsabo-hb-duplicate dashicons dashicons-admin-page" title="<?php esc_attr_e( 'Duplicate Section', 'asutsabo' ); ?>"></button>
								<button type="button" class="asutsabo-hb-btn-action asutsabo-hb-delete dashicons dashicons-trash" title="<?php esc_attr_e( 'Delete Section', 'asutsabo' ); ?>"></button>
								<button type="button" class="asutsabo-hb-btn-action asutsabo-hb-expand-btn dashicons dashicons-arrow-down" title="<?php esc_attr_e( 'Expand / Collapse', 'asutsabo' ); ?>"></button>
							</div>

							<div class="asutsabo-hb-card-body" style="display:none;">
								<!-- Heading -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-label"><?php esc_html_e( 'Section Heading / Title', 'asutsabo' ); ?></label>
									<input type="text" class="asutsabo-hb-field asutsabo-hb-title-input" data-key="title" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php esc_attr_e( 'Leave blank or enter title...', 'asutsabo' ); ?>" />
									<label class="asutsabo-hb-checkbox-label">
										<input type="checkbox" class="asutsabo-hb-field" data-key="show_title" <?php checked( $show_title ); ?> />
										<?php esc_html_e( 'Display Section Heading on Homepage', 'asutsabo' ); ?>
									</label>
								</div>

								<!-- Subtitle / Description -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-checkbox-label">
										<input type="checkbox" class="asutsabo-hb-field asutsabo-hb-toggle-desc" data-key="show_desc" <?php checked( $show_desc ); ?> />
										<?php esc_html_e( 'Enable Short Description / Subtitle', 'asutsabo' ); ?>
									</label>
									<div class="asutsabo-hb-desc-wrap" style="<?php echo $show_desc ? '' : 'display:none;'; ?>">
										<textarea class="asutsabo-hb-field" data-key="description" rows="2" placeholder="<?php esc_attr_e( 'Introductory sentence or description below heading...', 'asutsabo' ); ?>"><?php echo esc_textarea( $sec['description'] ?? '' ); ?></textarea>
									</div>
								</div>

								<!-- View All Button -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-checkbox-label">
										<input type="checkbox" class="asutsabo-hb-field asutsabo-hb-toggle-va" data-key="show_view_all" <?php checked( $show_va ); ?> />
										<?php esc_html_e( 'Enable "View All" Button', 'asutsabo' ); ?>
									</label>
									<div class="asutsabo-hb-va-wrap" style="<?php echo $show_va ? '' : 'display:none;'; ?>">
										<input type="text" class="asutsabo-hb-field" data-key="view_all_text" value="<?php echo esc_attr( $va_text ); ?>" placeholder="<?php esc_attr_e( 'Button Text (e.g. View all)', 'asutsabo' ); ?>" />
										<input type="text" class="asutsabo-hb-field" data-key="view_all_url" value="<?php echo esc_attr( $va_url ); ?>" placeholder="<?php esc_attr_e( 'Custom URL (optional, auto-uses category URL if blank)', 'asutsabo' ); ?>" style="margin-top:4px;" />
									</div>
								</div>

								<!-- Post Source -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-label"><?php esc_html_e( 'Post Source', 'asutsabo' ); ?></label>
									<select class="asutsabo-hb-field asutsabo-hb-source-select" data-key="source">
										<option value="latest" <?php selected( $source, 'latest' ); ?>><?php esc_html_e( 'Latest posts (All categories)', 'asutsabo' ); ?></option>
										<option value="category" <?php selected( $source, 'category' ); ?>><?php esc_html_e( 'Posts from a selected category', 'asutsabo' ); ?></option>
										<option value="categories" <?php selected( $source, 'categories' ); ?>><?php esc_html_e( 'Posts from multiple categories', 'asutsabo' ); ?></option>
										<option value="tags" <?php selected( $source, 'tags' ); ?>><?php esc_html_e( 'Posts from selected tags', 'asutsabo' ); ?></option>
										<option value="manual" <?php selected( $source, 'manual' ); ?>><?php esc_html_e( 'Manually selected post IDs', 'asutsabo' ); ?></option>
									</select>

									<!-- Single Category -->
									<div class="asutsabo-hb-source-conditional asutsabo-hb-source-cat" style="<?php echo ( 'category' === $source || empty( $source ) ) ? '' : 'display:none;'; ?>">
										<label class="asutsabo-hb-sublabel"><?php esc_html_e( 'Select Category', 'asutsabo' ); ?></label>
										<select class="asutsabo-hb-field" data-key="category">
											<?php foreach ( $category_choices as $c_slug => $c_name ) : ?>
												<option value="<?php echo esc_attr( $c_slug ); ?>" <?php selected( $sec['category'] ?? '', $c_slug ); ?>><?php echo esc_html( $c_name ); ?></option>
											<?php endforeach; ?>
										</select>
									</div>

									<!-- Multiple Categories -->
									<div class="asutsabo-hb-source-conditional asutsabo-hb-source-multi" style="<?php echo 'categories' === $source ? '' : 'display:none;'; ?>">
										<label class="asutsabo-hb-sublabel"><?php esc_html_e( 'Category Slugs (comma-separated)', 'asutsabo' ); ?></label>
										<input type="text" class="asutsabo-hb-field" data-key="categories" value="<?php echo esc_attr( is_array( $sec['categories'] ?? '' ) ? implode( ', ', $sec['categories'] ) : ( $sec['categories'] ?? '' ) ); ?>" placeholder="e.g. nagaland, national, sports" />
									</div>

									<!-- Tags -->
									<div class="asutsabo-hb-source-conditional asutsabo-hb-source-tags" style="<?php echo 'tags' === $source ? '' : 'display:none;'; ?>">
										<label class="asutsabo-hb-sublabel"><?php esc_html_e( 'Tag Slugs (comma-separated)', 'asutsabo' ); ?></label>
										<input type="text" class="asutsabo-hb-field" data-key="tags" value="<?php echo esc_attr( is_array( $sec['tags'] ?? '' ) ? implode( ', ', $sec['tags'] ) : ( $sec['tags'] ?? '' ) ); ?>" placeholder="e.g. breaking, special-report" />
									</div>

									<!-- Manual Post IDs -->
									<div class="asutsabo-hb-source-conditional asutsabo-hb-source-manual" style="<?php echo 'manual' === $source ? '' : 'display:none;'; ?>">
										<label class="asutsabo-hb-sublabel"><?php esc_html_e( 'Post IDs (comma-separated, in display order)', 'asutsabo' ); ?></label>
										<input type="text" class="asutsabo-hb-field" data-key="manual_ids" value="<?php echo esc_attr( is_array( $sec['manual_ids'] ?? '' ) ? implode( ', ', $sec['manual_ids'] ) : ( $sec['manual_ids'] ?? '' ) ); ?>" placeholder="e.g. 102, 105, 98" />
									</div>
								</div>

								<!-- Number of Posts -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-label"><?php esc_html_e( 'Number of Posts', 'asutsabo' ); ?></label>
									<?php $preset_counts = array( 1, 2, 3, 4, 5, 6, 8, 10, 12 ); ?>
									<select class="asutsabo-hb-field asutsabo-hb-count-select" data-key="count">
										<?php foreach ( $preset_counts as $pc ) : ?>
											<option value="<?php echo esc_attr( $pc ); ?>" <?php selected( $count, $pc ); ?>><?php echo esc_html( $pc ); ?></option>
										<?php endforeach; ?>
										<option value="custom" <?php selected( ! in_array( $count, $preset_counts, true ) ); ?>><?php esc_html_e( 'Custom Number...', 'asutsabo' ); ?></option>
									</select>
									<input type="number" class="asutsabo-hb-field asutsabo-hb-count-custom" data-key="count_custom" min="1" max="50" style="<?php echo in_array( $count, $preset_counts, true ) ? 'display:none;' : ''; ?>" value="<?php echo esc_attr( $count ); ?>" />
								</div>

								<!-- Layout Selector -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-label"><?php esc_html_e( 'Layout Type', 'asutsabo' ); ?></label>
									<select class="asutsabo-hb-field asutsabo-hb-layout-select" data-key="layout">
										<?php foreach ( $available_layouts as $l_key => $l_label ) : ?>
											<option value="<?php echo esc_attr( $l_key ); ?>" <?php selected( $layout, $l_key ); ?>><?php echo esc_html( $l_label ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>

								<!-- Grid Contextual Options -->
								<?php
								$is_grid = in_array( $layout, array( 'grid', 'grid-3', 'grid-4', 'cards-2' ), true );
								$cols    = isset( $sec['columns'] ) ? absint( $sec['columns'] ) : ( 'grid-4' === $layout ? 4 : ( 'grid-3' === $layout ? 3 : 2 ) );
								$aspect  = ! empty( $sec['aspect_ratio'] ) ? $sec['aspect_ratio'] : '16-9';
								?>
								<div class="asutsabo-hb-opt-grid" style="<?php echo $is_grid ? '' : 'display:none;'; ?>">
									<div class="asutsabo-hb-field-group">
										<label class="asutsabo-hb-label"><?php esc_html_e( 'Grid Columns', 'asutsabo' ); ?></label>
										<select class="asutsabo-hb-field" data-key="columns">
											<option value="2" <?php selected( $cols, 2 ); ?>><?php esc_html_e( '2 Columns', 'asutsabo' ); ?></option>
											<option value="3" <?php selected( $cols, 3 ); ?>><?php esc_html_e( '3 Columns', 'asutsabo' ); ?></option>
											<option value="4" <?php selected( $cols, 4 ); ?>><?php esc_html_e( '4 Columns', 'asutsabo' ); ?></option>
										</select>
									</div>
									<div class="asutsabo-hb-field-group">
										<label class="asutsabo-hb-label"><?php esc_html_e( 'Image Aspect Ratio', 'asutsabo' ); ?></label>
										<select class="asutsabo-hb-field" data-key="aspect_ratio">
											<option value="16-9" <?php selected( $aspect, '16-9' ); ?>><?php esc_html_e( '16:9 Landscape', 'asutsabo' ); ?></option>
											<option value="3-2" <?php selected( $aspect, '3-2' ); ?>><?php esc_html_e( '3:2 Classic', 'asutsabo' ); ?></option>
											<option value="4-3" <?php selected( $aspect, '4-3' ); ?>><?php esc_html_e( '4:3 Standard', 'asutsabo' ); ?></option>
											<option value="1-1" <?php selected( $aspect, '1-1' ); ?>><?php esc_html_e( '1:1 Square', 'asutsabo' ); ?></option>
										</select>
									</div>
								</div>

								<!-- Carousel Contextual Options -->
								<?php $is_carousel = ( 'feature-slider' === $layout ); ?>
								<div class="asutsabo-hb-opt-carousel" style="<?php echo $is_carousel ? '' : 'display:none;'; ?>">
									<div class="asutsabo-hb-field-group">
										<label class="asutsabo-hb-checkbox-label">
											<input type="checkbox" class="asutsabo-hb-field" data-key="carousel_autoplay" <?php checked( ! empty( $sec['carousel_autoplay'] ) ); ?> />
											<?php esc_html_e( 'Autoplay Slides', 'asutsabo' ); ?>
										</label>
									</div>
									<div class="asutsabo-hb-field-group">
										<label class="asutsabo-hb-label"><?php esc_html_e( 'Autoplay Speed (ms)', 'asutsabo' ); ?></label>
										<input type="number" class="asutsabo-hb-field" data-key="carousel_speed" min="1000" max="15000" step="500" value="<?php echo esc_attr( $sec['carousel_speed'] ?? 4000 ); ?>" />
									</div>
									<div class="asutsabo-hb-field-group">
										<label class="asutsabo-hb-checkbox-label">
											<input type="checkbox" class="asutsabo-hb-field" data-key="carousel_arrows" <?php checked( ! isset( $sec['carousel_arrows'] ) || ! empty( $sec['carousel_arrows'] ) ); ?> />
											<?php esc_html_e( 'Navigation Arrows On/Off', 'asutsabo' ); ?>
										</label>
										<label class="asutsabo-hb-checkbox-label">
											<input type="checkbox" class="asutsabo-hb-field" data-key="carousel_dots" <?php checked( ! isset( $sec['carousel_dots'] ) || ! empty( $sec['carousel_dots'] ) ); ?> />
											<?php esc_html_e( 'Pagination Dots On/Off', 'asutsabo' ); ?>
										</label>
									</div>
								</div>

								<!-- Category Pill Badge -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-label"><?php esc_html_e( 'Category Pill Badge Text', 'asutsabo' ); ?></label>
									<input type="text" class="asutsabo-hb-field" data-key="badge" value="<?php echo esc_attr( $sec['badge'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'e.g. ZUNHEBOTO, NAGALAND, EXCLUSIVE', 'asutsabo' ); ?>" />
									<label class="asutsabo-hb-checkbox-label">
										<input type="checkbox" class="asutsabo-hb-field" data-key="show_badge" <?php checked( ! isset( $sec['show_badge'] ) || ! empty( $sec['show_badge'] ) ); ?> />
										<?php esc_html_e( 'Show Category Badge / Label', 'asutsabo' ); ?>
									</label>
								</div>

								<!-- Meta toggles -->
								<div class="asutsabo-hb-field-group">
									<label class="asutsabo-hb-label"><?php esc_html_e( 'Article Metadata Display', 'asutsabo' ); ?></label>
									<div style="display:flex;flex-wrap:wrap;gap:12px;">
										<label class="asutsabo-hb-checkbox-label">
											<input type="checkbox" class="asutsabo-hb-field" data-key="show_date" <?php checked( ! isset( $sec['show_date'] ) || ! empty( $sec['show_date'] ) ); ?> />
											<?php esc_html_e( 'Show Date', 'asutsabo' ); ?>
										</label>
										<label class="asutsabo-hb-checkbox-label">
											<input type="checkbox" class="asutsabo-hb-field" data-key="show_author" <?php checked( ! isset( $sec['show_author'] ) || ! empty( $sec['show_author'] ) ); ?> />
											<?php esc_html_e( 'Show Author', 'asutsabo' ); ?>
										</label>
										<label class="asutsabo-hb-checkbox-label">
											<input type="checkbox" class="asutsabo-hb-field" data-key="show_excerpt" <?php checked( ! isset( $sec['show_excerpt'] ) || ! empty( $sec['show_excerpt'] ) ); ?> />
											<?php esc_html_e( 'Show Excerpt', 'asutsabo' ); ?>
										</label>
									</div>
								</div>

								<!-- Footer actions -->
								<div class="asutsabo-hb-card-footer">
									<button type="button" class="button button-secondary asutsabo-hb-duplicate-btn"><?php esc_html_e( 'Duplicate Section', 'asutsabo' ); ?></button>
									<button type="button" class="button asutsabo-hb-delete-btn"><?php esc_html_e( 'Delete Section', 'asutsabo' ); ?></button>
								</div>
							</div>
						</div>
						<?php
						$order_idx++;
					endforeach;
					?>
				</div>

				<input type="hidden" id="asutsabo-hb-data-input" <?php $this->link(); ?> value="<?php echo esc_attr( wp_json_encode( $sections ) ); ?>" />
			</div>
			<?php
		}
	}

	/**
	 * Customizer Control for Editable Navigation List Repeaters.
	 */
	class Asutsabo_Navigation_List_Control extends WP_Customize_Control {
		public $type = 'asutsabo_navigation_list';

		public function render_content() {
			$items = $this->value();
			if ( ! is_array( $items ) ) {
				if ( is_string( $items ) && ! empty( $items ) ) {
					$decoded = json_decode( $items, true );
					$items   = is_array( $decoded ) ? $decoded : array();
				} else {
					$items = array();
				}
			}
			?>
			<div class="asutsabo-nav-list-manager-wrap">
				<?php if ( ! empty( $this->label ) ) : ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $this->description ) ) : ?>
					<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php endif; ?>

				<div class="asutsabo-nav-list-top-bar" style="margin: 8px 0;">
					<button type="button" class="button button-primary asutsabo-nav-list-add-btn">+ <?php esc_html_e( 'Add Link', 'asutsabo' ); ?></button>
				</div>

				<div class="asutsabo-nav-list-items-container">
					<?php
					foreach ( $items as $item ) :
						$title  = ! empty( $item['title'] ) ? $item['title'] : '';
						$url    = ! empty( $item['url'] ) ? $item['url'] : '';
						$hidden = ! empty( $item['hidden'] );
						?>
						<div class="asutsabo-nav-list-item <?php echo $hidden ? 'is-hidden' : ''; ?>">
							<div class="asutsabo-nav-list-item-row" style="display:flex;align-items:center;gap:6px;margin-bottom:6px;">
								<span class="asutsabo-nav-list-drag-handle" style="cursor:grab;">&#9776;</span>
								<input type="text" class="asutsabo-nav-item-title" value="<?php echo esc_attr( $title ); ?>" placeholder="<?php esc_attr_e( 'Link Text', 'asutsabo' ); ?>" style="flex:1;" />
								<input type="text" class="asutsabo-nav-item-url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://..." style="flex:1;" />
								<label class="asutsabo-nav-item-hide-toggle" title="<?php esc_attr_e( 'Show / Hide Link', 'asutsabo' ); ?>">
									<input type="checkbox" class="asutsabo-nav-item-hidden" <?php checked( ! $hidden ); ?> />
								</label>
								<button type="button" class="asutsabo-nav-item-move-up button button-small" title="<?php esc_attr_e( 'Move Up', 'asutsabo' ); ?>">&#9650;</button>
								<button type="button" class="asutsabo-nav-item-move-down button button-small" title="<?php esc_attr_e( 'Move Down', 'asutsabo' ); ?>">&#9660;</button>
								<button type="button" class="asutsabo-nav-item-delete button button-small" title="<?php esc_attr_e( 'Delete Link', 'asutsabo' ); ?>" style="color:#b32d2e;">&#128465;</button>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<input type="hidden" class="asutsabo-nav-list-input" <?php $this->link(); ?> value="<?php echo esc_attr( wp_json_encode( $items ) ); ?>" />
			</div>
			<?php
		}
	}
}

/**
 * Register Theme Customizer settings, controls, and selective refresh partials.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function asutsabo_customize_register( $wp_customize ) {
	$category_choices = asutsabo_get_category_choices();

	// =========================================================================
	// 0. SITE IDENTITY CONTROLS (WordPress Core title_tagline Section)
	// =========================================================================
	$wp_customize->add_setting(
		'asutsabo_site_title_display',
		array(
			'default'           => 'all',
			'sanitize_callback' => 'asutsabo_sanitize_site_title_display',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_site_title_display',
		array(
			'label'       => esc_html__( 'Site Identity Display Combination', 'asutsabo' ),
			'description' => esc_html__( 'Choose how the logo, site title, and tagline are combined in the masthead.', 'asutsabo' ),
			'section'     => 'title_tagline',
			'type'        => 'select',
			'choices'     => array(
				'all'           => esc_html__( 'Show All (Logo, Title & Tagline)', 'asutsabo' ),
				'logo_tagline'  => esc_html__( 'Logo and Tagline Only (Hide Site Title text)', 'asutsabo' ),
				'title_tagline' => esc_html__( 'Title and Tagline Only (Hide Logo)', 'asutsabo' ),
				'logo_only'     => esc_html__( 'Logo Only (Hide Title & Tagline)', 'asutsabo' ),
				'title_only'    => esc_html__( 'Site Title Only (Hide Logo & Tagline)', 'asutsabo' ),
				'custom'        => esc_html__( 'Custom (Use granular checkboxes below)', 'asutsabo' ),
			),
			'priority'    => 45,
		)
	);

	// Display Logo checkbox
	$wp_customize->add_setting(
		'asutsabo_show_site_logo',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_show_site_logo',
		array(
			'label'       => esc_html__( 'Display Custom Logo', 'asutsabo' ),
			'description' => esc_html__( 'Applies if a logo image is uploaded above.', 'asutsabo' ),
			'section'     => 'title_tagline',
			'type'        => 'checkbox',
			'priority'    => 46,
		)
	);

	// Display Site Title text checkbox
	$wp_customize->add_setting(
		'asutsabo_show_site_title',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_show_site_title',
		array(
			'label'       => esc_html__( 'Display Site Title Text', 'asutsabo' ),
			'description' => esc_html__( 'Check to display text site title in masthead.', 'asutsabo' ),
			'section'     => 'title_tagline',
			'type'        => 'checkbox',
			'priority'    => 47,
		)
	);

	// Display Tagline checkbox
	$wp_customize->add_setting(
		'asutsabo_show_site_tagline',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_show_site_tagline',
		array(
			'label'       => esc_html__( 'Display Tagline / Description', 'asutsabo' ),
			'description' => esc_html__( 'Check to display tagline beneath the site title or logo.', 'asutsabo' ),
			'section'     => 'title_tagline',
			'type'        => 'checkbox',
			'priority'    => 48,
		)
	);

	// =========================================================================
	// 1. HEADER SECTION (asutsabo_header_section)
	// =========================================================================
	$wp_customize->add_section(
		'asutsabo_header_section',
		array(
			'title'       => esc_html__( 'Header & Masthead Settings', 'asutsabo' ),
			'description' => esc_html__( 'Configure breaking news ticker, digital edition notice, publication date, and search bar.', 'asutsabo' ),
			'priority'    => 30,
		)
	);

	// Breaking news ticker: toggle visibility
	$wp_customize->add_setting(
		'asutsabo_breaking_news_enable',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_breaking_news_enable',
		array(
			'label'       => esc_html__( 'Enable Breaking News Ticker', 'asutsabo' ),
			'description' => esc_html__( 'Show the live breaking news strip above the masthead.', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'checkbox',
		)
	);

	// Breaking news ticker: badge text
	$wp_customize->add_setting(
		'asutsabo_breaking_news_badge',
		array(
			'default'           => 'BREAKING NEWS',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_breaking_news_badge',
		array(
			'label'       => esc_html__( 'Breaking News Badge Text', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'text',
		)
	);

	// Breaking news ticker: category selection dropdown
	$wp_customize->add_setting(
		'asutsabo_breaking_news_category',
		array(
			'default'           => '',
			'sanitize_callback' => 'asutsabo_sanitize_category_slug',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_breaking_news_category',
		array(
			'label'       => esc_html__( 'Breaking News Category', 'asutsabo' ),
			'description' => esc_html__( 'Filter breaking stories by category, or leave as All for the latest published story.', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'select',
			'choices'     => $category_choices,
		)
	);

	// Masthead: editable digital edition text
	$wp_customize->add_setting(
		'asutsabo_edition_text',
		array(
			'default'           => 'DIGITAL EDITION',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_edition_text',
		array(
			'label'       => esc_html__( 'Digital Edition Label', 'asutsabo' ),
			'description' => esc_html__( 'Top masthead edition label text.', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'text',
		)
	);

	// Masthead: toggle for publication date
	$wp_customize->add_setting(
		'asutsabo_show_date',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_show_date',
		array(
			'label'       => esc_html__( 'Show Publication Date', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'checkbox',
		)
	);

	// Masthead: custom date format input
	$wp_customize->add_setting(
		'asutsabo_date_format',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_date_format',
		array(
			'label'       => esc_html__( 'Custom Date Format', 'asutsabo' ),
			'description' => esc_html__( 'PHP date format string (e.g., "l, F j, Y"). Leave empty to use default WordPress setting.', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'text',
		)
	);

	// Masthead: toggle for header search bar
	$wp_customize->add_setting(
		'asutsabo_show_search',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_show_search',
		array(
			'label'       => esc_html__( 'Show Header Search Bar', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'checkbox',
		)
	);

	// Breaking news post count
	$wp_customize->add_setting(
		'asutsabo_breaking_news_count',
		array(
			'default'           => 4,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_breaking_news_count',
		array(
			'label'       => esc_html__( 'Breaking News Headline Count', 'asutsabo' ),
			'description' => esc_html__( 'Number of breaking stories to cycle through in the ticker.', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'number',
			'input_attrs' => array( 'min' => 1, 'max' => 10, 'step' => 1 ),
		)
	);

	// Sticky navigation toggle
	$wp_customize->add_setting(
		'asutsabo_sticky_header',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_sticky_header',
		array(
			'label'       => esc_html__( 'Sticky Navigation Bar', 'asutsabo' ),
			'description' => esc_html__( 'Keep navigation bar pinned to top when scrolling down.', 'asutsabo' ),
			'section'     => 'asutsabo_header_section',
			'type'        => 'checkbox',
		)
	);

	// =========================================================================
	// 1B. LAYOUT & READING PREFERENCES (asutsabo_layout_section)
	// =========================================================================
	$wp_customize->add_section(
		'asutsabo_layout_section',
		array(
			'title'       => esc_html__( 'Layout & Reading Preferences', 'asutsabo' ),
			'description' => esc_html__( 'Configure sidebar layouts, reading progress bar, reader toolbar (font resizer/dark mode), and table of contents.', 'asutsabo' ),
			'priority'    => 32,
		)
	);

	// Default layout
	$wp_customize->add_setting(
		'asutsabo_default_layout',
		array(
			'default'           => 'right-sidebar',
			'sanitize_callback' => 'sanitize_key',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_default_layout',
		array(
			'label'       => esc_html__( 'Default Global Layout', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'select',
			'choices'     => array(
				'right-sidebar' => esc_html__( 'Right Sidebar', 'asutsabo' ),
				'no-sidebar'    => esc_html__( 'No Sidebar (Centered)', 'asutsabo' ),
			),
		)
	);

	// Single post sidebar toggle
	$wp_customize->add_setting(
		'asutsabo_single_sidebar',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_single_sidebar',
		array(
			'label'       => esc_html__( 'Enable Sidebar on Single Articles', 'asutsabo' ),
			'description' => esc_html__( 'Displays Primary Sidebar on individual post pages.', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'checkbox',
		)
	);

	// Archive sidebar toggle
	$wp_customize->add_setting(
		'asutsabo_archive_sidebar',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_archive_sidebar',
		array(
			'label'       => esc_html__( 'Enable Sidebar on Archives & Search', 'asutsabo' ),
			'description' => esc_html__( 'Displays Primary Sidebar on categories, tags, dates, author, and search pages.', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'checkbox',
		)
	);

	// Static page sidebar toggle
	$wp_customize->add_setting(
		'asutsabo_page_sidebar',
		array(
			'default'           => false,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_page_sidebar',
		array(
			'label'       => esc_html__( 'Enable Sidebar on Static Pages', 'asutsabo' ),
			'description' => esc_html__( 'Displays Primary Sidebar on standard static pages.', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'checkbox',
		)
	);

	// Reading progress bar toggle
	$wp_customize->add_setting(
		'asutsabo_enable_reading_progress',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_enable_reading_progress',
		array(
			'label'       => esc_html__( 'Reading Progress Indicator Bar', 'asutsabo' ),
			'description' => esc_html__( 'Displays an elegant scroll-progress bar pinned at the very top of articles.', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'checkbox',
		)
	);

	// Reader toolbar (font resizer & dark mode) toggle
	$wp_customize->add_setting(
		'asutsabo_enable_reader_controls',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_enable_reader_controls',
		array(
			'label'       => esc_html__( 'Reader Toolbar (Font Resizer & Dark/Sepia Mode)', 'asutsabo' ),
			'description' => esc_html__( 'Allows readers to toggle font size and switch between Light, Sepia, and Dark reading modes.', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'checkbox',
		)
	);

	// Table of Contents toggle
	$wp_customize->add_setting(
		'asutsabo_enable_toc',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_enable_toc',
		array(
			'label'       => esc_html__( 'Auto-Generate Table of Contents', 'asutsabo' ),
			'description' => esc_html__( 'Automatically generates a collapsible Table of Contents for articles with 2+ headings.', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'checkbox',
		)
	);

	// Back to Top button toggle
	$wp_customize->add_setting(
		'asutsabo_enable_back_to_top',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_enable_back_to_top',
		array(
			'label'       => esc_html__( 'Back to Top Floating Button', 'asutsabo' ),
			'description' => esc_html__( 'Displays a smooth-scroll button when readers scroll down.', 'asutsabo' ),
			'section'     => 'asutsabo_layout_section',
			'type'        => 'checkbox',
		)
	);

	// =========================================================================
	// 2. HOMEPAGE SECTIONS / HOMEPAGE BUILDER (asutsabo_homepage_builder_panel)
	// =========================================================================
	$wp_customize->add_panel(
		'asutsabo_homepage_builder_panel',
		array(
			'title'       => esc_html__( 'Homepage Sections / Homepage Builder', 'asutsabo' ),
			'description' => esc_html__( 'Create, edit, reorder, duplicate, hide, and customize all homepage magazine sections.', 'asutsabo' ),
			'priority'    => 35,
		)
	);

	// Master Manager Section
	$wp_customize->add_section(
		'asutsabo_hb_master_section',
		array(
			'title'       => esc_html__( '📋 Add, Reorder & Manage Sections', 'asutsabo' ),
			'description' => esc_html__( 'Drag and drop cards to reorder. Toggle visibility, duplicate, delete, or click "Add Homepage Section" to create new ones.', 'asutsabo' ),
			'panel'       => 'asutsabo_homepage_builder_panel',
			'priority'    => 1,
		)
	);

	$wp_customize->add_setting(
		'asutsabo_homepage_sections',
		array(
			'type'              => 'option',
			'default'           => asutsabo_get_default_homepage_sections(),
			'sanitize_callback' => 'asutsabo_sanitize_homepage_sections_data',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		new Asutsabo_Homepage_Builder_Control(
			$wp_customize,
			'asutsabo_homepage_sections',
			array(
				'section'  => 'asutsabo_hb_master_section',
				'settings' => 'asutsabo_homepage_sections',
			)
		)
	);

	// Dynamically register an individual Customizer Section for each Homepage Section
	$hp_sections       = function_exists( 'asutsabo_get_homepage_sections' ) ? asutsabo_get_homepage_sections() : array();
	$available_layouts = function_exists( 'asutsabo_get_available_layouts' ) ? asutsabo_get_available_layouts() : array();
	$sec_priority      = 10;

	foreach ( $hp_sections as $sec_id => $sec_data ) {
		$sec_title    = ! empty( $sec_data['title'] ) ? $sec_data['title'] : ucfirst( str_replace( '_', ' ', $sec_id ) );
		$panel_sec_id = 'asutsabo_hb_sec_' . sanitize_key( $sec_id );

		$wp_customize->add_section(
			$panel_sec_id,
			array(
				'title'       => sprintf( '%s %s', ! empty( $sec_data['enabled'] ) ? '●' : '○', esc_html( $sec_title ) ),
				'description' => sprintf( esc_html__( 'Configure settings for the "%s" homepage section.', 'asutsabo' ), esc_html( $sec_title ) ),
				'panel'       => 'asutsabo_homepage_builder_panel',
				'priority'    => $sec_priority++,
			)
		);

		// Visibility toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][enabled]",
			array(
				'type'              => 'option',
				'default'           => ! empty( $sec_data['enabled'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][enabled]",
			array(
				'label'       => esc_html__( 'Show this section on Homepage', 'asutsabo' ),
				'description' => esc_html__( 'If disabled, the section disappears without deleting its configuration.', 'asutsabo' ),
				'section'     => $panel_sec_id,
				'type'        => 'checkbox',
			)
		);

		// Section title setting
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][title]",
			array(
				'type'              => 'option',
				'default'           => $sec_title,
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][title]",
			array(
				'label'   => esc_html__( 'Section Heading / Title', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'text',
			)
		);

		// Show title toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][show_title]",
			array(
				'type'              => 'option',
				'default'           => ! isset( $sec_data['show_title'] ) || ! empty( $sec_data['show_title'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][show_title]",
			array(
				'label'   => esc_html__( 'Display Heading on Homepage', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'checkbox',
			)
		);

		// Show description toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][show_desc]",
			array(
				'type'              => 'option',
				'default'           => ! empty( $sec_data['show_desc'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][show_desc]",
			array(
				'label'   => esc_html__( 'Enable Short Description / Subtitle', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'checkbox',
			)
		);

		// Description textarea
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][description]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['description'] ?? '',
				'sanitize_callback' => 'sanitize_textarea_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][description]",
			array(
				'label'   => esc_html__( 'Short Description Text', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'textarea',
			)
		);

		// View all toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][show_view_all]",
			array(
				'type'              => 'option',
				'default'           => ! isset( $sec_data['show_view_all'] ) || ! empty( $sec_data['show_view_all'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][show_view_all]",
			array(
				'label'   => esc_html__( 'Enable "View All" Button', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'checkbox',
			)
		);

		// View all text
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][view_all_text]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['view_all_text'] ?? __( 'View all', 'asutsabo' ),
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][view_all_text]",
			array(
				'label'   => esc_html__( '"View All" Button Text', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'text',
			)
		);

		// View all custom URL
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][view_all_url]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['view_all_url'] ?? '',
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][view_all_url]",
			array(
				'label'       => esc_html__( '"View All" Custom URL', 'asutsabo' ),
				'description' => esc_html__( 'Leave empty to automatically use category archive link.', 'asutsabo' ),
				'section'     => $panel_sec_id,
				'type'        => 'url',
			)
		);

		// Post source
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][source]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['source'] ?? 'category',
				'sanitize_callback' => 'sanitize_key',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][source]",
			array(
				'label'   => esc_html__( 'Post Source', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'select',
				'choices' => array(
					'latest'     => esc_html__( 'Latest posts (All categories)', 'asutsabo' ),
					'category'   => esc_html__( 'Posts from a selected category', 'asutsabo' ),
					'categories' => esc_html__( 'Posts from multiple categories', 'asutsabo' ),
					'tags'       => esc_html__( 'Posts from selected tags', 'asutsabo' ),
					'manual'     => esc_html__( 'Manually selected post IDs', 'asutsabo' ),
				),
			)
		);

		// Category
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][category]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['category'] ?? '',
				'sanitize_callback' => 'asutsabo_sanitize_category_slug',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][category]",
			array(
				'label'   => esc_html__( 'Content Category', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'select',
				'choices' => $category_choices,
			)
		);

		// Post count
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][count]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['count'] ?? 4,
				'sanitize_callback' => 'absint',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][count]",
			array(
				'label'       => esc_html__( 'Number of Posts to Display', 'asutsabo' ),
				'section'     => $panel_sec_id,
				'type'        => 'number',
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 50,
					'step' => 1,
				),
			)
		);

		// Layout Type
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][layout]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['layout'] ?? 'feature-list',
				'sanitize_callback' => 'sanitize_key',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][layout]",
			array(
				'label'   => esc_html__( 'Layout Type', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'select',
				'choices' => $available_layouts,
			)
		);

		// Category pill badge text
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][badge]",
			array(
				'type'              => 'option',
				'default'           => $sec_data['badge'] ?? '',
				'sanitize_callback' => 'sanitize_text_field',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][badge]",
			array(
				'label'   => esc_html__( 'Category Pill Badge Text', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'text',
			)
		);

		// Show badge toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][show_badge]",
			array(
				'type'              => 'option',
				'default'           => ! isset( $sec_data['show_badge'] ) || ! empty( $sec_data['show_badge'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][show_badge]",
			array(
				'label'   => esc_html__( 'Show Category Badge / Label', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'checkbox',
			)
		);

		// Show date toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][show_date]",
			array(
				'type'              => 'option',
				'default'           => ! isset( $sec_data['show_date'] ) || ! empty( $sec_data['show_date'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][show_date]",
			array(
				'label'   => esc_html__( 'Show Article Date', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'checkbox',
			)
		);

		// Show author toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][show_author]",
			array(
				'type'              => 'option',
				'default'           => ! isset( $sec_data['show_author'] ) || ! empty( $sec_data['show_author'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][show_author]",
			array(
				'label'   => esc_html__( 'Show Author Byline', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'checkbox',
			)
		);

		// Show excerpt toggle
		$wp_customize->add_setting(
			"asutsabo_homepage_sections[{$sec_id}][show_excerpt]",
			array(
				'type'              => 'option',
				'default'           => ! isset( $sec_data['show_excerpt'] ) || ! empty( $sec_data['show_excerpt'] ),
				'sanitize_callback' => 'asutsabo_sanitize_checkbox',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_homepage_sections[{$sec_id}][show_excerpt]",
			array(
				'label'   => esc_html__( 'Show Excerpt / Summary', 'asutsabo' ),
				'section' => $panel_sec_id,
				'type'    => 'checkbox',
			)
		);
	}

	// Legacy settings definitions for selective refresh and backward compatibility
	$category_desks = array(
		'national'      => esc_html__( 'National', 'asutsabo' ),
		'world'         => esc_html__( 'World', 'asutsabo' ),
		'politics'      => esc_html__( 'Politics', 'asutsabo' ),
		'business'      => esc_html__( 'Business', 'asutsabo' ),
		'technology'    => esc_html__( 'Technology', 'asutsabo' ),
		'sports'        => esc_html__( 'Sports', 'asutsabo' ),
		'entertainment' => esc_html__( 'Entertainment & Arts', 'asutsabo' ),
		'culture'       => esc_html__( 'Culture', 'asutsabo' ),
		'lifestyle'     => esc_html__( 'Lifestyle', 'asutsabo' ),
	);

	$wp_customize->add_setting( 'asutsabo_fast_wire_title', array( 'default' => 'Fast Wire', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'postMessage' ) );
	$wp_customize->add_setting( 'asutsabo_fast_wire_count', array( 'default' => 6, 'sanitize_callback' => 'absint', 'transport' => 'refresh' ) );
	$wp_customize->add_setting( 'asutsabo_fast_wire_category', array( 'default' => '', 'sanitize_callback' => 'asutsabo_sanitize_category_slug', 'transport' => 'refresh' ) );
	$wp_customize->add_setting( 'asutsabo_editors_picks_title', array( 'default' => "Editor's Picks", 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'postMessage' ) );
	$wp_customize->add_setting( 'asutsabo_editors_picks_category', array( 'default' => 'editors-picks', 'sanitize_callback' => 'asutsabo_sanitize_category_slug', 'transport' => 'refresh' ) );
	$wp_customize->add_setting( 'asutsabo_editors_picks_count', array( 'default' => 3, 'sanitize_callback' => 'absint', 'transport' => 'refresh' ) );
	$wp_customize->add_setting( 'asutsabo_top_dispatches_title', array( 'default' => 'Top Dispatches', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'postMessage' ) );
	$wp_customize->add_setting( 'asutsabo_top_dispatches_category', array( 'default' => '', 'sanitize_callback' => 'asutsabo_sanitize_category_slug', 'transport' => 'refresh' ) );
	$wp_customize->add_setting( 'asutsabo_top_dispatches_count', array( 'default' => 3, 'sanitize_callback' => 'absint', 'transport' => 'refresh' ) );

	foreach ( $category_desks as $slug => $label ) {
		$wp_customize->add_setting( "asutsabo_{$slug}_enable", array( 'default' => true, 'sanitize_callback' => 'asutsabo_sanitize_checkbox', 'transport' => 'refresh' ) );
		$wp_customize->add_setting( "asutsabo_{$slug}_title", array( 'default' => $label, 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'postMessage' ) );
		$wp_customize->add_setting( "asutsabo_{$slug}_category", array( 'default' => $slug, 'sanitize_callback' => 'asutsabo_sanitize_category_slug', 'transport' => 'refresh' ) );
		$wp_customize->add_setting( "asutsabo_{$slug}_count", array( 'default' => 2, 'sanitize_callback' => 'absint', 'transport' => 'refresh' ) );
	}


	// =========================================================================
	// 3. HOMEPAGE BRIEFING / NEWSLETTER SECTION (asutsabo_newsletter_section)
	// =========================================================================
	$wp_customize->add_section(
		'asutsabo_newsletter_section',
		array(
			'title'       => esc_html__( 'Homepage Briefing Box', 'asutsabo' ),
			'description' => esc_html__( 'Configure the "The Daily Intelligence / Join Free Briefing" box on the homepage.', 'asutsabo' ),
			'priority'    => 38,
		)
	);

	// Visibility Toggle
	$wp_customize->add_setting(
		'asutsabo_show_newsletter',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_show_newsletter',
		array(
			'label'       => esc_html__( 'Show Newsletter / Briefing Box', 'asutsabo' ),
			'description' => esc_html__( 'Show or hide the "Join Free Briefing" callout on the homepage.', 'asutsabo' ),
			'section'     => 'asutsabo_newsletter_section',
			'type'        => 'checkbox',
		)
	);

	// Eyebrow text
	$wp_customize->add_setting(
		'asutsabo_newsletter_eyebrow',
		array(
			'default'           => 'THE DAILY INTELLIGENCE',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_newsletter_eyebrow',
		array(
			'label'   => esc_html__( 'Eyebrow Text (Top Tag)', 'asutsabo' ),
			'section' => 'asutsabo_newsletter_section',
			'type'    => 'text',
		)
	);

	// Headline
	$wp_customize->add_setting(
		'asutsabo_newsletter_headline',
		array(
			'default'           => 'Essential journalism, direct to your inbox.',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_newsletter_headline',
		array(
			'label'   => esc_html__( 'Headline', 'asutsabo' ),
			'section' => 'asutsabo_newsletter_section',
			'type'    => 'text',
		)
	);

	// Description
	$wp_customize->add_setting(
		'asutsabo_newsletter_description',
		array(
			'default'           => "Subscribe to receive My WordPress Website's independent reporting, investigative dispatches, and cultural critique directly in your inbox.",
			'sanitize_callback' => 'sanitize_textarea_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_newsletter_description',
		array(
			'label'   => esc_html__( 'Description', 'asutsabo' ),
			'section' => 'asutsabo_newsletter_section',
			'type'    => 'textarea',
		)
	);

	// Button Label
	$wp_customize->add_setting(
		'asutsabo_newsletter_button_text',
		array(
			'default'           => 'Join Free Briefing',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_newsletter_button_text',
		array(
			'label'   => esc_html__( 'Button Label', 'asutsabo' ),
			'section' => 'asutsabo_newsletter_section',
			'type'    => 'text',
		)
	);

	// Button Link / Action
	$wp_customize->add_setting(
		'asutsabo_newsletter_button_url',
		array(
			'default'           => '#subscribe',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_newsletter_button_url',
		array(
			'label'       => esc_html__( 'Button Link / Action URL', 'asutsabo' ),
			'description' => esc_html__( 'Anchor (e.g. #subscribe) or destination URL.', 'asutsabo' ),
			'section'     => 'asutsabo_newsletter_section',
			'type'        => 'text',
		)
	);

	// Disclaimer text
	$wp_customize->add_setting(
		'asutsabo_newsletter_disclaimer',
		array(
			'default'           => 'NO SPAM. ONE-CLICK UNSUBSCRIBE AT ANY TIME.',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_newsletter_disclaimer',
		array(
			'label'   => esc_html__( 'Disclaimer / Note Text', 'asutsabo' ),
			'section' => 'asutsabo_newsletter_section',
			'type'    => 'text',
		)
	);


	// =========================================================================
	// 4. FOOTER SECTION (asutsabo_footer_section)
	// =========================================================================
	$wp_customize->add_section(
		'asutsabo_footer_section',
		array(
			'title'       => esc_html__( 'Footer Settings', 'asutsabo' ),
			'description' => esc_html__( 'Configure footer bio description, copyright line, and social media links.', 'asutsabo' ),
			'priority'    => 40,
		)
	);

	// About/Bio: textarea
	$wp_customize->add_setting(
		'asutsabo_footer_bio',
		array(
			'default'           => 'A digital publication devoted to fearless journalism, deep investigative reporting, critical commentary, and cultural analysis. Founded on principles of truth, nuance, and editorial rigor.',
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_footer_bio',
		array(
			'label'       => esc_html__( 'Publication Overview / Bio', 'asutsabo' ),
			'description' => esc_html__( 'Displayed in the first footer column when no widgets are assigned.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'textarea',
		)
	);

	// -------------------------------------------------------------------------
	// Footer Column 2: Sections
	// -------------------------------------------------------------------------
	$wp_customize->add_setting(
		'asutsabo_footer_col2_show',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_footer_col2_show',
		array(
			'label'       => esc_html__( 'Show Footer Column 2 (Sections)', 'asutsabo' ),
			'description' => esc_html__( 'Toggle visibility of the second footer column.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'checkbox',
		)
	);

	$wp_customize->add_setting(
		'asutsabo_footer_col2_title',
		array(
			'default'           => esc_html__( 'Sections', 'asutsabo' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_footer_col2_title',
		array(
			'label'       => esc_html__( 'Column 2 Title', 'asutsabo' ),
			'description' => esc_html__( 'Default is "Sections". You can also assign a custom menu to "Footer Sections Menu (Column 2)" in Appearance > Menus.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'asutsabo_footer_col2_custom_content',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_footer_col2_custom_content',
		array(
			'label'       => esc_html__( 'Column 2 Custom Content (optional)', 'asutsabo' ),
			'description' => esc_html__( 'Enter custom HTML or links. When filled, overrides the default category list.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'textarea',
		)
	);

	// Footer Column 2: Editable Sections Menu Repeater
	$wp_customize->add_setting(
		'asutsabo_sections_menu_items',
		array(
			'type'              => 'option',
			'default'           => function_exists( 'asutsabo_get_default_sections_menu_items' ) ? asutsabo_get_default_sections_menu_items() : array(),
			'sanitize_callback' => 'asutsabo_sanitize_nav_list_data',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new Asutsabo_Navigation_List_Control(
			$wp_customize,
			'asutsabo_sections_menu_items',
			array(
				'label'       => esc_html__( 'Column 2: "Sections" Menu Links', 'asutsabo' ),
				'description' => esc_html__( 'Manage items in the Sections column. Add, edit titles, change destination URLs, reorder, hide, or delete links.', 'asutsabo' ),
				'section'     => 'asutsabo_footer_section',
			)
		)
	);

	// -------------------------------------------------------------------------
	// Footer Column 3: Standards
	// -------------------------------------------------------------------------
	$wp_customize->add_setting(
		'asutsabo_footer_col3_show',
		array(
			'default'           => true,
			'sanitize_callback' => 'asutsabo_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_footer_col3_show',
		array(
			'label'       => esc_html__( 'Show Footer Column 3 (Standards)', 'asutsabo' ),
			'description' => esc_html__( 'Toggle visibility of the third footer column.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'checkbox',
		)
	);

	$wp_customize->add_setting(
		'asutsabo_footer_col3_title',
		array(
			'default'           => esc_html__( 'Standards', 'asutsabo' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_footer_col3_title',
		array(
			'label'       => esc_html__( 'Column 3 Title', 'asutsabo' ),
			'description' => esc_html__( 'Default is "Standards". You can also assign a custom menu to "Footer Standards & Policies Menu (Column 3)" in Appearance > Menus.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'asutsabo_footer_col3_custom_content',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'asutsabo_footer_col3_custom_content',
		array(
			'label'       => esc_html__( 'Column 3 Custom Content (optional)', 'asutsabo' ),
			'description' => esc_html__( 'Enter custom HTML or links. When filled, overrides the default standards pages.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'textarea',
		)
	);

	// Footer Column 3: Editable Standards Menu Repeater
	$wp_customize->add_setting(
		'asutsabo_standards_menu_items',
		array(
			'type'              => 'option',
			'default'           => function_exists( 'asutsabo_get_default_standards_menu_items' ) ? asutsabo_get_default_standards_menu_items() : array(),
			'sanitize_callback' => 'asutsabo_sanitize_nav_list_data',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		new Asutsabo_Navigation_List_Control(
			$wp_customize,
			'asutsabo_standards_menu_items',
			array(
				'label'       => esc_html__( 'Column 3: "Standards" Menu Links', 'asutsabo' ),
				'description' => esc_html__( 'Manage items in the Standards & Policies column. Add, edit titles, change destination URLs, reorder, hide, or delete links.', 'asutsabo' ),
				'section'     => 'asutsabo_footer_section',
			)
		)
	);

	// Copyright line: text field supporting {year} and {site_title}
	$wp_customize->add_setting(
		'asutsabo_copyright_text',
		array(
			'default'           => '&copy; {year} {site_title}. All rights reserved.',
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'asutsabo_copyright_text',
		array(
			'label'       => esc_html__( 'Copyright Statement', 'asutsabo' ),
			'description' => esc_html__( 'Supports {year} and {site_title} placeholders.', 'asutsabo' ),
			'section'     => 'asutsabo_footer_section',
			'type'        => 'text',
		)
	);

	// Social links
	$social_platforms = array(
		'twitter'   => esc_html__( 'Twitter / X URL', 'asutsabo' ),
		'facebook'  => esc_html__( 'Facebook URL', 'asutsabo' ),
		'youtube'   => esc_html__( 'YouTube URL', 'asutsabo' ),
		'linkedin'  => esc_html__( 'LinkedIn URL', 'asutsabo' ),
		'instagram' => esc_html__( 'Instagram URL', 'asutsabo' ),
		'rss'       => esc_html__( 'RSS Feed URL', 'asutsabo' ),
	);

	foreach ( $social_platforms as $s_slug => $s_label ) {
		$wp_customize->add_setting(
			"asutsabo_social_{$s_slug}",
			array(
				'default'           => ( 'rss' === $s_slug ? get_bloginfo( 'rss2_url' ) : '' ),
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			"asutsabo_social_{$s_slug}",
			array(
				'label'   => $s_label,
				'section' => 'asutsabo_footer_section',
				'type'    => 'url',
			)
		);
	}


	// =========================================================================
	// 4. SELECTIVE REFRESH PARTIALS
	// =========================================================================
	if ( isset( $wp_customize->selective_refresh ) ) {
		// Digital Edition Label
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_edition_text',
			array(
				'selector'            => '.asutsabo-edition-label',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_edition_text', 'DIGITAL EDITION' ) );
				},
				'container_inclusive' => false,
			)
		);

		// Breaking News Badge
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_breaking_news_badge',
			array(
				'selector'            => '.asutsabo-breaking-news-label',
				'render_callback'     => function () {
					return '<span class="asutsabo-breaking-news-pulse" aria-hidden="true"></span> ' . esc_html( get_theme_mod( 'asutsabo_breaking_news_badge', 'BREAKING NEWS' ) );
				},
				'container_inclusive' => false,
			)
		);

		// Fast Wire Title
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_fast_wire_title',
			array(
				'selector'            => '.asutsabo-fast-wire .is-style-asutsabo-section-label',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_fast_wire_title', 'Fast Wire' ) );
				},
				'container_inclusive' => false,
			)
		);

		// Editor's Picks Title
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_editors_picks_title',
			array(
				'selector'            => '.asutsabo-editors-picks-section .is-style-asutsabo-section-label',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_editors_picks_title', "Editor's Picks" ) );
				},
				'container_inclusive' => false,
			)
		);

		// Top Dispatches Title
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_top_dispatches_title',
			array(
				'selector'            => '.asutsabo-hero-secondary .is-style-asutsabo-section-label',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_top_dispatches_title', 'Top Dispatches' ) );
				},
				'container_inclusive' => false,
			)
		);

		// Category Section Titles
		foreach ( $category_desks as $slug => $label ) {
			$wp_customize->selective_refresh->add_partial(
				"asutsabo_{$slug}_title",
				array(
					'selector'            => ".asutsabo-section-heading-{$slug}",
					'render_callback'     => function () use ( $slug, $label ) {
						return esc_html( get_theme_mod( "asutsabo_{$slug}_title", $label ) );
					},
					'container_inclusive' => false,
				)
			);
		}

		// Footer Bio
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_footer_bio',
			array(
				'selector'            => '.asutsabo-footer-bio',
				'render_callback'     => function () {
					$bio = get_theme_mod(
						'asutsabo_footer_bio',
						'A digital publication devoted to fearless journalism, deep investigative reporting, critical commentary, and cultural analysis. Founded on principles of truth, nuance, and editorial rigor.'
					);
					return wp_kses_post( $bio );
				},
				'container_inclusive' => false,
			)
		);

		// Copyright Line
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_copyright_text',
			array(
				'selector'            => '.asutsabo-copyright',
				'render_callback'     => function () {
					$default    = '&copy; {year} {site_title}. All rights reserved.';
					$template   = get_theme_mod( 'asutsabo_copyright_text', $default );
					$year       = wp_date( 'Y' );
					$site_title = get_bloginfo( 'name' );
					$rendered   = str_replace( array( '{year}', '{site_title}' ), array( $year, $site_title ), $template );
					return '<p style="margin:0;">' . wp_kses_post( $rendered ) . '</p>';
				},
				'container_inclusive' => false,
			)
		);

		// Homepage Briefing Box Partials
		$wp_customize->selective_refresh->add_partial(
			'asutsabo_newsletter_eyebrow',
			array(
				'selector'            => '.asutsabo-briefing-eyebrow',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_newsletter_eyebrow', 'THE DAILY INTELLIGENCE' ) );
				},
				'container_inclusive' => false,
			)
		);

		$wp_customize->selective_refresh->add_partial(
			'asutsabo_newsletter_headline',
			array(
				'selector'            => '.asutsabo-briefing-headline',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_newsletter_headline', 'Essential journalism, direct to your inbox.' ) );
				},
				'container_inclusive' => false,
			)
		);

		$wp_customize->selective_refresh->add_partial(
			'asutsabo_newsletter_description',
			array(
				'selector'            => '.asutsabo-briefing-description',
				'render_callback'     => function () {
					$default_desc = sprintf(
						/* translators: %s: site name */
						__( 'Subscribe to receive %s\'s independent reporting, investigative dispatches, and cultural critique directly in your inbox.', 'asutsabo' ),
						get_bloginfo( 'name' )
					);
					return esc_html( get_theme_mod( 'asutsabo_newsletter_description', $default_desc ) );
				},
				'container_inclusive' => false,
			)
		);

		$wp_customize->selective_refresh->add_partial(
			'asutsabo_newsletter_button_text',
			array(
				'selector'            => '.asutsabo-briefing-button',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_newsletter_button_text', 'Join Free Briefing' ) );
				},
				'container_inclusive' => false,
			)
		);

		$wp_customize->selective_refresh->add_partial(
			'asutsabo_newsletter_disclaimer',
			array(
				'selector'            => '.asutsabo-briefing-disclaimer',
				'render_callback'     => function () {
					return esc_html( get_theme_mod( 'asutsabo_newsletter_disclaimer', 'NO SPAM. ONE-CLICK UNSUBSCRIBE AT ANY TIME.' ) );
				},
				'container_inclusive' => false,
			)
		);
	}
}
add_action( 'customize_register', 'asutsabo_customize_register' );

/**
 * Enqueue scripts for Customizer live preview.
 */
function asutsabo_customize_preview_js() {
	wp_enqueue_script(
		'asutsabo-customizer-preview',
		get_template_directory_uri() . '/assets/js/customizer.js',
		array( 'customize-preview', 'jquery' ),
		ASUTSABO_VERSION,
		true
	);
}
add_action( 'customize_preview_init', 'asutsabo_customize_preview_js' );

/**
 * Enqueue scripts and styles for Customizer sidebar controls.
 */
function asutsabo_customize_controls_enqueue_scripts() {
	wp_enqueue_style(
		'asutsabo-customizer-controls',
		get_template_directory_uri() . '/assets/css/customizer-controls.css',
		array(),
		ASUTSABO_VERSION
	);

	wp_enqueue_script(
		'asutsabo-customizer-controls',
		get_template_directory_uri() . '/assets/js/customizer-controls.js',
		array( 'customize-controls', 'jquery', 'jquery-ui-sortable' ),
		ASUTSABO_VERSION,
		true
	);

	wp_localize_script(
		'asutsabo-customizer-controls',
		'asutsaboCustomizerData',
		array(
			'l10n' => array(
				'copied'          => __( '(Copy)', 'asutsabo' ),
				'confirmDelete'   => __( 'Are you sure you want to delete this section? Posts and categories will NOT be deleted.', 'asutsabo' ),
				'newSectionTitle' => __( 'New Section', 'asutsabo' ),
			),
		)
	);
}
add_action( 'customize_controls_enqueue_scripts', 'asutsabo_customize_controls_enqueue_scripts' );

/**
 * Synchronize settings saved in Theme Customizer with Homepage Builder option.
 */
function asutsabo_sync_customizer_to_builder() {
	if ( ! function_exists( 'asutsabo_get_homepage_sections' ) ) {
		return;
	}

	$sections = asutsabo_get_homepage_sections();
	$updated = false;

	// Fast wire
	if ( isset( $sections['fast_wire'] ) ) {
		$sections['fast_wire']['title']    = get_theme_mod( 'asutsabo_fast_wire_title', $sections['fast_wire']['title'] );
		$sections['fast_wire']['category'] = get_theme_mod( 'asutsabo_fast_wire_category', $sections['fast_wire']['category'] );
		$sections['fast_wire']['count']    = absint( get_theme_mod( 'asutsabo_fast_wire_count', $sections['fast_wire']['count'] ) );
		$updated = true;
	}

	// Hero
	if ( isset( $sections['hero'] ) ) {
		$sections['hero']['title']    = get_theme_mod( 'asutsabo_top_dispatches_title', $sections['hero']['title'] );
		$sections['hero']['category'] = get_theme_mod( 'asutsabo_top_dispatches_category', $sections['hero']['category'] );
		$sections['hero']['count']    = absint( get_theme_mod( 'asutsabo_top_dispatches_count', $sections['hero']['count'] ) );
		$updated = true;
	}

	// Editor's picks
	if ( isset( $sections['editors_picks'] ) ) {
		$sections['editors_picks']['title']    = get_theme_mod( 'asutsabo_editors_picks_title', $sections['editors_picks']['title'] );
		$sections['editors_picks']['category'] = get_theme_mod( 'asutsabo_editors_picks_category', $sections['editors_picks']['category'] );
		$sections['editors_picks']['count']    = absint( get_theme_mod( 'asutsabo_editors_picks_count', $sections['editors_picks']['count'] ) );
		$updated = true;
	}

	// Desks
	$slugs = array( 'national', 'world', 'politics', 'business', 'technology', 'sports', 'entertainment', 'culture', 'lifestyle' );
	foreach ( $slugs as $slug ) {
		if ( isset( $sections[ $slug ] ) ) {
			$sections[ $slug ]['enabled']  = (bool) get_theme_mod( "asutsabo_{$slug}_enable", $sections[ $slug ]['enabled'] );
			$sections[ $slug ]['title']    = get_theme_mod( "asutsabo_{$slug}_title", $sections[ $slug ]['title'] );
			$sections[ $slug ]['category'] = get_theme_mod( "asutsabo_{$slug}_category", $sections[ $slug ]['category'] );
			$sections[ $slug ]['count']    = absint( get_theme_mod( "asutsabo_{$slug}_count", $sections[ $slug ]['count'] ) );
			$updated = true;
		}
	}

	// Briefing
	if ( isset( $sections['briefing'] ) ) {
		$sections['briefing']['enabled']               = (bool) get_theme_mod( 'asutsabo_show_newsletter', $sections['briefing']['enabled'] );
		$sections['briefing']['newsletter_eyebrow']    = get_theme_mod( 'asutsabo_newsletter_eyebrow', $sections['briefing']['newsletter_eyebrow'] );
		$sections['briefing']['newsletter_headline']   = get_theme_mod( 'asutsabo_newsletter_headline', $sections['briefing']['newsletter_headline'] );
		$sections['briefing']['newsletter_desc']       = get_theme_mod( 'asutsabo_newsletter_description', $sections['briefing']['newsletter_desc'] );
		$sections['briefing']['newsletter_btn_text']   = get_theme_mod( 'asutsabo_newsletter_button_text', $sections['briefing']['newsletter_btn_text'] );
		$sections['briefing']['newsletter_btn_url']    = get_theme_mod( 'asutsabo_newsletter_button_url', $sections['briefing']['newsletter_btn_url'] );
		$sections['briefing']['newsletter_disclaimer'] = get_theme_mod( 'asutsabo_newsletter_disclaimer', $sections['briefing']['newsletter_disclaimer'] );
		$updated = true;
	}

	if ( $updated ) {
		update_option( 'asutsabo_homepage_sections', $sections );
	}
}
add_action( 'customize_save_after', 'asutsabo_sync_customizer_to_builder' );
