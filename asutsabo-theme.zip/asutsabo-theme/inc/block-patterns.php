<?php
/**
 * Asutsabo Pattern Categories.
 *
 * Registers pattern categories for editorial layouts.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register pattern categories.
 */
function asutsabo_register_pattern_categories() {
	$categories = array(
		'asutsabo-header'      => array(
			'label' => __( 'Asutsabo: Headers & Mastheads', 'asutsabo' ),
		),
		'asutsabo-homepage'    => array(
			'label' => __( 'Asutsabo: Homepage Sections', 'asutsabo' ),
		),
		'asutsabo-article'     => array(
			'label' => __( 'Asutsabo: Article Elements', 'asutsabo' ),
		),
		'asutsabo-footer'      => array(
			'label' => __( 'Asutsabo: Footers', 'asutsabo' ),
		),
		'asutsabo-pages'       => array(
			'label' => __( 'Asutsabo: Starter Pages', 'asutsabo' ),
		),
		'asutsabo-advertising' => array(
			'label' => __( 'Asutsabo: Advertising Slots', 'asutsabo' ),
		),
	);

	foreach ( $categories as $slug => $properties ) {
		register_block_pattern_category( $slug, $properties );
	}
}
add_action( 'init', 'asutsabo_register_pattern_categories' );
