<?php
/**
 * Asutsabo Structured Data & Technical SEO Fallback.
 *
 * Emits schema.org NewsArticle JSON-LD for singular posts when no third-party
 * SEO plugin is active to avoid conflicting or duplicate structured data.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks whether an active SEO plugin is handling metadata and schema.
 *
 * @return bool True if a known SEO plugin is active, false otherwise.
 */
function asutsabo_has_active_seo_plugin() {
	// Yoast SEO
	if ( defined( 'WPSEO_VERSION' ) ) {
		return true;
	}

	// Rank Math
	if ( defined( 'RANK_MATH_VERSION' ) ) {
		return true;
	}

	// All in One SEO (AIOSEO)
	if ( defined( 'AIOSEO_VERSION' ) ) {
		return true;
	}

	// The SEO Framework
	if ( defined( 'THE_SEO_FRAMEWORK_VERSION' ) ) {
		return true;
	}

	// SEOPress
	if ( defined( 'SEOPRESS_VERSION' ) ) {
		return true;
	}

	// Slim SEO
	if ( defined( 'SLIM_SEO_VER' ) ) {
		return true;
	}

	return false;
}

/**
 * Emits fallback NewsArticle JSON-LD in the document head.
 */
function asutsabo_output_structured_data() {
	// Only apply to single posts.
	if ( ! is_singular( 'post' ) ) {
		return;
	}

	// Suppress if an SEO plugin is detected.
	if ( asutsabo_has_active_seo_plugin() ) {
		return;
	}

	// Allow developers to disable via filter.
	if ( apply_filters( 'asutsabo_disable_structured_data', false ) ) {
		return;
	}

	$post = get_queried_object();
	if ( ! $post instanceof WP_Post ) {
		return;
	}

	$post_id   = $post->ID;
	$title     = wp_strip_all_tags( get_the_title( $post_id ) );
	$excerpt   = wp_strip_all_tags( get_the_excerpt( $post_id ) );
	$permalink = get_permalink( $post_id );
	$published = get_the_date( 'c', $post_id );
	$modified  = get_the_modified_date( 'c', $post_id );

	$author_id   = $post->post_author;
	$author_name = get_the_author_meta( 'display_name', $author_id );
	$author_url  = get_author_posts_url( $author_id );

	$site_name = get_bloginfo( 'name' );
	$site_url  = home_url( '/' );

	// Build Schema.org NewsArticle object.
	$schema = array(
		'@context'         => 'https://schema.org',
		'@type'            => 'NewsArticle',
		'mainEntityOfPage' => array(
			'@type' => 'WebPage',
			'@id'   => esc_url( $permalink ),
		),
		'headline'         => $title,
		'description'      => $excerpt,
		'datePublished'    => $published,
		'dateModified'     => $modified,
		'author'           => array(
			'@type' => 'Person',
			'name'  => esc_html( $author_name ),
			'url'   => esc_url( $author_url ),
		),
		'publisher'        => array(
			'@type' => 'Organization',
			'name'  => esc_html( $site_name ),
			'url'   => esc_url( $site_url ),
		),
	);

	// Include custom site logo if set.
	$custom_logo_id = get_theme_mod( 'custom_logo' );
	if ( $custom_logo_id ) {
		$logo_data = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		if ( $logo_data ) {
			$schema['publisher']['logo'] = array(
				'@type'  => 'ImageObject',
				'url'    => esc_url( $logo_data[0] ),
				'width'  => (int) $logo_data[1],
				'height' => (int) $logo_data[2],
			);
		}
	}

	// Include featured image if set.
	if ( has_post_thumbnail( $post_id ) ) {
		$image_id   = get_post_thumbnail_id( $post_id );
		$image_data = wp_get_attachment_image_src( $image_id, 'full' );
		if ( $image_data ) {
			$schema['image'] = array(
				'@type'  => 'ImageObject',
				'url'    => esc_url( $image_data[0] ),
				'width'  => (int) $image_data[1],
				'height' => (int) $image_data[2],
			);
		}
	}

	// Output clean escaped JSON-LD script tag.
	$json_string = wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	if ( $json_string ) {
		echo "\n" . '<script type="application/ld+json">' . $json_string . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	// BreadcrumbList schema
	$categories = get_the_category( $post_id );
	if ( ! empty( $categories ) ) {
		$primary_cat = $categories[0];
		$breadcrumb_schema = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => array(
				array(
					'@type'    => 'ListItem',
					'position' => 1,
					'name'     => get_bloginfo( 'name' ),
					'item'     => home_url( '/' ),
				),
				array(
					'@type'    => 'ListItem',
					'position' => 2,
					'name'     => $primary_cat->name,
					'item'     => get_category_link( $primary_cat->term_id ),
				),
				array(
					'@type'    => 'ListItem',
					'position' => 3,
					'name'     => $title,
					'item'     => $permalink,
				),
			),
		);
		$bc_json = wp_json_encode( $breadcrumb_schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( $bc_json ) {
			echo '<script type="application/ld+json">' . $bc_json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
}
add_action( 'wp_head', 'asutsabo_output_structured_data', 15 );

/**
 * Output WebSite and Organization JSON-LD on front page when no SEO plugin active.
 */
function asutsabo_output_front_page_schema() {
	if ( ! ( is_front_page() || is_home() ) ) {
		return;
	}
	if ( asutsabo_has_active_seo_plugin() ) {
		return;
	}

	$site_name = get_bloginfo( 'name' );
	$site_desc = get_bloginfo( 'description' );
	$site_url  = home_url( '/' );

	$schema = array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			array(
				'@type'       => 'WebSite',
				'@id'         => esc_url( $site_url ) . '#website',
				'url'         => esc_url( $site_url ),
				'name'        => esc_html( $site_name ),
				'description' => esc_html( $site_desc ),
				'potentialAction' => array(
					'@type'       => 'SearchAction',
					'target'      => esc_url( $site_url ) . '?s={search_term_string}',
					'query-input' => 'required name=search_term_string',
				),
			),
			array(
				'@type' => 'NewsMediaOrganization',
				'@id'   => esc_url( $site_url ) . '#organization',
				'name'  => esc_html( $site_name ),
				'url'   => esc_url( $site_url ),
			),
		),
	);

	$json_string = wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	if ( $json_string ) {
		echo "\n" . '<script type="application/ld+json">' . $json_string . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
add_action( 'wp_head', 'asutsabo_output_front_page_schema', 15 );

/**
 * Output Open Graph and Twitter Card metadata when no SEO plugin active.
 */
function asutsabo_output_social_meta_tags() {
	if ( asutsabo_has_active_seo_plugin() ) {
		return;
	}

	$site_name = get_bloginfo( 'name' );
	$og_title  = wp_get_document_title();
	$og_url    = is_singular() ? get_permalink() : home_url( '/' );
	$og_type   = is_singular( 'post' ) ? 'article' : 'website';
	$og_desc   = '';
	$og_image  = '';
	$author_tw = '';
	$pub_time  = '';
	$mod_time  = '';
	$section   = '';

	if ( is_singular() ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			$og_desc  = wp_strip_all_tags( get_the_excerpt( $post->ID ) );
			$pub_time = get_the_date( 'c', $post->ID );
			$mod_time = get_the_modified_date( 'c', $post->ID );
			$cats     = get_the_category( $post->ID );
			if ( ! empty( $cats ) ) {
				$section = $cats[0]->name;
			}
			$author_tw = get_the_author_meta( 'asutsabo_twitter', $post->post_author );

			if ( has_post_thumbnail( $post->ID ) ) {
				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large' );
				if ( $thumb ) {
					$og_image = $thumb[0];
				}
			}
		}
	} else {
		$og_desc = get_bloginfo( 'description' );
	}

	// Fallback image to site icon or custom logo if available
	if ( empty( $og_image ) ) {
		if ( has_site_icon() ) {
			$og_image = get_site_icon_url( 512 );
		} elseif ( has_custom_logo() ) {
			$logo_src = wp_get_attachment_image_src( get_theme_mod( 'custom_logo' ), 'full' );
			if ( $logo_src ) {
				$og_image = $logo_src[0];
			}
		}
	}

	echo "\n<!-- Asutsabo Fallback SEO Meta -->\n";
	echo '<meta property="og:site_name" content="' . esc_attr( $site_name ) . '" />' . "\n";
	echo '<meta property="og:type" content="' . esc_attr( $og_type ) . '" />' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
	if ( ! empty( $og_desc ) ) {
		echo '<meta property="og:description" content="' . esc_attr( $og_desc ) . '" />' . "\n";
	}
	echo '<meta property="og:url" content="' . esc_url( $og_url ) . '" />' . "\n";

	if ( is_singular( 'post' ) ) {
		if ( ! empty( $pub_time ) ) {
			echo '<meta property="article:published_time" content="' . esc_attr( $pub_time ) . '" />' . "\n";
		}
		if ( ! empty( $mod_time ) ) {
			echo '<meta property="article:modified_time" content="' . esc_attr( $mod_time ) . '" />' . "\n";
		}
		if ( ! empty( $section ) ) {
			echo '<meta property="article:section" content="' . esc_attr( $section ) . '" />' . "\n";
		}
	}

	if ( ! empty( $og_image ) ) {
		echo '<meta property="og:image" content="' . esc_url( $og_image ) . '" />' . "\n";
		echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
		echo '<meta name="twitter:image" content="' . esc_url( $og_image ) . '" />' . "\n";
	} else {
		echo '<meta name="twitter:card" content="summary" />' . "\n";
	}
	echo '<meta name="twitter:title" content="' . esc_attr( $og_title ) . '" />' . "\n";
	if ( ! empty( $og_desc ) ) {
		echo '<meta name="twitter:description" content="' . esc_attr( $og_desc ) . '" />' . "\n";
	}
	if ( ! empty( $author_tw ) ) {
		$tw_handle = '@' . ltrim( preg_replace( '#^https?://(www\.)?(twitter|x)\.com/#i', '', $author_tw ), '@' );
		echo '<meta name="twitter:creator" content="' . esc_attr( $tw_handle ) . '" />' . "\n";
	}
	echo "<!-- /Asutsabo Fallback SEO Meta -->\n\n";
}
add_action( 'wp_head', 'asutsabo_output_social_meta_tags', 10 );
