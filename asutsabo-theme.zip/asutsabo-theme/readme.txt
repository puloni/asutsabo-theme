=== Asutsabo ===
Contributors: unheard
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A serious, professional, modern digital newspaper and magazine theme designed for Unheard (https://unheard.me).

== Description ==

Asutsabo is an editorial WordPress magazine theme engineered for professional digital newspapers, journals, magazines, and serious online publications. Built on a battle-tested classic and hybrid PHP template architecture, Asutsabo delivers authentic broad-sheet aesthetics: sharp typographic hierarchy, information-dense multi-story grids, breaking news ticker, comprehensive article metadata, staff author profiles, widgetized sidebars, and customizable navigation menus.

Features:
* Classic/Hybrid PHP template architecture (header.php, footer.php, front-page.php, single.php, etc.) with theme.json for editor color/font palettes.
* Standard WordPress navigation menus (Primary, Top Bar, Footer) manageable via Appearance > Menus with optional sticky header.
* Standard dynamic widget areas (Primary Sidebar, Homepage Top/Middle/Bottom, Footer Columns 1-4) with full sidebar support across articles, pages, and archive views.
* Custom Page Templates: Page with Sidebar, Full Width (No Sidebar), and Newsroom Staff & Editorial Directory.
* Built-in One-Click Demo Import (Appearance > Demo Import) with 48 editorial articles, 14 categories, staff author profiles, 11 standard editorial pages, and local media attachments. Zero third-party plugin requirements.
* Broad-sheet front page featuring Fast Wire service, Lead Story & Top Dispatches, Editor's Picks showcase, 2-column Category desks, Opinion columns with author avatars, Multimedia & Video Showcase, Trending / Most Read ranking, and responsive ad containers.
* Duplicate story prevention ensuring unique headlines across homepage desks with graceful fallbacks.
* Reading enhancements: scroll reading progress bar, reader preferences toolbar (font size resizer and Light/Sepia/Dark mode switch with localStorage persistence), auto-generated collapsible Table of Contents, floating Back-to-Top button.
* Comprehensive article reading experience with category kickers, drop caps, pull quotes, bylines, reading time indicators, social sharing (with Bluesky and copy link), Audio Dispatch player ("Listen to Story"), editorial correction/clarification notices, and related coverage.
* Staff Journalist & Author enhancement: editorial role/beat titles, social profile links (Twitter/X, LinkedIn, Bluesky, website), and full Newsroom Directory page template.
* Multi-headline breaking news ticker carousel with auto-rotation, pause on hover, manual controls, and smart post-specific dismiss persistence.
* Interactive homepage briefing newsletter signup form with email input.
* Fully accessible (WCAG 2.2 AA target) with visible focus indicators, skip links, semantic landmarks, and keyboard-friendly mobile navigation.
* SEO structured data fallback (Article / NewsArticle schema, Open Graph, Twitter Cards) with automatic suppression when major SEO plugins are active.
* 100% responsive, zero external CDN dependencies, lightweight, and performance-optimized.

== Installation ==

1. In your WordPress admin dashboard, navigate to Appearance > Themes.
2. Activate "Asutsabo".
3. (Recommended) Navigate to Appearance > Demo Import and click "Import Demo Content Now" to populate your site with a full digital newspaper setup.
4. Go to Appearance > Menus to customize your navigation menus, and Appearance > Widgets to configure your sidebars.

== Copyright ==

Asutsabo WordPress Theme, (C) 2026 Unheard
Asutsabo is distributed under the terms of the GNU General Public License v2 or later.
