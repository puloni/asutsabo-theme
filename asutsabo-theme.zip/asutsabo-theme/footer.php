<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
	</div><!-- #content -->

	<footer id="colophon" class="site-footer asutsabo-site-footer" style="border-top:3px solid var(--wp--preset--color--border-dark, #2B2927);background-color:var(--wp--preset--color--base, #FAF8F5);margin-top:4rem;">
		<?php get_template_part( 'template-parts/footer/footer-widgets' ); ?>

		<div class="asutsabo-container alignwide">
			<hr class="wp-block-separator is-style-asutsabo-divider-thick" style="margin:2.5rem 0 1.5rem 0;" />

			<div class="asutsabo-footer-bottom" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1.5rem;padding-bottom:2.5rem;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.8125rem;color:var(--wp--preset--color--muted, #6E6B65);">
				<?php asutsabo_render_copyright(); ?>

				<?php asutsabo_render_footer_social(); ?>

				<div class="asutsabo-footer-secondary-nav">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'footer',
							'container'      => 'nav',
							'container_class'=> 'footer-navigation asutsabo-footer-nav',
							'menu_class'     => 'footer-menu asutsabo-footer-menu',
							'depth'          => 1,
							'fallback_cb'    => '__return_false',
						)
					);
					?>
				</div>
			</div>
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php asutsabo_render_back_to_top(); ?>

<?php wp_footer(); ?>

</body>
</html>
