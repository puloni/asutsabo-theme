<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_active_sidebar( 'primary-sidebar' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area asutsabo-sidebar asutsabo-primary-sidebar" aria-label="<?php esc_attr_e( 'Primary Sidebar', 'asutsabo' ); ?>">
	<?php dynamic_sidebar( 'primary-sidebar' ); ?>
</aside><!-- #secondary -->
