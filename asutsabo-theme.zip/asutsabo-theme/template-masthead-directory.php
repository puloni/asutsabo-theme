<?php
/**
 * Template Name: Newsroom Staff & Editorial Directory
 * Description: Editorial masthead directory displaying journalists, editors, and columnists.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$authors = get_users(
	array(
		'has_published_posts' => array( 'post' ),
		'orderby'             => 'post_count',
		'order'               => 'DESC',
	)
);
$hide_title = (bool) get_post_meta( get_the_ID(), '_asutsabo_hide_title', true );
?>

<main id="primary-content" class="site-main asutsabo-masthead-directory asutsabo-container alignwide" style="padding-top:2.5rem;padding-bottom:4rem;">
	<?php if ( ! $hide_title ) : ?>
		<header class="page-header asutsabo-directory-header" style="text-align:center;border-bottom:2px solid var(--wp--preset--color--border-dark, #2B2927);padding-bottom:2rem;margin-bottom:3rem;">
			<span class="is-style-asutsabo-kicker"><?php esc_html_e( 'The Editorial Board & Masthead', 'asutsabo' ); ?></span>
			<h1 class="page-title is-style-asutsabo-featured-headline" style="margin:0.5rem 0 1rem 0;">
				<?php the_title(); ?>
			</h1>
			<p style="font-size:1.15rem;color:var(--wp--preset--color--secondary, #474542);max-width:680px;margin:0 auto;line-height:1.6;">
				<?php esc_html_e( 'Meet the journalists, editors, investigative reporters, and cultural critics reporting across our news desks.', 'asutsabo' ); ?>
			</p>
		</header>
	<?php endif; ?>

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php if ( get_the_content() ) : ?>
			<div class="asutsabo-directory-intro" style="max-width:760px;margin:0 auto 3rem auto;font-size:1.125rem;line-height:1.75;">
				<?php the_content(); ?>
			</div>
		<?php endif; ?>
	<?php endwhile; endif; ?>

	<?php if ( ! empty( $authors ) ) : ?>
		<div class="asutsabo-grid asutsabo-staff-grid" style="display:grid;grid-template-columns:repeat(auto-fill, minmax(320px, 1fr));gap:2rem;">
			<?php foreach ( $authors as $author ) :
				$aid      = $author->ID;
				$role     = get_user_meta( $aid, 'asutsabo_job_title', true );
				$twitter  = get_user_meta( $aid, 'asutsabo_twitter', true );
				$linkedin = get_user_meta( $aid, 'asutsabo_linkedin', true );
				$bluesky  = get_user_meta( $aid, 'asutsabo_bluesky', true );
				$url      = get_the_author_meta( 'user_url', $aid );
				$posts_ct = count_user_posts( $aid );
				?>
				<div class="asutsabo-staff-card" style="border:1px solid var(--wp--preset--color--border, #DED9D0);background:var(--wp--preset--color--surface, #ffffff);padding:1.5rem;display:flex;flex-direction:column;justify-content:space-between;">
					<div>
						<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem;">
							<?php echo get_avatar( $aid, 68, '', '', array( 'style' => 'border-radius:50%;flex-shrink:0;' ) ); ?>
							<div>
								<h3 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.25rem;margin:0 0 0.25rem 0;line-height:1.2;">
									<a href="<?php echo esc_url( get_author_posts_url( $aid ) ); ?>" style="color:inherit;text-decoration:none;">
										<?php echo esc_html( $author->display_name ); ?>
									</a>
								</h3>
								<?php if ( ! empty( $role ) ) : ?>
									<span class="is-style-asutsabo-metadata" style="font-weight:700;color:var(--wp--preset--color--kicker, #94181E);display:block;">
										<?php echo esc_html( $role ); ?>
									</span>
								<?php endif; ?>
							</div>
						</div>

						<?php if ( ! empty( $author->description ) ) : ?>
							<p style="font-size:0.875rem;line-height:1.6;color:var(--wp--preset--color--secondary, #474542);margin:0 0 1rem 0;">
								<?php echo esc_html( wp_trim_words( $author->description, 28, '...' ) ); ?>
							</p>
						<?php endif; ?>
					</div>

					<div style="border-top:1px solid var(--wp--preset--color--border, #DED9D0);padding-top:0.75rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.5rem;">
						<span class="is-style-asutsabo-metadata">
							<?php printf( esc_html__( '%d Dispatches', 'asutsabo' ), (int) $posts_ct ); ?>
						</span>

						<div class="asutsabo-staff-socials" style="display:flex;align-items:center;gap:0.5rem;">
							<?php if ( ! empty( $twitter ) ) :
								$t_url = ( strpos( $twitter, 'http' ) === 0 ) ? $twitter : 'https://x.com/' . ltrim( $twitter, '@' );
								?>
								<a href="<?php echo esc_url( $t_url ); ?>" target="_blank" rel="noopener noreferrer" style="color:inherit;" aria-label="<?php esc_attr_e( 'Twitter', 'asutsabo' ); ?>">
									<?php echo asutsabo_get_social_icon_svg( 'twitter' ); ?>
								</a>
							<?php endif; ?>
							<?php if ( ! empty( $linkedin ) ) :
								$li_url = ( strpos( $linkedin, 'http' ) === 0 ) ? $linkedin : 'https://linkedin.com/in/' . $linkedin;
								?>
								<a href="<?php echo esc_url( $li_url ); ?>" target="_blank" rel="noopener noreferrer" style="color:inherit;" aria-label="<?php esc_attr_e( 'LinkedIn', 'asutsabo' ); ?>">
									<?php echo asutsabo_get_social_icon_svg( 'linkedin' ); ?>
								</a>
							<?php endif; ?>
							<?php if ( ! empty( $bluesky ) ) :
								$bsky_url = ( strpos( $bluesky, 'http' ) === 0 ) ? $bluesky : 'https://bsky.app/profile/' . ltrim( $bluesky, '@' );
								?>
								<a href="<?php echo esc_url( $bsky_url ); ?>" target="_blank" rel="noopener noreferrer" style="color:inherit;" aria-label="<?php esc_attr_e( 'Bluesky', 'asutsabo' ); ?>">
									<?php echo asutsabo_get_social_icon_svg( 'bluesky' ); ?>
								</a>
							<?php endif; ?>
							<a href="<?php echo esc_url( get_author_posts_url( $aid ) ); ?>" style="font-size:0.75rem;font-weight:700;text-transform:uppercase;color:inherit;text-decoration:none;margin-left:0.25rem;">
								<?php esc_html_e( 'View Articles', 'asutsabo' ); ?> &rarr;
							</a>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</main><!-- #primary-content -->

<?php
get_footer();
