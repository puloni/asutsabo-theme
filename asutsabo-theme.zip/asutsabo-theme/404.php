<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary-content" class="site-main asutsabo-404-main asutsabo-container alignwide" style="padding-top:3.5rem;padding-bottom:5rem;max-width:860px;margin:0 auto;">
	<header class="page-header asutsabo-404-header" style="margin-bottom:2.5rem;">
		<span class="is-style-asutsabo-kicker"><?php esc_html_e( 'Error 404 &bull; Missing Dispatch', 'asutsabo' ); ?></span>
		<h1 class="page-title is-style-asutsabo-featured-headline" style="margin:0.35rem 0 1rem 0;">
			<?php esc_html_e( 'This page has disappeared from the edition.', 'asutsabo' ); ?>
		</h1>
		<p class="is-style-asutsabo-lead-paragraph" style="margin-bottom:2rem;">
			<?php esc_html_e( 'The story may have been moved, archived, or the URL entered may be inaccurate. You can return to our homepage, search our archives, or explore the recent dispatches below.', 'asutsabo' ); ?>
		</p>

		<div class="asutsabo-404-actions" style="display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:2rem;">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="asutsabo-btn asutsabo-btn-primary" style="display:inline-block;padding:0.75rem 1.5rem;background:var(--wp--preset--color--primary, #181716);color:#ffffff;text-decoration:none;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;font-weight:700;border-radius:2px;">
				<?php esc_html_e( 'Return to Homepage', 'asutsabo' ); ?>
			</a>
			<a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ? get_permalink( get_option( 'page_for_posts' ) ) : home_url( '/' ) ); ?>" class="asutsabo-btn asutsabo-btn-outline" style="display:inline-block;padding:0.75rem 1.5rem;border:1px solid var(--wp--preset--color--border-dark, #2B2927);color:var(--wp--preset--color--contrast, #141413);text-decoration:none;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;font-weight:700;border-radius:2px;">
				<?php esc_html_e( 'Browse Latest News', 'asutsabo' ); ?>
			</a>
		</div>

		<div class="asutsabo-404-search" style="max-width:560px;margin-bottom:3rem;">
			<?php get_search_form(); ?>
		</div>
	</header>

	<hr class="wp-block-separator is-style-asutsabo-divider-thick" style="margin:2.5rem 0;" />

	<!-- Recent Wire Updates -->
	<section class="asutsabo-404-recent-stories">
		<h2 class="is-style-asutsabo-section-label"><?php esc_html_e( 'Recent Headlines', 'asutsabo' ); ?></h2>
		<?php
		$recent_query = new WP_Query(
			array(
				'posts_per_page'      => 6,
				'ignore_sticky_posts' => 1,
				'post_status'         => 'publish',
			)
		);
		if ( $recent_query->have_posts() ) :
			?>
			<div class="asutsabo-wire-list" style="display:grid;grid-template-columns:1fr;gap:0.75rem;">
				<?php
				while ( $recent_query->have_posts() ) :
					$recent_query->the_post();
					?>
					<div class="asutsabo-wire-item" style="display:flex;align-items:baseline;padding:0.5rem 0;border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);gap:1rem;">
						<time class="asutsabo-wire-time is-style-asutsabo-metadata" datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>" style="font-family:var(--wp--preset--font-family--mono, monospace);font-size:0.8rem;flex-shrink:0;">
							<?php echo esc_html( get_the_date( 'M j, H:i' ) ); ?>
						</time>
						<a href="<?php the_permalink(); ?>" class="asutsabo-wire-title" style="font-size:1rem;font-weight:600;color:inherit;text-decoration:none;line-height:1.35;">
							<?php the_title(); ?>
						</a>
					</div>
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			</div>
		<?php endif; ?>
	</section>
</main><!-- #primary-content -->

<?php
get_footer();
