<?php
/**
 * The template for displaying comments.
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area asutsabo-comments-area" style="margin-top:3rem;padding-top:2rem;border-top:2px solid var(--wp--preset--color--primary, #181716);">

	<?php if ( have_comments() ) : ?>
		<h3 class="comments-title is-style-asutsabo-section-label">
			<?php
			$asutsabo_comment_count = get_comments_number();
			if ( '1' === $asutsabo_comment_count ) {
				printf(
					/* translators: 1: title. */
					esc_html__( 'One Comment on &ldquo;%1$s&rdquo;', 'asutsabo' ),
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			} else {
				printf(
					/* translators: 1: comment count number, 2: title. */
					esc_html( _nx( '%1$s Comment on &ldquo;%2$s&rdquo;', '%1$s Comments on &ldquo;%2$s&rdquo;', $asutsabo_comment_count, 'comments title', 'asutsabo' ) ),
					number_format_i18n( $asutsabo_comment_count ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			}
			?>
		</h3>

		<ol class="comment-list asutsabo-comment-list" style="list-style:none;padding:0;margin:1.5rem 0;">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation(
			array(
				'prev_text' => esc_html__( '&larr; Older Comments', 'asutsabo' ),
				'next_text' => esc_html__( 'Newer Comments &rarr;', 'asutsabo' ),
			)
		);
		?>

	<?php endif; // Check for have_comments(). ?>

	<?php
	// If comments are closed and there are comments, let's leave a little note, shall we?
	if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) :
		?>
		<p class="no-comments is-style-asutsabo-metadata"><?php esc_html_e( 'Comments are closed for this dispatch.', 'asutsabo' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'title_reply'        => esc_html__( 'Leave a Commentary', 'asutsabo' ),
			'title_reply_to'     => esc_html__( 'Reply to %s', 'asutsabo' ),
			'class_submit'       => 'asutsabo-btn asutsabo-btn-primary',
			'submit_button'      => '<input name="%1$s" type="submit" id="%2$s" class="%3$s" value="%4$s" style="padding:0.6rem 1.5rem;background:var(--wp--preset--color--primary, #181716);color:#ffffff;border:none;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;font-weight:700;cursor:pointer;border-radius:2px;" />',
		)
	);
	?>

</div><!-- #comments -->
