<?php
/**
 * Title: 3-Column Editorial Grid
 * Slug: asutsabo/grid-three-column
 * Categories: asutsabo-homepage
 * Description: Three-column broadsheet article grid with images, headlines, and excerpts.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignwide">
	<!-- wp:heading {"level":2,"className":"is-style-asutsabo-section-label"} -->
	<h2 class="wp-block-heading is-style-asutsabo-section-label">Featured Investigations</h2>
	<!-- /wp:heading -->

	<!-- wp:query {"queryId":13,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
	<div class="wp-block-query">
		<!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"border":{"bottom":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"padding":{"bottom":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
		<div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;border-bottom-style:solid;padding-bottom:var(--wp--preset--spacing--30)">
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2"} /-->
			<!-- wp:post-terms {"term":"category","fontSize":"x-small"} /-->
			<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"large","style":{"typography":{"lineHeight":"1.2"}}} /-->
			<!-- wp:post-excerpt {"showMoreOnNewLine":false,"fontSize":"small"} /-->
			<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|10"}}}} -->
			<div class="wp-block-group">
				<!-- wp:post-author-name {"isLink":true,"fontSize":"x-small"} /-->
				<!-- wp:post-date {"fontSize":"x-small"} /-->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph -->
		<p>No articles found.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
