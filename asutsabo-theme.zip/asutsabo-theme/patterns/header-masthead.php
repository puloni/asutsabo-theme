<?php
/**
 * Title: Editorial Masthead Header
 * Slug: asutsabo/header-masthead
 * Categories: asutsabo-header
 * Description: Broad-sheet newspaper masthead with date, site title, navigation and search.
 * Inserter: true
 */
?>
<!-- wp:group {"tagName":"header","className":"asutsabo-site-header","layout":{"type":"constrained"}} -->
<header class="wp-block-group asutsabo-site-header">
	<!-- wp:html -->
	<a class="skip-link" href="#primary-content">Skip to content</a>
	<!-- /wp:html -->

	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexDirection":"column","justifyContent":"center"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|30"}}}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:site-logo {"width":80,"shouldNavigationBeDisplayed":false,"align":"center"} /-->
		<!-- wp:site-title {"level":1,"textAlign":"center","style":{"typography":{"fontFamily":"var:preset|font-family|serif","fontSize":"clamp(2.75rem, 7vw, 4.75rem)","letterSpacing":"-0.03em","fontWeight":"800","lineHeight":"1"}}} /-->
		<!-- wp:site-tagline {"textAlign":"center","fontSize":"small","style":{"typography":{"fontFamily":"var:preset|font-family|sans","letterSpacing":"0.08em","textTransform":"uppercase","fontStyle":"normal"},"spacing":{"margin":{"top":"var:preset|spacing|10"}}}} /-->
	</div>
	<!-- /wp:group -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-double","align":"wide"} -->
	<hr class="wp-block-separator alignwide has-alpha-channel-opacity is-style-asutsabo-divider-double"/>
	<!-- /wp:separator -->

	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"border":{"bottom":{"color":"var:preset|color|border-dark","width":"2px"}}}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:navigation {"layout":{"type":"flex","justifyContent":"left","orientation":"horizontal"},"style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontWeight":"700","fontSize":"0.875rem","textTransform":"uppercase","letterSpacing":"0.05em"}}} /-->

		<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","alignItems":"center"}} -->
		<div class="wp-block-group">
			<!-- wp:search {"label":"Search","showLabel":false,"buttonText":"Search","buttonPosition":"button-inside","buttonUseIcon":true,"isSearchFieldHidden":false,"style":{"border":{"radius":"2px"}}} /-->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</header>
<!-- /wp:group -->
