<?php
/**
 * Title: Advertisement In-Feed (728x90)
 * Slug: asutsabo/ad-infeed
 * Categories: asutsabo-advertising
 * Description: In-feed article stream advertising slot with reserved dimensions.
 * Inserter: true
 */
?>
<!-- wp:group {"className":"asutsabo-ad-placeholder asutsabo-ad-infeed","layout":{"type":"flex","flexDirection":"column","justifyContent":"center"}} -->
<div class="wp-block-group asutsabo-ad-placeholder asutsabo-ad-infeed">
	<span class="asutsabo-ad-label">Sponsored Announcement</span>
	<span class="asutsabo-ad-dims">728 &times; 90</span>
</div>
<!-- /wp:group -->
