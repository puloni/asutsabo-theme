<?php
/**
 * Title: Compact Header
 * Slug: asutsabo/header-compact
 * Categories: asutsabo-header
 * Description: Streamlined single-row header for focused reading.
 * Inserter: true
 */
?>
<!-- wp:group {"tagName":"header","className":"asutsabo-header-compact","layout":{"type":"constrained"},"style":{"border":{"bottom":{"color":"var:preset|color|border","width":"1px"}}}} -->
<header class="wp-block-group asutsabo-header-compact">
	<!-- wp:html -->
	<a class="skip-link" href="#primary-content">Skip to content</a>
	<!-- /wp:html -->
	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","alignItems":"center"}} -->
		<div class="wp-block-group">
			<!-- wp:site-logo {"width":36,"shouldNavigationBeDisplayed":false} /-->
			<!-- wp:site-title {"level":2,"style":{"typography":{"fontFamily":"var:preset|font-family|serif","fontSize":"1.375rem","fontWeight":"800"}}} /-->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","alignItems":"center"}} -->
		<div class="wp-block-group">
			<!-- wp:navigation {"layout":{"type":"flex","orientation":"horizontal"},"style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontSize":"0.875rem","fontWeight":"600"}}} /-->
			<!-- wp:search {"label":"Search","showLabel":false,"buttonText":"Search","buttonPosition":"button-inside","buttonUseIcon":true,"isSearchFieldHidden":false,"style":{"border":{"radius":"2px"}}} /-->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->
</header>
<!-- /wp:group -->
