<?php
/**
 * Title: Compact Footer
 * Slug: asutsabo/footer-compact
 * Categories: asutsabo-footer
 * Description: Minimal single-row footer with copyright and essential links.
 * Inserter: true
 */
?>
<!-- wp:group {"className":"asutsabo-footer-compact","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}},"border":{"top":{"color":"var:preset|color|border","width":"1px"}}}} -->
<div class="wp-block-group asutsabo-footer-compact">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:paragraph {"fontSize":"x-small","style":{"color":{"text":"var:preset|color|muted"}}} -->
		<p class="has-muted-color has-text-color has-x-small-font-size">&copy; Unheard. All rights reserved.</p>
		<!-- /wp:paragraph -->
		<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"horizontal"},"style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontSize":"0.75rem"}}} /-->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
