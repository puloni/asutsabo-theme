<?php
/**
 * Title: Advertisement Leaderboard (970x90)
 * Slug: asutsabo/ad-leaderboard
 * Categories: asutsabo-advertising
 * Description: Standard IAB leaderboard advertising slot with reserved dimensions to prevent CLS.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","className":"asutsabo-ad-placeholder asutsabo-ad-leaderboard","layout":{"type":"flex","flexDirection":"column","justifyContent":"center"}} -->
<div class="wp-block-group alignwide asutsabo-ad-placeholder asutsabo-ad-leaderboard">
	<span class="asutsabo-ad-label">Advertisement</span>
	<span class="asutsabo-ad-dims">970 &times; 90 / 728 &times; 90</span>
</div>
<!-- /wp:group -->
