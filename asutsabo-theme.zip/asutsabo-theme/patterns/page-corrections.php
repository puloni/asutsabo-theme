<?php
/**
 * Title: Corrections Policy & Archive Page
 * Slug: asutsabo/page-corrections
 * Categories: asutsabo-pages
 * Description: Editorial corrections charter and transparent record of factual revisions.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
	<p class="is-style-asutsabo-kicker">Accountability</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"className":"is-style-asutsabo-featured-headline"} -->
	<h1 class="wp-block-heading is-style-asutsabo-featured-headline">Corrections Policy &amp; Public Record</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
	<p class="is-style-asutsabo-lead-paragraph">Unheard is dedicated to publishing verified facts. When errors occur, we correct the record promptly, transparently, and unreservedly.</p>
	<!-- /wp:paragraph -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-thick"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-thick"/>
	<!-- /wp:separator -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">How We Handle Corrections</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Substantive factual errors in articles are updated immediately in the text, accompanied by a clearly marked editorial correction note at the bottom or top of the piece detailing the date and nature of the revision.</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">Requesting a Correction</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>If you identify a factual error in our reporting, please contact the standards desk directly at <strong>corrections@unheard.me</strong> with the article URL, the specific passage, and supporting documentation.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
