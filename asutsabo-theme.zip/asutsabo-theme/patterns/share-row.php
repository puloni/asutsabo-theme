<?php
/**
 * Title: Article Social Share Row
 * Slug: asutsabo/share-row
 * Categories: asutsabo-article
 * Description: Accessible social sharing toolbar with Web Share API and clipboard copy support.
 * Inserter: true
 */
?>
<!-- wp:group {"className":"asutsabo-share-row","layout":{"type":"flex","flexWrap":"wrap","alignItems":"center"}} -->
<div class="wp-block-group asutsabo-share-row">
	<span class="asutsabo-share-label">Share:</span>

	<!-- wp:html -->
	<button type="button" class="asutsabo-share-btn asutsabo-share-native" style="display:none;" aria-label="Share article via device dialog">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/></svg>
		<span>Share</span>
	</button>
	<button type="button" class="asutsabo-share-btn asutsabo-share-copy" aria-label="Copy link to article">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg>
		<span>Copy Link</span>
	</button>
	<a class="asutsabo-share-btn asutsabo-share-x" href="https://twitter.com/share" target="_blank" rel="noopener noreferrer" aria-label="Share on X (formerly Twitter)">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
		<span>X</span>
	</a>
	<a class="asutsabo-share-btn asutsabo-share-fb" href="https://www.facebook.com/sharer/sharer.php" target="_blank" rel="noopener noreferrer" aria-label="Share on Facebook">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"/></svg>
		<span>Facebook</span>
	</a>
	<a class="asutsabo-share-btn asutsabo-share-wa" href="https://api.whatsapp.com/send" target="_blank" rel="noopener noreferrer" aria-label="Share via WhatsApp">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M17.472 14.382c-.301-.15-1.78-.879-2.056-.98-.276-.1-.476-.15-.677.15-.2.3-.777.98-.952 1.18-.175.2-.351.226-.652.075-.301-.15-1.27-.468-2.42-1.493-.894-.798-1.498-1.783-1.674-2.083-.175-.3-.019-.462.132-.612.136-.135.301-.35.451-.526.151-.175.2-.3.301-.5.1-.2.05-.375-.025-.525-.075-.15-.677-1.634-.927-2.239-.244-.59-.492-.51-.676-.52l-.577-.01c-.2 0-.526.075-.802.375-.276.3-1.053 1.03-1.053 2.51 0 1.48 1.078 2.91 1.228 3.11.151.2 2.122 3.24 5.141 4.542.718.31 1.279.496 1.716.635.722.23 1.38.197 1.9-.12.58-.354.952-.98 1.053-1.48.1-.5.1-.93.07-.98-.03-.05-.23-.15-.53-.3zM12.04 2C6.51 2 2.02 6.49 2.02 12.02c0 1.77.46 3.49 1.34 5.01L2 22l5.12-1.34c1.47.8 3.13 1.23 4.92 1.23 5.53 0 10.02-4.49 10.02-10.02C22.06 6.49 17.57 2 12.04 2z"/></svg>
		<span>WhatsApp</span>
	</a>
	<a class="asutsabo-share-btn asutsabo-share-li" href="https://www.linkedin.com/sharing/share-offsite/" target="_blank" rel="noopener noreferrer" aria-label="Share on LinkedIn">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 8.76c-.97 0-1.75-.79-1.75-1.76s.78-1.76 1.75-1.76 1.75.79 1.75 1.76-.78 1.76-1.75 1.76M7.86 18.5V10.13H5.07V18.5h2.79z"/></svg>
		<span>LinkedIn</span>
	</a>
	<a class="asutsabo-share-btn asutsabo-share-tg" href="https://t.me/share/url" target="_blank" rel="noopener noreferrer" aria-label="Share via Telegram">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/></svg>
		<span>Telegram</span>
	</a>
	<a class="asutsabo-share-btn asutsabo-share-mail" href="mailto:?subject=Recommended%20Story&amp;body=Check%20out%20this%20article" aria-label="Share article via email">
		<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
		<span>Email</span>
	</a>
	<span class="asutsabo-share-feedback" aria-live="polite"></span>
	<!-- /wp:html -->
</div>
<!-- /wp:group -->
