<?php
/**
 * Title: Editorial Article Header
 * Slug: asutsabo/article-header
 * Categories: asutsabo-article
 * Description: Editorial headline, deck, comprehensive byline, and featured image presentation.
 * Inserter: true
 */
?>
<!-- wp:group {"tagName":"header","className":"asutsabo-article-header","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
<header class="wp-block-group asutsabo-article-header">
	<!-- wp:post-terms {"term":"category","fontSize":"small","style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontWeight":"700","textTransform":"uppercase","letterSpacing":"0.08em"}}} /-->
	<!-- wp:post-title {"level":1,"className":"is-style-asutsabo-featured-headline","style":{"spacing":{"margin":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|20"}}}} /-->
	<!-- wp:post-excerpt {"showMoreOnNewLine":false,"className":"is-style-asutsabo-lead-paragraph"} /-->

	<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"border":{"top":{"color":"var:preset|color|border","width":"1px","style":"solid"},"bottom":{"color":"var:preset|color|border","width":"1px","style":"solid"}}}} -->
	<div class="wp-block-group" style="border-top-color:var(--wp--preset--color--border);border-top-width:1px;border-top-style:solid;border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;border-bottom-style:solid;padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20)">
		<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","alignItems":"center"}} -->
		<div class="wp-block-group">
			<!-- wp:avatar {"size":44,"style":{"border":{"radius":"50%"}}} /-->
			<!-- wp:group {"layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"0"}}} -->
			<div class="wp-block-group">
				<!-- wp:post-author-name {"fontSize":"small","style":{"typography":{"fontWeight":"700"}}} /-->
				<!-- wp:post-date {"fontSize":"x-small"} /-->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","alignItems":"center"}} -->
		<div class="wp-block-group">
			<!-- wp:shortcode -->
			[asutsabo_reading_time]
			<!-- /wp:shortcode -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

	<!-- wp:post-featured-image {"aspectRatio":"16/9","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}}} /-->
</header>
<!-- /wp:group -->
