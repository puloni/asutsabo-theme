<?php
/**
 * Title: Masthead & Editorial Leadership Page
 * Slug: asutsabo/page-masthead
 * Categories: asutsabo-pages
 * Description: Editorial directory listing editors, desk chiefs, and foreign correspondents.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
	<p class="is-style-asutsabo-kicker">Masthead</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"className":"is-style-asutsabo-featured-headline"} -->
	<h1 class="wp-block-heading is-style-asutsabo-featured-headline">Editorial Leadership &amp; Staff</h1>
	<!-- /wp:heading -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-thick"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-thick"/>
	<!-- /wp:separator -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">Leadership</h3>
	<!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|30"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}}} -->
			<p>Editor-in-Chief</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|muted"}}} -->
			<p class="has-muted-color has-text-color has-small-font-size">Executive Newsroom Oversight</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}}} -->
			<p>Managing Editor</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|muted"}}} -->
			<p class="has-muted-color has-text-color has-small-font-size">Daily Operations &amp; Strategy</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-double"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-double"/>
	<!-- /wp:separator -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">Desks &amp; Correspondents</h3>
	<!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|20","left":"var:preset|spacing|30"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}}} -->
			<p>Investigative Desk</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|secondary"}}} -->
			<p class="has-secondary-color has-text-color has-small-font-size">In-depth systemic reporting and public interest records.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}}} -->
			<p>Culture &amp; Ideas</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|secondary"}}} -->
			<p class="has-secondary-color has-text-color has-small-font-size">Essays, long-form reviews, philosophy, and critique.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
