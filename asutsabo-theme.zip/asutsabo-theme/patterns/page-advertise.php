<?php
/**
 * Title: Advertise & Sponsorship Page
 * Slug: asutsabo/page-advertise
 * Categories: asutsabo-pages
 * Description: Media kit, readership demographics, and commercial partnership information.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
	<p class="is-style-asutsabo-kicker">Partnerships</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"className":"is-style-asutsabo-featured-headline"} -->
	<h1 class="wp-block-heading is-style-asutsabo-featured-headline">Advertise With Unheard</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
	<p class="is-style-asutsabo-lead-paragraph">Connect with an influential, highly educated readership of policymakers, researchers, executives, cultural leaders, and engaged citizens.</p>
	<!-- /wp:paragraph -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-thick"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-thick"/>
	<!-- /wp:separator -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Digital Display Placements</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>High-visibility, non-intrusive display sponsorships across desktop and mobile. Standard IAB leaderboard, medium rectangle, and half-page placements strictly separated from editorial copy.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Newsletter Sponsorship</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>Direct exposure in our morning briefing and weekly cultural dispatches delivered to verified engaged subscribers with industry-leading open rates.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-double"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-double"/>
	<!-- /wp:separator -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">Media Kit Inquiries</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>For rate cards, specifications, and bespoke partnership opportunities, contact our commercial director at <strong>partners@unheard.me</strong>.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
