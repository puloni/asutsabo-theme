<?php
/**
 * Title: Primary Editorial Hero
 * Slug: asutsabo/hero-primary
 * Categories: asutsabo-homepage
 * Description: Dominant front-page lead story with prominent headline, deck, and hero photography.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignwide">
	<!-- wp:query {"queryId":10,"query":{"perPage":1,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
	<div class="wp-block-query">
		<!-- wp:post-template {"layout":{"type":"default"}} -->
		<!-- wp:group {"layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
		<div class="wp-block-group">
			<!-- wp:post-terms {"term":"category","fontSize":"x-small"} /-->
			<!-- wp:post-title {"level":2,"isLink":true,"className":"is-style-asutsabo-featured-headline"} /-->
			<!-- wp:post-excerpt {"showMoreOnNewLine":false,"className":"is-style-asutsabo-lead-paragraph"} /-->
			<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"var:preset|spacing|30"}}} -->
			<div class="wp-block-group">
				<!-- wp:avatar {"size":36,"style":{"border":{"radius":"50%"}}} /-->
				<!-- wp:post-author-name {"isLink":true,"fontSize":"small","style":{"typography":{"fontWeight":"700"}}} /-->
				<!-- wp:post-date /-->
			</div>
			<!-- /wp:group -->
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/9","style":{"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} /-->
		</div>
		<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph {"fontSize":"medium"} -->
		<p>No featured stories found.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
