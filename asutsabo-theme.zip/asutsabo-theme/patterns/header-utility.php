<?php
/**
 * Title: Utility Header Bar
 * Slug: asutsabo/header-utility
 * Categories: asutsabo-header
 * Description: Top utility strip with edition indicator, date, and social links.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10","left":"var:preset|spacing|30","right":"var:preset|spacing|30"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group alignfull" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;padding-top:var(--wp--preset--spacing--10);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--10);padding-left:var(--wp--preset--spacing--30)">
	<!-- wp:paragraph {"fontSize":"x-small","style":{"typography":{"textTransform":"uppercase","letterSpacing":"0.06em"},"color":{"text":"var:preset|color|muted"}}} -->
	<p class="has-muted-color has-text-color has-x-small-font-size"><?php echo esc_html( get_bloginfo( 'name' ) ); ?> &bull; <?php esc_html_e( 'Digital Edition', 'asutsabo' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:navigation {"layout":{"type":"flex","orientation":"horizontal"},"style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontSize":"0.75rem","fontWeight":"600"}}} -->
		<!-- wp:page-list {"isNested":false} /-->
	<!-- /wp:navigation -->
</div>
<!-- /wp:group -->
