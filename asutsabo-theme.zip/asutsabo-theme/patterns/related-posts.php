<?php
/**
 * Title: Related Editorial Stories
 * Slug: asutsabo/related-posts
 * Categories: asutsabo-article
 * Description: Three-column related stories section with featured images and excerpts.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}},"border":{"top":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"padding":{"top":"var:preset|spacing|40"}}} -->
<div class="wp-block-group alignwide" style="border-top-color:var(--wp--preset--color--border);border-top-width:1px;border-top-style:solid;padding-top:var(--wp--preset--spacing--40)">
	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">Related Coverage</h3>
	<!-- /wp:heading -->

	<!-- wp:query {"queryId":25,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
	<div class="wp-block-query">
		<!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}},"layout":{"type":"constrained"}} -->
		<div class="wp-block-group">
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2"} /-->
			<!-- wp:post-terms {"term":"category","fontSize":"x-small"} /-->
			<!-- wp:post-title {"level":4,"isLink":true,"fontSize":"medium","style":{"typography":{"fontWeight":"700","lineHeight":"1.25"}}} /-->
			<!-- wp:post-date {"fontSize":"x-small"} /-->
		</div>
		<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph {"fontSize":"small"} -->
		<p>No related coverage available.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
