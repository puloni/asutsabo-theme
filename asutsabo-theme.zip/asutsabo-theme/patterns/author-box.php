<?php
/**
 * Title: Author Biography Box
 * Slug: asutsabo/author-box
 * Categories: asutsabo-article
 * Description: Editorial profile card displaying author portrait, biography, and archive link.
 * Inserter: true
 */
?>
<!-- wp:group {"className":"asutsabo-author-bio-card","layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"top"}} -->
<div class="wp-block-group asutsabo-author-bio-card">
	<!-- wp:avatar {"size":72,"style":{"border":{"radius":"50%"}}} /-->
	<!-- wp:group {"layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|10"}}} -->
	<div class="wp-block-group">
		<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
		<p class="is-style-asutsabo-kicker">About The Author</p>
		<!-- /wp:paragraph -->
		<!-- wp:post-author-name {"fontSize":"medium","style":{"typography":{"fontWeight":"700"}}} /-->
		<!-- wp:post-author-biography {"fontSize":"small"} /-->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
