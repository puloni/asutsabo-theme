<?php
/**
 * Title: Photojournalism Visual Grid
 * Slug: asutsabo/grid-image-led
 * Categories: asutsabo-homepage
 * Description: Photography-forward visual essay grid with prominent imagery and captions.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignwide">
	<!-- wp:heading {"level":2,"className":"is-style-asutsabo-section-label"} -->
	<h2 class="wp-block-heading is-style-asutsabo-section-label">In Pictures &bull; Visual Essays</h2>
	<!-- /wp:heading -->

	<!-- wp:query {"queryId":19,"query":{"perPage":2,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
	<div class="wp-block-query">
		<!-- wp:post-template {"layout":{"type":"grid","columnCount":2}} -->
		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|10"}},"layout":{"type":"constrained"}} -->
		<div class="wp-block-group">
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"3/2","className":"is-style-asutsabo-editorial-image"} /-->
			<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"large","style":{"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} /-->
			<!-- wp:post-excerpt {"showMoreOnNewLine":false,"fontSize":"small"} /-->
			<!-- wp:post-date {"fontSize":"x-small"} /-->
		</div>
		<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph -->
		<p>No photo essays found.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
