<?php
/**
 * Title: Advertisement Medium Rectangle (300x250)
 * Slug: asutsabo/ad-medium-rectangle
 * Categories: asutsabo-advertising
 * Description: Standard sidebar or mid-article rectangular advertising unit.
 * Inserter: true
 */
?>
<!-- wp:group {"className":"asutsabo-ad-placeholder asutsabo-ad-medium-rectangle","layout":{"type":"flex","flexDirection":"column","justifyContent":"center"}} -->
<div class="wp-block-group asutsabo-ad-placeholder asutsabo-ad-medium-rectangle">
	<span class="asutsabo-ad-label">Advertisement</span>
	<span class="asutsabo-ad-dims">300 &times; 250</span>
</div>
<!-- /wp:group -->
