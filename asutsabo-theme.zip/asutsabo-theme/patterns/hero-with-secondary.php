<?php
/**
 * Title: Hero with Secondary Stories
 * Slug: asutsabo/hero-with-secondary
 * Categories: asutsabo-homepage
 * Description: Broad-sheet front section featuring a lead investigative story alongside supporting dispatches.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignwide">
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"66.66%"} -->
		<div class="wp-block-column" style="flex-basis:66.66%">
			<!-- wp:query {"queryId":11,"query":{"perPage":1,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
			<div class="wp-block-query">
				<!-- wp:post-template {"layout":{"type":"default"}} -->
				<!-- wp:post-terms {"term":"category","fontSize":"x-small"} /-->
				<!-- wp:post-title {"level":2,"isLink":true,"fontSize":"xx-large","style":{"typography":{"lineHeight":"1.12"}}} /-->
				<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/9","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}}} /-->
				<!-- wp:post-excerpt {"showMoreOnNewLine":false} /-->
				<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} -->
				<div class="wp-block-group">
					<!-- wp:post-author-name {"isLink":true,"fontSize":"x-small"} /-->
					<!-- wp:post-date /-->
				</div>
				<!-- /wp:group -->
				<!-- /wp:post-template -->

				<!-- wp:query-no-results -->
				<!-- wp:paragraph -->
				<p>No lead stories found.</p>
				<!-- /wp:paragraph -->
				<!-- /wp:query-no-results -->
			</div>
			<!-- /wp:query -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"33.33%","style":{"border":{"left":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"spacing":{"padding":{"left":"var:preset|spacing|30"}}}} -->
		<div class="wp-block-column" style="border-left-color:var(--wp--preset--color--border);border-left-width:1px;border-left-style:solid;padding-left:var(--wp--preset--spacing--30);flex-basis:33.33%">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Top Dispatches</h3>
			<!-- /wp:heading -->

			<!-- wp:query {"queryId":12,"query":{"perPage":3,"pages":0,"offset":1,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
			<div class="wp-block-query">
				<!-- wp:post-template {"layout":{"type":"default"}} -->
				<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"padding":{"bottom":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
				<div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;border-bottom-style:solid;padding-bottom:var(--wp--preset--spacing--30);margin-bottom:var(--wp--preset--spacing--30)">
					<!-- wp:post-terms {"term":"category","fontSize":"x-small"} /-->
					<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"large","style":{"typography":{"lineHeight":"1.25"}}} /-->
					<!-- wp:post-excerpt {"showMoreOnNewLine":false,"fontSize":"small"} /-->
					<!-- wp:post-date {"fontSize":"x-small"} /-->
				</div>
				<!-- /wp:group -->
				<!-- /wp:post-template -->

				<!-- wp:query-no-results -->
				<!-- wp:paragraph -->
				<p>No secondary dispatches available.</p>
				<!-- /wp:paragraph -->
				<!-- /wp:query-no-results -->
			</div>
			<!-- /wp:query -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
