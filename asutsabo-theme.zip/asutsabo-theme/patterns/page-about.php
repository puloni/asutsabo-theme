<?php
/**
 * Title: About The Publication Page
 * Slug: asutsabo/page-about
 * Categories: asutsabo-pages
 * Description: Editorial starter pattern for About page with mission, principles, and history.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
	<p class="is-style-asutsabo-kicker">About Unheard</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"className":"is-style-asutsabo-featured-headline"} -->
	<h1 class="wp-block-heading is-style-asutsabo-featured-headline">Fearless, independent journalism for a complex world.</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
	<p class="is-style-asutsabo-lead-paragraph">Unheard was established with a singular conviction: that serious, nuanced reporting and honest critique are vital pillars of an informed society. We pursue facts without commercial compromise or political dogmatism.</p>
	<!-- /wp:paragraph -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-thick"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-thick"/>
	<!-- /wp:separator -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Our Principles</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>We believe in verification before declaration. Our reporters work on the ground to investigate systemic issues, unearth overlooked stories, and challenge prevailing orthodoxy with evidence and intellect.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Editorial Independence</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>Our newsroom operates with total editorial autonomy. Neither commercial sponsors nor external partners influence our investigations, conclusions, or journalistic decisions.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
