<?php
/**
 * Title: Business & Economics Desk
 * Slug: asutsabo/section-business
 * Categories: asutsabo-homepage
 * Description: Section displaying market resilience, commerce, and monetary reporting from the Business desk.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:heading {"level":2,"className":"is-style-asutsabo-section-label"} -->
	<h2 class="wp-block-heading is-style-asutsabo-section-label">Business</h2>
	<!-- /wp:heading -->

	<!-- wp:query {"queryId":54,"query":{"perPage":2,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false,"asutsaboCategory":"business","asutsaboCategory":"business"},"className":"asutsabo-query-category-business"} -->
	<div class="wp-block-query asutsabo-query-category-business">
		<!-- wp:post-template {"layout":{"type":"default"}} -->
		<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"padding":{"bottom":"var:preset|spacing|20"}},"layout":{"type":"constrained"}} -->
		<div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;border-bottom-style:solid;padding-bottom:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--30)">
			<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/9"} /-->
			<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"large","style":{"spacing":{"margin":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10"}},"typography":{"lineHeight":"1.2"}}} /-->
			<!-- wp:post-excerpt {"showMoreOnNewLine":false,"fontSize":"small"} /-->
			<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|10"}}}} -->
			<div class="wp-block-group">
				<!-- wp:post-author-name {"isLink":true,"fontSize":"x-small"} /-->
				<!-- wp:post-date {"fontSize":"x-small"} /-->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph {"fontSize":"small"} -->
		<p>No business dispatches available.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
