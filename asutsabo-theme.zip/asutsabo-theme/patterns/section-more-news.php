<?php
/**
 * Title: More News Stream & Sidebar
 * Slug: asutsabo/section-more-news
 * Categories: asutsabo-homepage
 * Description: Editorial stream of additional reporting paired with an informative newsroom sidebar.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group alignwide">
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|50"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"68%"} -->
		<div class="wp-block-column" style="flex-basis:68%">
			<!-- wp:heading {"level":2,"className":"is-style-asutsabo-section-label"} -->
			<h2 class="wp-block-heading is-style-asutsabo-section-label">More News &amp; Reports</h2>
			<!-- /wp:heading -->

			<!-- wp:query {"queryId":60,"query":{"perPage":4,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"className":"asutsabo-more-news asutsabo-exclude-displayed"} -->
			<div class="wp-block-query asutsabo-more-news asutsabo-exclude-displayed">
				<!-- wp:post-template {"layout":{"type":"default"}} -->
				<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"padding":{"bottom":"var:preset|spacing|30"}},"layout":{"type":"flex","flexWrap":"wrap","verticalAlignment":"top"}} -->
				<div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;border-bottom-style:solid;padding-bottom:var(--wp--preset--spacing--30);margin-bottom:var(--wp--preset--spacing--30)">
					<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/9","width":"260px"} /-->
					<!-- wp:group {"layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|10"}}} -->
					<div class="wp-block-group">
						<!-- wp:post-terms {"term":"category","fontSize":"x-small"} /-->
						<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"large","style":{"typography":{"lineHeight":"1.2"}}} /-->
						<!-- wp:post-excerpt {"showMoreOnNewLine":false,"fontSize":"small"} /-->
						<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
						<div class="wp-block-group">
							<!-- wp:post-author-name {"isLink":true,"fontSize":"x-small"} /-->
							<!-- wp:post-date {"fontSize":"x-small"} /-->
						</div>
						<!-- /wp:group -->
					</div>
					<!-- /wp:group -->
				</div>
				<!-- /wp:group -->
				<!-- /wp:post-template -->

				<!-- wp:query-no-results -->
				<!-- wp:paragraph -->
				<p>No additional dispatches found.</p>
				<!-- /wp:paragraph -->
				<!-- /wp:query-no-results -->
			</div>
			<!-- /wp:query -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"32%","style":{"border":{"left":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"spacing":{"padding":{"left":"var:preset|spacing|30"}}}} -->
		<div class="wp-block-column" style="border-left-color:var(--wp--preset--color--border);border-left-width:1px;border-left-style:solid;padding-left:var(--wp--preset--spacing--30);flex-basis:32%">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Latest Wire</h3>
			<!-- /wp:heading -->
			<!-- wp:latest-posts {"postsToShow":5,"displayPostDate":true} /-->
			<!-- wp:pattern {"slug":"asutsabo/ad-medium-rectangle"} /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
