<?php
/**
 * Title: Complete Article Footer
 * Slug: asutsabo/article-footer
 * Categories: asutsabo-article
 * Description: Article footer with tags, share bar, author box, navigation, and comments.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<div class="wp-block-group">
	<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30"}}}} -->
	<div class="wp-block-group">
		<!-- wp:post-terms {"term":"post_tag","fontSize":"small"} /-->
	</div>
	<!-- /wp:group -->

	<!-- wp:pattern {"slug":"asutsabo/share-row"} /-->

	<!-- wp:pattern {"slug":"asutsabo/author-box"} /-->

	<!-- wp:pattern {"slug":"asutsabo/post-navigation"} /-->

	<!-- wp:pattern {"slug":"asutsabo/related-posts"} /-->

	<!-- wp:comments {"className":"asutsabo-comments-area","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"}}}} -->
	<div class="wp-block-comments asutsabo-comments-area">
		<!-- wp:comments-title {"level":3} /-->
		<!-- wp:comment-template -->
		<!-- wp:columns {"style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
		<div class="wp-block-columns">
			<!-- wp:column {"width":"48px"} -->
			<div class="wp-block-column" style="flex-basis:48px">
				<!-- wp:comment-author-avatar {"avatarSize":48,"style":{"border":{"radius":"50%"}}} /-->
			</div>
			<!-- /wp:column -->
			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:comment-author-name /-->
				<!-- wp:comment-date {"fontSize":"x-small"} /-->
				<!-- wp:comment-content /-->
				<!-- wp:comment-reply-link /-->
			</div>
			<!-- /wp:column -->
		</div>
		<!-- /wp:columns -->
		<!-- /wp:comment-template -->
		<!-- wp:comments-pagination -->
		<!-- wp:comments-pagination-previous /-->
		<!-- wp:comments-pagination-numbers /-->
		<!-- wp:comments-pagination-next /-->
		<!-- /wp:comments-pagination -->
		<!-- wp:post-comments-form /-->
	</div>
	<!-- /wp:comments -->
</div>
<!-- /wp:group -->
