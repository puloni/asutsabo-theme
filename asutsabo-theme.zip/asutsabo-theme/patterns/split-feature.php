<?php
/**
 * Title: Split Feature Investigation
 * Slug: asutsabo/split-feature
 * Categories: asutsabo-homepage
 * Description: 50/50 high-impact split section pairing a dominant visual with investigative text.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}},"border":{"top":{"color":"var:preset|color|border-dark","width":"2px","style":"solid"},"bottom":{"color":"var:preset|color|border-dark","width":"1px","style":"solid"}},"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}} -->
<div class="wp-block-group alignwide" style="border-top-color:var(--wp--preset--color--border-dark);border-top-width:2px;border-top-style:solid;border-bottom-color:var(--wp--preset--color--border-dark);border-bottom-width:1px;border-bottom-style:solid;padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:query {"queryId":20,"query":{"perPage":1,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
	<div class="wp-block-query">
		<!-- wp:post-template {"layout":{"type":"default"}} -->
		<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|50"}}}} -->
		<div class="wp-block-columns are-vertically-aligned-center">
			<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
			<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%">
				<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"4/3"} /-->
			</div>
			<!-- /wp:column -->

			<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
			<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%">
				<!-- wp:post-terms {"term":"category","fontSize":"x-small"} /-->
				<!-- wp:post-title {"level":2,"isLink":true,"fontSize":"xx-large","style":{"typography":{"lineHeight":"1.15"}}} /-->
				<!-- wp:post-excerpt {"showMoreOnNewLine":false,"className":"is-style-asutsabo-lead-paragraph"} /-->
				<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} -->
				<div class="wp-block-group">
					<!-- wp:avatar {"size":32,"style":{"border":{"radius":"50%"}}} /-->
					<!-- wp:post-author-name {"isLink":true,"fontSize":"small","style":{"typography":{"fontWeight":"700"}}} /-->
					<!-- wp:post-date {"fontSize":"x-small"} /-->
				</div>
				<!-- /wp:group -->
			</div>
			<!-- /wp:column -->
		</div>
		<!-- /wp:columns -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph -->
		<p>No feature story available.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
