<?php
/**
 * Title: Wire Service Headlines
 * Slug: asutsabo/compact-headlines
 * Categories: asutsabo-homepage
 * Description: Fast, information-dense wire-service headline ticker.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|40"}}}} -->
<div class="wp-block-group alignwide">
	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">Fast Wire</h3>
	<!-- /wp:heading -->

	<!-- wp:query {"queryId":16,"query":{"perPage":6,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false}} -->
	<div class="wp-block-query">
		<!-- wp:post-template {"layout":{"type":"default"}} -->
		<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px","style":"solid"}}},"layout":{"type":"flex","flexWrap":"nowrap","alignItems":"baseline"}} -->
		<div class="wp-block-group" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-width:1px;border-bottom-style:solid;padding-top:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--10)">
			<!-- wp:post-date {"format":"H:i","style":{"typography":{"fontFamily":"var:preset|font-family|mono","fontSize":"0.75rem"}},"className":"has-muted-color has-text-color"} /-->
			<!-- wp:post-title {"isLink":true,"fontSize":"small","style":{"typography":{"fontWeight":"600"}}} /-->
		</div>
		<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph {"fontSize":"small"} -->
		<p>No wire updates at this moment.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
