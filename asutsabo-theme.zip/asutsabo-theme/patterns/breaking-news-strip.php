<?php
/**
 * Title: Breaking News Strip
 * Slug: asutsabo/breaking-news-strip
 * Categories: asutsabo-header
 * Description: Alert bar featuring latest breaking story with dismiss action.
 * Inserter: true
 */
?>
<!-- wp:group {"tagName":"aside","ariaLabel":"Breaking News","className":"asutsabo-breaking-news"} -->
<aside aria-label="Breaking News" class="wp-block-group asutsabo-breaking-news" data-alert-id="asutsabo-breaking-bar">
	<div class="asutsabo-breaking-news-inner" style="display:flex;align-items:center;flex:1;overflow:hidden;">
		<p class="asutsabo-breaking-news-label" style="margin:0 0.75rem 0 0;"><span class="asutsabo-breaking-news-pulse" aria-hidden="true"></span>Breaking News</p>
		<!-- wp:latest-posts {"postsToShow":1} /-->
	</div>
	<button type="button" class="asutsabo-breaking-news-dismiss" aria-label="Dismiss breaking news alert">&times;</button>
</aside>
<!-- /wp:group -->
