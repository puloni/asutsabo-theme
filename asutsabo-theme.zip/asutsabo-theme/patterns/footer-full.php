<?php
/**
 * Title: Complete Editorial Footer
 * Slug: asutsabo/footer-full
 * Categories: asutsabo-footer
 * Description: Three-column newspaper footer with publication info, sections, and standards.
 * Inserter: true
 */
?>
<!-- wp:group {"className":"asutsabo-site-footer","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|40"}},"border":{"top":{"color":"var:preset|color|border-dark","width":"3px"}}}} -->
<div class="wp-block-group asutsabo-site-footer">
	<!-- wp:group {"align":"wide","layout":{"type":"constrained"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|40","left":"var:preset|spacing|40"}}}} -->
		<div class="wp-block-columns">
			<!-- wp:column {"width":"40%"} -->
			<div class="wp-block-column" style="flex-basis:40%">
				<!-- wp:site-title {"level":3,"style":{"typography":{"fontFamily":"var:preset|font-family|serif","fontSize":"1.75rem","fontWeight":"800"}}} /-->
				<!-- wp:site-tagline {"fontSize":"small","style":{"spacing":{"margin":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|20"}}}} /-->
				<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|secondary"},"typography":{"lineHeight":"1.6"}}} -->
				<p class="has-secondary-color has-text-color has-small-font-size">A digital publication devoted to fearless journalism, deep investigative reporting, critical commentary, and cultural analysis.</p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column {"width":"30%"} -->
			<div class="wp-block-column" style="flex-basis:30%">
				<!-- wp:heading {"level":4,"className":"is-style-asutsabo-section-label"} -->
				<h4 class="wp-block-heading is-style-asutsabo-section-label">Sections</h4>
				<!-- /wp:heading -->
				<!-- wp:navigation {"overlayMenu":"never","layout":{"type":"flex","orientation":"vertical"},"style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontSize":"0.875rem"}}} /-->
			</div>
			<!-- /wp:column -->

			<!-- wp:column {"width":"30%"} -->
			<div class="wp-block-column" style="flex-basis:30%">
				<!-- wp:heading {"level":4,"className":"is-style-asutsabo-section-label"} -->
				<h4 class="wp-block-heading is-style-asutsabo-section-label">Standards</h4>
				<!-- /wp:heading -->
				<!-- wp:page-list {"isNested":false} /-->
			</div>
			<!-- /wp:column -->
		</div>
		<!-- /wp:columns -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
