<?php
/**
 * Title: Newspaper Newsletter CTA
 * Slug: asutsabo/newsletter-cta
 * Categories: asutsabo-homepage, asutsabo-article
 * Description: Bold editorial newsletter subscription box with clean call-to-action.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","className":"asutsabo-newsletter-box","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide asutsabo-newsletter-box">
	<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns are-vertically-aligned-center">
		<!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%">
			<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
			<p class="is-style-asutsabo-kicker">The Daily Intelligence</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"fontSize":"x-large","style":{"typography":{"fontWeight":"800","lineHeight":"1.15"}}} -->
			<h3 class="wp-block-heading has-x-large-font-size">Essential journalism, direct to your inbox.</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|secondary"}}} -->
			<p class="has-secondary-color has-text-color has-small-font-size"><?php printf( esc_html__( 'Subscribe to receive %s\'s independent reporting, investigative dispatches, and cultural critique directly in your inbox.', 'asutsabo' ), esc_html( get_bloginfo( 'name' ) ) ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
		<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%">
			<!-- wp:buttons {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"left"}} -->
			<div class="wp-block-buttons">
				<!-- wp:button {"width":100} -->
				<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link wp-element-button" href="#subscribe">Join Free Briefing</a></div>
				<!-- /wp:button -->
			</div>
			<!-- /wp:buttons -->
			<!-- wp:paragraph {"fontSize":"x-small","style":{"color":{"text":"var:preset|color|muted"},"spacing":{"margin":{"top":"var:preset|spacing|10"}}}} -->
			<p class="has-muted-color has-text-color has-x-small-font-size">No spam. One-click unsubscribe at any time.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
