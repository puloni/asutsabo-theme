<?php
/**
 * Title: Editorial Standards & Ethics Page
 * Slug: asutsabo/page-editorial-standards
 * Categories: asutsabo-pages
 * Description: Editorial charter on verification, source attribution, conflicts of interest, and rigor.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
	<p class="is-style-asutsabo-kicker">Ethics &amp; Policy</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"className":"is-style-asutsabo-featured-headline"} -->
	<h1 class="wp-block-heading is-style-asutsabo-featured-headline">Editorial Standards &amp; Code of Ethics</h1>
	<!-- /wp:heading -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-thick"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-thick"/>
	<!-- /wp:separator -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">1. Verification &amp; Accuracy</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Every factual assertion published by Unheard is subject to rigorous corroboration. Our reporters seek primary documentation, on-the-record statements, and multiple corroborating sources before publication.</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">2. Anonymous Sources</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Confidentiality is extended only when information of profound public interest cannot be obtained otherwise and the source faces genuine jeopardy. Anonymous sources must be vetted and approved by senior newsroom editors.</p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
	<h3 class="wp-block-heading is-style-asutsabo-section-label">3. Conflicts of Interest</h3>
	<!-- /wp:heading -->
	<!-- wp:paragraph -->
	<p>Reporters and editors must disclose any personal, political, or financial relationships that could present an actual or perceived conflict of interest. We accept no sponsored editorial coverage.</p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
