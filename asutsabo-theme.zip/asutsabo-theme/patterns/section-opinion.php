<?php
/**
 * Title: Opinion & Columnists Showcase
 * Slug: asutsabo/section-opinion
 * Categories: asutsabo-homepage
 * Description: Editorial columnists section featuring author avatars, bylines, and opinion essays.
 * Inserter: true
 */
?>
<!-- wp:group {"align":"wide","layout":{"type":"constrained"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"}},"border":{"top":{"color":"var:preset|color|border-dark","width":"2px","style":"solid"},"bottom":{"color":"var:preset|color|border-dark","width":"1px","style":"solid"}},"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}} -->
<div class="wp-block-group alignwide" style="border-top-color:var(--wp--preset--color--border-dark);border-top-width:2px;border-top-style:solid;border-bottom-color:var(--wp--preset--color--border-dark);border-bottom-width:1px;border-bottom-style:solid;padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)">
	<!-- wp:heading {"level":2,"className":"is-style-asutsabo-section-label"} -->
	<h2 class="wp-block-heading is-style-asutsabo-section-label">Opinion &bull; The Columnists</h2>
	<!-- /wp:heading -->

	<!-- wp:query {"queryId":21,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false,"asutsaboCategory":"opinion","asutsaboCategory":"opinion"},"className":"asutsabo-query-category-opinion"} -->
	<div class="wp-block-query asutsabo-query-category-opinion">
		<!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
		<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|20"},"border":{"right":{"color":"var:preset|color|border","width":"1px","style":"solid"}},"padding":{"right":"var:preset|spacing|30"}},"layout":{"type":"constrained"}} -->
		<div class="wp-block-group" style="border-right-color:var(--wp--preset--color--border);border-right-width:1px;border-right-style:solid;padding-right:var(--wp--preset--spacing--30)">
			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","alignItems":"center"},"style":{"spacing":{"blockGap":"var:preset|spacing|20"}}} -->
			<div class="wp-block-group">
				<!-- wp:avatar {"size":56,"style":{"border":{"radius":"50%"}}} /-->
				<!-- wp:group {"layout":{"type":"constrained"}} -->
				<div class="wp-block-group">
					<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
					<p class="is-style-asutsabo-kicker">Column</p>
					<!-- /wp:paragraph -->
					<!-- wp:post-author-name {"fontSize":"small","style":{"typography":{"fontWeight":"700"}}} /-->
				</div>
				<!-- /wp:group -->
			</div>
			<!-- /wp:group -->

			<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"large","style":{"typography":{"fontStyle":"italic","lineHeight":"1.25"},"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} /-->
			<!-- wp:post-excerpt {"showMoreOnNewLine":false,"fontSize":"small"} /-->
		</div>
		<!-- /wp:group -->
		<!-- /wp:post-template -->

		<!-- wp:query-no-results -->
		<!-- wp:paragraph -->
		<p>No opinion columns found.</p>
		<!-- /wp:paragraph -->
		<!-- /wp:query-no-results -->
	</div>
	<!-- /wp:query -->
</div>
<!-- /wp:group -->
