<?php
/**
 * Title: Editorial Correction & Update Note
 * Slug: asutsabo/correction-note
 * Categories: asutsabo-article
 * Description: Formal editorial correction or update notification box.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"1rem","bottom":"1rem","left":"1.25rem","right":"1.25rem"}},"border":{"left":{"color":"var:preset|color|accent","width":"3px"}}}} -->
<div class="wp-block-group" style="border-left-color:var(--wp--preset--color--accent);border-left-width:3px;border-left-style:solid;padding-top:1rem;padding-right:1.25rem;padding-bottom:1rem;padding-left:1.25rem">
	<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
	<p class="is-style-asutsabo-kicker">Correction &bull; Editorial Note</p>
	<!-- /wp:paragraph -->
	<!-- wp:paragraph {"fontSize":"small"} -->
	<p class="has-small-font-size"><?php printf( esc_html__( 'An earlier version of this report contained an inadvertent inaccuracy. The details have been updated in the text to reflect verified facts in accordance with %s\'s Editorial Standards.', 'asutsabo' ), esc_html( get_bloginfo( 'name' ) ) ); ?></p>
	<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
