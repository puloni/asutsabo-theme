<?php
/**
 * Title: Social Media & Newsletter Footer
 * Slug: asutsabo/footer-social
 * Categories: asutsabo-footer
 * Description: Footer variation emphasizing digital dispatches and social connectivity.
 * Inserter: true
 */
?>
<!-- wp:group {"tagName":"footer","className":"asutsabo-footer-social","layout":{"type":"constrained"},"style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|40"}},"border":{"top":{"color":"var:preset|color|border-dark","width":"2px","style":"solid"}}}} -->
<footer class="wp-block-group asutsabo-footer-social">
	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
	<div class="wp-block-group alignwide">
		<!-- wp:group {"layout":{"type":"constrained"}} -->
		<div class="wp-block-group">
			<!-- wp:site-title {"level":3,"style":{"typography":{"fontFamily":"var:preset|font-family|serif","fontSize":"1.5rem","fontWeight":"800"}}} /-->
			<!-- wp:paragraph {"fontSize":"small","style":{"color":{"text":"var:preset|color|secondary"}}} -->
			<p class="has-secondary-color has-text-color has-small-font-size">Independent journalism without compromise.</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:group -->

		<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","alignItems":"center"}} -->
		<div class="wp-block-group">
			<!-- wp:navigation {"layout":{"type":"flex","orientation":"horizontal"},"style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontSize":"0.875rem","fontWeight":"600"}}} -->
				<!-- wp:page-list {"isNested":false} /-->
			<!-- /wp:navigation -->
		</div>
		<!-- /wp:group -->
	</div>
	<!-- /wp:group -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-thick","style":{"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-thick"/>
	<!-- /wp:separator -->

	<!-- wp:group {"align":"wide","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"},"style":{"typography":{"fontFamily":"var:preset|font-family|sans","fontSize":"0.75rem"},"color":{"text":"var:preset|color|muted"}}} -->
	<div class="wp-block-group alignwide has-muted-color has-text-color" style="font-family:var(--wp--preset--font-family--sans);font-size:0.75rem">
		<!-- wp:paragraph -->
		<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'All rights reserved.', 'asutsabo' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</footer>
<!-- /wp:group -->
