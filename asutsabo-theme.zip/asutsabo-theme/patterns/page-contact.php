<?php
/**
 * Title: Contact & Newsroom Tips Page
 * Slug: asutsabo/page-contact
 * Categories: asutsabo-pages
 * Description: Editorial starter pattern for Contact page with secure tips, newsroom desks, and press inquiries.
 * Inserter: true
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group">
	<!-- wp:paragraph {"className":"is-style-asutsabo-kicker"} -->
	<p class="is-style-asutsabo-kicker">Get in Touch</p>
	<!-- /wp:paragraph -->
	<!-- wp:heading {"level":1,"className":"is-style-asutsabo-featured-headline"} -->
	<h1 class="wp-block-heading is-style-asutsabo-featured-headline">Contact the Newsroom</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"className":"is-style-asutsabo-lead-paragraph"} -->
	<p class="is-style-asutsabo-lead-paragraph">We welcome story tips, leaks of public interest, letters to the editor, and syndicate inquiries.</p>
	<!-- /wp:paragraph -->

	<!-- wp:separator {"className":"is-style-asutsabo-divider-thick"} -->
	<hr class="wp-block-separator has-alpha-channel-opacity is-style-asutsabo-divider-thick"/>
	<!-- /wp:separator -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30","left":"var:preset|spacing|40"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Confidential Tips</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>Have information that should be investigated? We protect confidential sources. Send encrypted correspondence via Signal or PGP-encrypted mail to our investigative team.</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontFamily":"var:preset|font-family|mono"}}} -->
			<p>tips@unheard.me</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"className":"is-style-asutsabo-section-label"} -->
			<h3 class="wp-block-heading is-style-asutsabo-section-label">Editorial Inquiries</h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>For pitches, op-ed submissions, corrections, and general newsroom inquiries, please direct your communication to the relevant editorial desk.</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontFamily":"var:preset|font-family|mono"}}} -->
			<p>editor@unheard.me</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
