/**
 * Asutsabo Reader Enhancements JavaScript.
 *
 * Implements:
 * 1. Reading Progress Bar (scroll progress through article content)
 * 2. Reader Toolbar (Font Resizer & Theme Mode: Light / Sepia / Dark with localStorage)
 * 3. Table of Contents collapsible toggle & smooth scroll
 * 4. Back to Top floating button
 * 5. Sticky Navigation Bar
 *
 * @package Asutsabo
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		// =========================================================================
		// 1. READER PREFERENCES (Theme Mode & Font Size)
		// =========================================================================
		var rootHtml = document.documentElement;

		// Restore theme mode
		try {
			var savedTheme = localStorage.getItem('asutsabo_reader_theme');
			if (savedTheme) {
				rootHtml.setAttribute('data-theme', savedTheme);
			}
			var savedFontSize = localStorage.getItem('asutsabo_reader_font_size');
			if (savedFontSize) {
				rootHtml.setAttribute('data-font-size', savedFontSize);
			}
		} catch (e) {}

		// Theme Switcher Buttons
		var themeButtons = document.querySelectorAll('.asutsabo-theme-btn');
		themeButtons.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var theme = btn.getAttribute('data-theme') || 'light';
				rootHtml.setAttribute('data-theme', theme);
				themeButtons.forEach(function (b) { b.classList.remove('is-active'); });
				btn.classList.add('is-active');
				try {
					localStorage.setItem('asutsabo_reader_theme', theme);
				} catch (e) {}
			});

			// Highlight active on load
			var current = rootHtml.getAttribute('data-theme') || 'light';
			if (btn.getAttribute('data-theme') === current) {
				btn.classList.add('is-active');
			}
		});

		// Font Resizer Buttons
		var fontButtons = document.querySelectorAll('.asutsabo-font-btn');
		var fontSizes   = ['small', 'medium', 'large'];
		var currentSize = rootHtml.getAttribute('data-font-size') || 'medium';

		fontButtons.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var action = btn.getAttribute('data-action');
				var curIdx = fontSizes.indexOf(currentSize);
				if (curIdx === -1) {
					curIdx = 1;
				}

				if (action === 'font-inc') {
					if (curIdx < fontSizes.length - 1) {
						currentSize = fontSizes[curIdx + 1];
					}
				} else if (action === 'font-dec') {
					if (curIdx > 0) {
						currentSize = fontSizes[curIdx - 1];
					}
				} else if (action === 'font-reset') {
					currentSize = 'medium';
				}

				rootHtml.setAttribute('data-font-size', currentSize);
				try {
					localStorage.setItem('asutsabo_reader_font_size', currentSize);
				} catch (e) {}
			});
		});

		// =========================================================================
		// 2. READING PROGRESS BAR
		// =========================================================================
		var progressBar = document.getElementById('asutsabo-reading-progress');
		var progressFill = progressBar ? progressBar.querySelector('.asutsabo-reading-progress-fill') : null;
		var articleContent = document.querySelector('.asutsabo-article-content');

		function updateReadingProgress() {
			if (!progressFill || !articleContent) {
				return;
			}
			var rect   = articleContent.getBoundingClientRect();
			var total  = articleContent.offsetHeight;
			var top    = rect.top;
			var windowH = window.innerHeight;

			// Percentage scrolled through article
			var progress = 0;
			if (top > 0) {
				progress = 0;
			} else {
				var scrolled = Math.abs(top);
				progress = Math.min(100, Math.round((scrolled / (total - windowH * 0.4)) * 100));
			}

			if (progressFill) {
				progressFill.style.width = Math.max(0, Math.min(100, progress)) + '%';
			}
		}

		if (progressBar && articleContent) {
			window.addEventListener('scroll', updateReadingProgress, { passive: true });
			window.addEventListener('resize', updateReadingProgress, { passive: true });
			updateReadingProgress();
		}

		// =========================================================================
		// 3. TABLE OF CONTENTS COLLAPSIBLE & SMOOTH SCROLL
		// =========================================================================
		var tocBox    = document.querySelector('.asutsabo-toc-box');
		var tocToggle = tocBox ? tocBox.querySelector('.asutsabo-toc-toggle') : null;
		var tocList   = tocBox ? tocBox.querySelector('.asutsabo-toc-list') : null;
		var tocText   = tocToggle ? tocToggle.querySelector('.asutsabo-toc-toggle-text') : null;

		if (tocToggle && tocList) {
			tocToggle.addEventListener('click', function () {
				var isExpanded = tocToggle.getAttribute('aria-expanded') === 'true';
				tocToggle.setAttribute('aria-expanded', !isExpanded);
				tocList.style.display = isExpanded ? 'none' : 'block';
				if (tocText) {
					var hideStr = (typeof asutsaboReaderL10n !== 'undefined' && asutsaboReaderL10n.collapseTOC) ? asutsaboReaderL10n.collapseTOC : 'Hide';
					var showStr = (typeof asutsaboReaderL10n !== 'undefined' && asutsaboReaderL10n.expandTOC) ? asutsaboReaderL10n.expandTOC : 'Show';
					tocText.textContent = isExpanded ? showStr : hideStr;
				}
			});
		}

		// Smooth scroll with offset for fixed header
		var tocLinks = document.querySelectorAll('.asutsabo-toc-list a');
		tocLinks.forEach(function (link) {
			link.addEventListener('click', function (e) {
				var targetId = link.getAttribute('href');
				if (targetId && targetId.indexOf('#') === 0 && targetId.length > 1) {
					var targetEl = document.querySelector(targetId);
					if (targetEl) {
						e.preventDefault();
						var offset = 80;
						var bodyRect = document.body.getBoundingClientRect().top;
						var elRect   = targetEl.getBoundingClientRect().top;
						var targetPosition = elRect - bodyRect - offset;
						window.scrollTo({
							top: targetPosition,
							behavior: 'smooth'
						});
						targetEl.focus({ preventScroll: true });
					}
				}
			});
		});

		// =========================================================================
		// 4. BACK TO TOP BUTTON
		// =========================================================================
		var backToTopBtn = document.getElementById('asutsabo-back-to-top');
		if (backToTopBtn) {
			function toggleBackToTop() {
				if (window.scrollY > 400) {
					backToTopBtn.classList.add('is-visible');
				} else {
					backToTopBtn.classList.remove('is-visible');
				}
			}

			window.addEventListener('scroll', toggleBackToTop, { passive: true });
			toggleBackToTop();

			backToTopBtn.addEventListener('click', function () {
				window.scrollTo({
					top: 0,
					behavior: 'smooth'
				});
			});
		}

		// =========================================================================
		// 5. STICKY HEADER PROGRESSION
		// =========================================================================
		var navWrap = document.querySelector('.asutsabo-nav-container-wrap');
		if (navWrap) {
			var masthead = document.querySelector('.asutsabo-masthead');
			var lastScrollY = window.scrollY;

			function handleStickyNav() {
				var currentY = window.scrollY;
				var threshold = masthead ? masthead.offsetHeight : 150;

				if (currentY > threshold) {
					navWrap.classList.add('is-sticky');
				} else {
					navWrap.classList.remove('is-sticky');
				}
				lastScrollY = currentY;
			}

			window.addEventListener('scroll', handleStickyNav, { passive: true });
			handleStickyNav();
		}
	});
})();
