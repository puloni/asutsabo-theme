/**
 * Asutsabo Dismissible Breaking News Bar.
 *
 * Provides accessible dismiss behavior with sessionStorage persistence.
 * Degrades 100% gracefully if JavaScript is disabled.
 *
 * @package Asutsabo
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var alertBars = document.querySelectorAll('.asutsabo-breaking-news');

		alertBars.forEach(function (bar) {
			var alertId = bar.getAttribute('data-alert-id') || 'asutsabo-breaking-news-default';
			var dismissed = false;

			try {
				dismissed = window.sessionStorage.getItem('asutsabo_dismissed_' + alertId) === 'true';
			} catch (e) {
				// sessionStorage may be disabled/restricted.
			}

			if (dismissed) {
				bar.style.display = 'none';
				return;
			}

			var dismissBtn = bar.querySelector('.asutsabo-breaking-news-dismiss');
			if (dismissBtn) {
				dismissBtn.addEventListener('click', function () {
					bar.style.opacity = '0';
					bar.style.transition = 'opacity 0.2s ease';
					setTimeout(function () {
						bar.style.display = 'none';
					}, 200);

					try {
						window.sessionStorage.setItem('asutsabo_dismissed_' + alertId, 'true');
					} catch (e) {
						// Fallback silently.
					}
				});
			}

			// Carousel navigation for multiple breaking news headlines
			var slides      = bar.querySelectorAll('.asutsabo-breaking-slide');
			var prevBtn     = bar.querySelector('.asutsabo-breaking-prev');
			var nextBtn     = bar.querySelector('.asutsabo-breaking-next');
			var currentSpan = bar.querySelector('.asutsabo-breaking-current');
			var totalSlides = slides.length;
			var currentIdx  = 0;
			var autoTimer   = null;

			if (totalSlides > 1) {
				function showSlide(index) {
					slides.forEach(function (slide, i) {
						if (i === index) {
							slide.style.display = 'inline-block';
							slide.classList.add('is-active');
						} else {
							slide.style.display = 'none';
							slide.classList.remove('is-active');
						}
					});
					if (currentSpan) {
						currentSpan.textContent = index + 1;
					}
					currentIdx = index;
				}

				function nextSlide() {
					var next = (currentIdx + 1) % totalSlides;
					showSlide(next);
				}

				function prevSlide() {
					var prev = (currentIdx - 1 + totalSlides) % totalSlides;
					showSlide(prev);
				}

				if (nextBtn) {
					nextBtn.addEventListener('click', function () {
						nextSlide();
						restartTimer();
					});
				}
				if (prevBtn) {
					prevBtn.addEventListener('click', function () {
						prevSlide();
						restartTimer();
					});
				}

				function startTimer() {
					autoTimer = setInterval(nextSlide, 6000);
				}

				function stopTimer() {
					if (autoTimer) {
						clearInterval(autoTimer);
						autoTimer = null;
					}
				}

				function restartTimer() {
					stopTimer();
					startTimer();
				}

				// Pause on hover or focus
				bar.addEventListener('mouseenter', stopTimer);
				bar.addEventListener('mouseleave', startTimer);
				bar.addEventListener('focusin', stopTimer);
				bar.addEventListener('focusout', startTimer);

				startTimer();
			}
		});
	});
})();
