/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better real-time preview experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 *
 * @package Asutsabo
 */

(function ($) {
	'use strict';

	// Masthead: Digital edition text
	wp.customize('asutsabo_edition_text', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-edition-label').text(newVal);
		});
	});

	// Header: Breaking news badge
	wp.customize('asutsabo_breaking_news_badge', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-breaking-news-label').html(
				'<span class="asutsabo-breaking-news-pulse" aria-hidden="true"></span> ' + newVal
			);
		});
	});

	// Fast Wire section title
	wp.customize('asutsabo_fast_wire_title', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-fast-wire .is-style-asutsabo-section-label').text(newVal);
		});
	});

	// Editor's Picks section title
	wp.customize('asutsabo_editors_picks_title', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-editors-picks-section .is-style-asutsabo-section-label').text(newVal);
		});
	});

	// Top Dispatches section title
	wp.customize('asutsabo_top_dispatches_title', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-hero-secondary .is-style-asutsabo-section-label').text(newVal);
		});
	});

	// Category section titles
	var categories = [
		'national',
		'world',
		'politics',
		'business',
		'technology',
		'sports',
		'entertainment',
		'culture',
		'lifestyle'
	];

	$.each(categories, function (index, slug) {
		wp.customize('asutsabo_' + slug + '_title', function (value) {
			value.bind(function (newVal) {
				$('.asutsabo-section-heading-' + slug).text(newVal);
			});
		});
	});

	// Footer bio
	wp.customize('asutsabo_footer_bio', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-footer-bio').html(newVal);
		});
	});

	// Briefing / Newsletter box live handlers
	wp.customize('asutsabo_newsletter_eyebrow', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-briefing-eyebrow').text(newVal);
		});
	});

	wp.customize('asutsabo_newsletter_headline', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-briefing-headline').text(newVal);
		});
	});

	wp.customize('asutsabo_newsletter_description', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-briefing-description').text(newVal);
		});
	});

	wp.customize('asutsabo_newsletter_button_text', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-briefing-button').text(newVal);
		});
	});

	wp.customize('asutsabo_newsletter_button_url', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-briefing-button').attr('href', newVal);
		});
	});

	wp.customize('asutsabo_newsletter_disclaimer', function (value) {
		value.bind(function (newVal) {
			$('.asutsabo-briefing-disclaimer').text(newVal);
		});
	});
})(jQuery);

