/**
 * Asutsabo Social Sharing Enhancements.
 *
 * Populates real post URLs and titles on social sharing links, provides
 * Web Share API progressive enhancement, and clipboard copy with accessible feedback.
 *
 * @package Asutsabo
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var l10n = window.asutsaboShareL10n || {};
		var currentUrl = l10n.shareUrl || window.location.href;
		var currentTitle = l10n.shareTitle || document.title;

		var encodedUrl = encodeURIComponent(currentUrl);
		var encodedTitle = encodeURIComponent(currentTitle);

		// Populate live share targets
		document.querySelectorAll('.asutsabo-share-x').forEach(function (el) {
			el.href = 'https://twitter.com/intent/tweet?url=' + encodedUrl + '&text=' + encodedTitle;
		});

		document.querySelectorAll('.asutsabo-share-fb').forEach(function (el) {
			el.href = 'https://www.facebook.com/sharer/sharer.php?u=' + encodedUrl;
		});

		document.querySelectorAll('.asutsabo-share-wa').forEach(function (el) {
			el.href = 'https://api.whatsapp.com/send?text=' + encodedTitle + '%20' + encodedUrl;
		});

		document.querySelectorAll('.asutsabo-share-li').forEach(function (el) {
			el.href = 'https://www.linkedin.com/sharing/share-offsite/?url=' + encodedUrl;
		});

		document.querySelectorAll('.asutsabo-share-tg').forEach(function (el) {
			el.href = 'https://t.me/share/url?url=' + encodedUrl + '&text=' + encodedTitle;
		});

		document.querySelectorAll('.asutsabo-share-mail').forEach(function (el) {
			el.href = 'mailto:?subject=' + encodedTitle + '&body=' + encodedUrl;
		});

		// Copy Link Button
		var copyButtons = document.querySelectorAll('.asutsabo-share-copy');
		copyButtons.forEach(function (button) {
			button.addEventListener('click', function (e) {
				e.preventDefault();
				var targetUrl = button.getAttribute('data-url') || currentUrl;
				var feedbackEl = button.closest('.asutsabo-share-row') ? button.closest('.asutsabo-share-row').querySelector('.asutsabo-share-feedback') : null;
				var copiedMsg = l10n.copied || 'Link copied to clipboard!';
				var errorMsg = l10n.copyError || 'Failed to copy link.';

				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(targetUrl).then(function () {
						if (feedbackEl) {
							feedbackEl.textContent = copiedMsg;
							feedbackEl.setAttribute('role', 'status');
							setTimeout(function () {
								feedbackEl.textContent = '';
							}, 4000);
						}
					}).catch(function () {
						if (feedbackEl) {
							feedbackEl.textContent = errorMsg;
						}
					});
				} else {
					// Fallback for older browsers.
					var input = document.createElement('textarea');
					input.value = targetUrl;
					document.body.appendChild(input);
					input.select();
					try {
						document.execCommand('copy');
						if (feedbackEl) {
							feedbackEl.textContent = copiedMsg;
							setTimeout(function () {
								feedbackEl.textContent = '';
							}, 4000);
						}
					} catch (err) {
						if (feedbackEl) {
							feedbackEl.textContent = errorMsg;
						}
					}
					document.body.removeChild(input);
				}
			});
		});

		// Native Web Share API
		if (navigator.share) {
			var nativeTriggers = document.querySelectorAll('.asutsabo-share-native');
			nativeTriggers.forEach(function (trigger) {
				trigger.style.display = 'inline-flex';
				trigger.addEventListener('click', function (e) {
					e.preventDefault();
					navigator.share({
						title: currentTitle,
						url: currentUrl
					}).catch(function () {
						// User canceled share
					});
				});
			});
		}
	});
})();
