/**
 * Asutsabo Customizer Controls Script
 *
 * Provides real-time interactive management for the Homepage Sections Builder
 * and Navigation List Repeaters inside the WordPress Customizer.
 *
 * @package Asutsabo
 */

(function ($, wp) {
	'use strict';

	if (!wp || !wp.customize) {
		return;
	}

	$(document).ready(function () {
		initHomepageBuilder();
		initNavListRepeaters();
	});

	/**
	 * Initialize the Homepage Builder Controls.
	 */
	function initHomepageBuilder() {
		var $wrap = $('#asutsabo-hb-manager-wrap');
		if (!$wrap.length) {
			return;
		}

		var $container = $('#asutsabo-hb-cards-container');
		var $input     = $('#asutsabo-hb-data-input');
		var settingId  = 'asutsabo_homepage_sections';

		// Enable jQuery UI Sortable for drag-and-drop section reordering
		if ($.fn.sortable) {
			$container.sortable({
				handle: '.asutsabo-hb-drag-handle',
				axis: 'y',
				opacity: 0.8,
				placeholder: 'asutsabo-hb-sortable-placeholder',
				update: function () {
					serializeAndSave();
				}
			});
		}

		// Header click expands/collapses card (except when clicking controls)
		$container.on('click', '.asutsabo-hb-card-header', function (e) {
			if ($(e.target).closest('.asutsabo-hb-toggle-switch, .asutsabo-hb-btn-action, .asutsabo-hb-drag-handle').length) {
				return;
			}
			var $card = $(this).closest('.asutsabo-hb-card');
			$card.toggleClass('is-expanded');
			$card.find('.asutsabo-hb-card-body').slideToggle(180);
		});

		$container.on('click', '.asutsabo-hb-expand-btn', function (e) {
			e.stopPropagation();
			var $card = $(this).closest('.asutsabo-hb-card');
			$card.toggleClass('is-expanded');
			$card.find('.asutsabo-hb-card-body').slideToggle(180);
		});

		// Expand All / Collapse All
		$wrap.on('click', '.asutsabo-hb-expand-all', function () {
			$container.find('.asutsabo-hb-card').addClass('is-expanded');
			$container.find('.asutsabo-hb-card-body').slideDown(180);
		});

		$wrap.on('click', '.asutsabo-hb-collapse-all', function () {
			$container.find('.asutsabo-hb-card').removeClass('is-expanded');
			$container.find('.asutsabo-hb-card-body').slideUp(180);
		});

		// Enable / Disable toggle
		$container.on('change', '.asutsabo-hb-enabled-toggle', function () {
			var $card = $(this).closest('.asutsabo-hb-card');
			var checked = $(this).is(':checked');
			$card.toggleClass('is-disabled', !checked);
			serializeAndSave();
		});

		// Live update title text in card header
		$container.on('input', '.asutsabo-hb-title-input', function () {
			var val = $(this).val();
			var $card = $(this).closest('.asutsabo-hb-card');
			$card.find('.asutsabo-hb-card-title-text').text(val.trim() ? val : '(Untitled Section)');
			serializeAndSave();
		});

		// Live update layout badge in card header
		$container.on('change', '.asutsabo-hb-layout-select', function () {
			var $card = $(this).closest('.asutsabo-hb-card');
			var layoutText = $(this).find('option:selected').text();
			var layoutVal  = $(this).val();
			$card.find('.asutsabo-hb-layout-badge').text(layoutText);

			// Contextual options toggling
			var isGrid = (layoutVal === 'grid' || layoutVal === 'grid-3' || layoutVal === 'grid-4' || layoutVal === 'cards-2');
			var isCarousel = (layoutVal === 'feature-slider');

			$card.find('.asutsabo-hb-opt-grid').toggle(isGrid);
			$card.find('.asutsabo-hb-opt-carousel').toggle(isCarousel);

			serializeAndSave();
		});

		// Source conditional visibility
		$container.on('change', '.asutsabo-hb-source-select', function () {
			var $card = $(this).closest('.asutsabo-hb-card');
			var source = $(this).val();

			$card.find('.asutsabo-hb-source-conditional').hide();
			if (source === 'category') {
				$card.find('.asutsabo-hb-source-cat').show();
			} else if (source === 'categories') {
				$card.find('.asutsabo-hb-source-multi').show();
			} else if (source === 'tags') {
				$card.find('.asutsabo-hb-source-tags').show();
			} else if (source === 'manual') {
				$card.find('.asutsabo-hb-source-manual').show();
			}
			serializeAndSave();
		});

		// Count custom input toggle
		$container.on('change', '.asutsabo-hb-count-select', function () {
			var $card = $(this).closest('.asutsabo-hb-card');
			var val = $(this).val();
			if (val === 'custom') {
				$card.find('.asutsabo-hb-count-custom').show().focus();
			} else {
				$card.find('.asutsabo-hb-count-custom').hide();
			}
			serializeAndSave();
		});

		// Description toggle
		$container.on('change', '.asutsabo-hb-toggle-desc', function () {
			var $card = $(this).closest('.asutsabo-hb-card');
			$card.find('.asutsabo-hb-desc-wrap').toggle($(this).is(':checked'));
			serializeAndSave();
		});

		// View All toggle
		$container.on('change', '.asutsabo-hb-toggle-va', function () {
			var $card = $(this).closest('.asutsabo-hb-card');
			$card.find('.asutsabo-hb-va-wrap').toggle($(this).is(':checked'));
			serializeAndSave();
		});

		// Generic change on any field input
		$container.on('change input', '.asutsabo-hb-field', function (e) {
			if ($(this).hasClass('asutsabo-hb-title-input')) {
				return; // Handled separately
			}
			serializeAndSave();
		});

		// Reorder Up
		$container.on('click', '.asutsabo-hb-move-up', function (e) {
			e.stopPropagation();
			var $card = $(this).closest('.asutsabo-hb-card');
			var $prev = $card.prev('.asutsabo-hb-card');
			if ($prev.length) {
				$card.insertBefore($prev);
				serializeAndSave();
			}
		});

		// Reorder Down
		$container.on('click', '.asutsabo-hb-move-down', function (e) {
			e.stopPropagation();
			var $card = $(this).closest('.asutsabo-hb-card');
			var $next = $card.next('.asutsabo-hb-card');
			if ($next.length) {
				$card.insertAfter($next);
				serializeAndSave();
			}
		});

		// Duplicate Section
		$container.on('click', '.asutsabo-hb-duplicate, .asutsabo-hb-duplicate-btn', function (e) {
			e.stopPropagation();
			var $card = $(this).closest('.asutsabo-hb-card');
			var newId = 'sec_' + Date.now();
			var $clone = $card.clone();

			$clone.attr('data-id', newId);
			var oldTitle = $clone.find('.asutsabo-hb-title-input').val();
			var newTitle = oldTitle + ' ' + (window.asutsaboCustomizerData ? window.asutsaboCustomizerData.l10n.copied : '(Copy)');

			$clone.find('.asutsabo-hb-title-input').val(newTitle);
			$clone.find('.asutsabo-hb-card-title-text').text(newTitle);
			$clone.find('.asutsabo-hb-card-body').hide();
			$clone.removeClass('is-expanded');

			$clone.insertAfter($card);
			serializeAndSave();

			$clone.find('.asutsabo-hb-card-header').trigger('click');
		});

		// Delete Section
		$container.on('click', '.asutsabo-hb-delete, .asutsabo-hb-delete-btn', function (e) {
			e.stopPropagation();
			var confirmMsg = (window.asutsaboCustomizerData && window.asutsaboCustomizerData.l10n.confirmDelete) || 'Are you sure you want to delete this section?';
			if (window.confirm(confirmMsg)) {
				var $card = $(this).closest('.asutsabo-hb-card');
				$card.slideUp(180, function () {
					$(this).remove();
					serializeAndSave();
				});
			}
		});

		// Add Homepage Section
		$wrap.on('click', '.asutsabo-hb-add-section-btn', function () {
			var newId = 'section_' + Date.now();
			var defaultTitle = (window.asutsaboCustomizerData && window.asutsaboCustomizerData.l10n.newSectionTitle) || 'New Section';

			// Clone the first card as template, or build markup
			var $template = $container.find('.asutsabo-hb-card').first();
			if ($template.length) {
				var $newCard = $template.clone();
				$newCard.attr('data-id', newId);
				$newCard.removeClass('is-disabled is-expanded');
				$newCard.find('.asutsabo-hb-enabled-toggle').prop('checked', true);
				$newCard.find('.asutsabo-hb-title-input').val(defaultTitle);
				$newCard.find('.asutsabo-hb-card-title-text').text(defaultTitle);
				$newCard.find('.asutsabo-hb-layout-select').val('feature-list');
				$newCard.find('.asutsabo-hb-layout-badge').text('Featured + List');
				$newCard.find('.asutsabo-hb-source-select').val('latest');
				$newCard.find('.asutsabo-hb-source-conditional').hide();
				$newCard.find('.asutsabo-hb-count-select').val('4');
				$newCard.find('.asutsabo-hb-count-custom').hide().val('4');
				$newCard.find('.asutsabo-hb-toggle-desc').prop('checked', false);
				$newCard.find('.asutsabo-hb-desc-wrap').hide();
				$newCard.find('textarea').val('');
				$newCard.find('.asutsabo-hb-card-body').show();
				$newCard.addClass('is-expanded');

				$container.append($newCard);
				serializeAndSave();

				// Scroll into view
				$('html, body, .wp-full-overlay-sidebar-content').animate({
					scrollTop: $newCard.offset().top - 100
				}, 250);
				$newCard.find('.asutsabo-hb-title-input').focus();
			}
		});

		/**
		 * Read DOM cards into JSON and update Customizer setting.
		 */
		function serializeAndSave() {
			var sections = {};
			var order = 1;

			$container.find('.asutsabo-hb-card').each(function () {
				var $card = $(this);
				var secId = $card.attr('data-id') || ('sec_' + order);

				var countVal = $card.find('[data-key="count"]').val();
				var countNum = 4;
				if (countVal === 'custom') {
					countNum = parseInt($card.find('[data-key="count_custom"]').val(), 10) || 4;
				} else {
					countNum = parseInt(countVal, 10) || 4;
				}

				var secData = {
					id:                  secId,
					type:                'desk',
					title:               $card.find('[data-key="title"]').val() || '',
					show_title:          $card.find('[data-key="show_title"]').is(':checked'),
					description:         $card.find('[data-key="description"]').val() || '',
					show_desc:           $card.find('[data-key="show_desc"]').is(':checked'),
					show_view_all:       $card.find('[data-key="show_view_all"]').is(':checked'),
					view_all_text:       $card.find('[data-key="view_all_text"]').val() || 'View all',
					view_all_url:        $card.find('[data-key="view_all_url"]').val() || '',
					source:              $card.find('[data-key="source"]').val() || 'category',
					category:            $card.find('[data-key="category"]').val() || '',
					categories:          $card.find('[data-key="categories"]').val() || '',
					tags:                $card.find('[data-key="tags"]').val() || '',
					manual_ids:          $card.find('[data-key="manual_ids"]').val() || '',
					count:               countNum,
					layout:              $card.find('[data-key="layout"]').val() || 'feature-list',
					enabled:             $card.find('[data-key="enabled"]').is(':checked'),
					order:               order,
					badge:               $card.find('[data-key="badge"]').val() || '',
					show_badge:          $card.find('[data-key="show_badge"]').is(':checked'),
					show_date:           $card.find('[data-key="show_date"]').is(':checked'),
					show_author:         $card.find('[data-key="show_author"]').is(':checked'),
					show_excerpt:        $card.find('[data-key="show_excerpt"]').is(':checked'),
					columns:             parseInt($card.find('[data-key="columns"]').val(), 10) || 2,
					aspect_ratio:        $card.find('[data-key="aspect_ratio"]').val() || '16-9',
					carousel_autoplay:   $card.find('[data-key="carousel_autoplay"]').is(':checked'),
					carousel_speed:      parseInt($card.find('[data-key="carousel_speed"]').val(), 10) || 4000,
					carousel_arrows:     $card.find('[data-key="carousel_arrows"]').is(':checked'),
					carousel_dots:       $card.find('[data-key="carousel_dots"]').is(':checked'),
					carousel_visible:    1
				};

				sections[secId] = secData;
				order++;
			});

			// Update hidden input
			var jsonStr = JSON.stringify(sections);
			$input.val(jsonStr);

			// Tell WordPress Customizer the setting has changed
			if (wp.customize(settingId)) {
				wp.customize(settingId).set(sections);
			}
		}
	}

	/**
	 * Initialize Navigation List Repeater Controls (Sections & Standards Menus).
	 */
	function initNavListRepeaters() {
		$('.asutsabo-nav-list-manager-wrap').each(function () {
			var $wrap      = $(this);
			var $container = $wrap.find('.asutsabo-nav-list-items-container');
			var $input     = $wrap.find('.asutsabo-nav-list-input');
			var settingId  = $wrap.closest('[data-customize-setting-link]').attr('data-customize-setting-link') ||
			                 $input.attr('data-customize-setting-link');

			// Sortable
			if ($.fn.sortable) {
				$container.sortable({
					handle: '.asutsabo-nav-list-drag-handle',
					axis: 'y',
					update: function () {
						serializeNavList();
					}
				});
			}

			// Add Link
			$wrap.on('click', '.asutsabo-nav-list-add-btn', function () {
				var markup =
					'<div class="asutsabo-nav-list-item">' +
						'<div class="asutsabo-nav-list-item-row" style="display:flex;align-items:center;gap:6px;margin-bottom:6px;">' +
							'<span class="asutsabo-nav-list-drag-handle" style="cursor:grab;">&#9776;</span>' +
							'<input type="text" class="asutsabo-nav-item-title" value="New Link" placeholder="Link Text" style="flex:1;" />' +
							'<input type="text" class="asutsabo-nav-item-url" value="#" placeholder="https://..." style="flex:1;" />' +
							'<label class="asutsabo-nav-item-hide-toggle" title="Hide/Show Item">' +
								'<input type="checkbox" class="asutsabo-nav-item-hidden" checked />' +
							'</label>' +
							'<button type="button" class="asutsabo-nav-item-move-up button button-small">&#9650;</button>' +
							'<button type="button" class="asutsabo-nav-item-move-down button button-small">&#9660;</button>' +
							'<button type="button" class="asutsabo-nav-item-delete button button-small" style="color:#b32d2e;">&#128465;</button>' +
						'</div>' +
					'</div>';
				$container.append(markup);
				serializeNavList();
			});

			// Hide/Show Toggle
			$container.on('change', '.asutsabo-nav-item-hidden', function () {
				var $item = $(this).closest('.asutsabo-nav-list-item');
				$item.toggleClass('is-hidden', !$(this).is(':checked'));
				serializeNavList();
			});

			// Field change
			$container.on('input change', '.asutsabo-nav-item-title, .asutsabo-nav-item-url', function () {
				serializeNavList();
			});

			// Delete
			$container.on('click', '.asutsabo-nav-item-delete', function () {
				$(this).closest('.asutsabo-nav-list-item').remove();
				serializeNavList();
			});

			// Move Up / Down
			$container.on('click', '.asutsabo-nav-item-move-up', function () {
				var $item = $(this).closest('.asutsabo-nav-list-item');
				var $prev = $item.prev('.asutsabo-nav-list-item');
				if ($prev.length) {
					$item.insertBefore($prev);
					serializeNavList();
				}
			});

			$container.on('click', '.asutsabo-nav-item-move-down', function () {
				var $item = $(this).closest('.asutsabo-nav-list-item');
				var $next = $item.next('.asutsabo-nav-list-item');
				if ($next.length) {
					$item.insertAfter($next);
					serializeNavList();
				}
			});

			function serializeNavList() {
				var items = [];
				$container.find('.asutsabo-nav-list-item').each(function () {
					var $row = $(this);
					items.push({
						title:  $row.find('.asutsabo-nav-item-title').val() || '',
						url:    $row.find('.asutsabo-nav-item-url').val() || '',
						hidden: !$row.find('.asutsabo-nav-item-hidden').is(':checked')
					});
				});

				$input.val(JSON.stringify(items));
				$input.trigger('change');

				// Update Customizer setting if linked
				var customizerSetting = $input.attr('data-customize-setting-link');
				if (customizerSetting && wp.customize(customizerSetting)) {
					wp.customize(customizerSetting).set(items);
				}
			}
		});
	}

})(jQuery, window.wp);
