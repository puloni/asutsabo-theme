/**
 * Asutsabo Navigation Accessibility & Mobile Drawer Enhancement.
 *
 * Implements accessible keyboard focus management, Escape key listener,
 * mobile drawer toggle, and ARIA attributes for classic & hybrid navigation.
 *
 * @package Asutsabo
 */

(function () {
	'use strict';

	// Global carousel functions for homepage feature-slider
	window.asutsaboCarouselGoTo = function (carouselId, slideIndex) {
		var carousel = document.getElementById(carouselId);
		if (!carousel) return;
		var slides = carousel.querySelectorAll('.asutsabo-carousel-slide');
		var dots   = carousel.querySelectorAll('.asutsabo-dot');
		if (!slides.length) return;
		var total = slides.length;
		var current = (slideIndex + total) % total;
		carousel.setAttribute('data-current-slide', current);

		slides.forEach(function (slide, idx) {
			if (idx === current) {
				slide.classList.add('is-active');
			} else {
				slide.classList.remove('is-active');
			}
		});

		dots.forEach(function (dot, idx) {
			if (idx === current) {
				dot.classList.add('is-active');
			} else {
				dot.classList.remove('is-active');
			}
		});
	};

	window.asutsaboCarouselNext = function (carouselId) {
		var carousel = document.getElementById(carouselId);
		if (!carousel) return;
		var current = parseInt(carousel.getAttribute('data-current-slide') || '0', 10);
		window.asutsaboCarouselGoTo(carouselId, current + 1);
	};

	window.asutsaboCarouselPrev = function (carouselId) {
		var carousel = document.getElementById(carouselId);
		if (!carousel) return;
		var current = parseInt(carousel.getAttribute('data-current-slide') || '0', 10);
		window.asutsaboCarouselGoTo(carouselId, current - 1);
	};

	document.addEventListener('DOMContentLoaded', function () {
		var navToggles = document.querySelectorAll('.asutsabo-nav-toggle, .asutsabo-mobile-menu-toggle');
		var navMenu    = document.querySelector('.main-navigation');

		if (navToggles.length && navMenu) {
			navToggles.forEach(function (toggle) {
				toggle.addEventListener('click', function () {
					var expanded = toggle.getAttribute('aria-expanded') === 'true';
					navToggles.forEach(function (t) {
						t.setAttribute('aria-expanded', !expanded);
					});
					navMenu.classList.toggle('is-menu-open');
				});
			});
		}

		// Mobile search drawer toggle
		var searchToggle = document.querySelector('.asutsabo-mobile-search-toggle');
		var searchDrawer = document.querySelector('.asutsabo-mobile-search-drawer');
		if (searchToggle && searchDrawer) {
			searchToggle.addEventListener('click', function () {
				var isHidden = searchDrawer.style.display === 'none' || !searchDrawer.style.display;
				searchDrawer.style.display = isHidden ? 'block' : 'none';
				if (isHidden) {
					var input = searchDrawer.querySelector('input[type="search"]');
					if (input) {
						input.focus();
					}
				}
			});
		}

		// Close menu on Escape key.
		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape' || event.keyCode === 27) {
				if (navMenu && navMenu.classList.contains('is-menu-open')) {
					navMenu.classList.remove('is-menu-open');
					navToggles.forEach(function (t) {
						t.setAttribute('aria-expanded', 'false');
					});
				}
				if (searchDrawer && searchDrawer.style.display === 'block') {
					searchDrawer.style.display = 'none';
				}
			}
		});

		// Submenu dropdown keyboard accessibility
		var menuItemsWithChildren = document.querySelectorAll('.main-navigation .menu-item-has-children');
		menuItemsWithChildren.forEach(function (item) {
			var link = item.querySelector('a');
			if (link) {
				link.addEventListener('focus', function () {
					item.classList.add('is-focused');
				});
				link.addEventListener('blur', function () {
					setTimeout(function () {
						if (!item.contains(document.activeElement)) {
							item.classList.remove('is-focused');
						}
					}, 10);
				});
			}
		});
	});
})();
