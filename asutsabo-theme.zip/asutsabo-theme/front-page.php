<?php
/**
 * The template for displaying the magazine front page.
 *
 * Implements a dynamic, modular editorial layout driven by the Homepage Builder.
 * Allows full section reordering, independent section titles, customizable categories,
 * post counts, layout styles, and cleanly removable CTA and ad placements.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// Array to prevent duplicate stories across sections.
$displayed_posts = array();

/**
 * Helper to fetch category posts with duplicate exclusion and graceful fallbacks.
 *
 * @param string $slug            Category slug.
 * @param int    $count           Number of posts.
 * @param array  $displayed_posts Array of already displayed post IDs.
 * @return WP_Query
 */
function asutsabo_get_front_category_query( $slug, $count = 2, &$displayed_posts = array() ) {
	$args = array(
		'posts_per_page'      => $count > 0 ? $count : 2,
		'ignore_sticky_posts' => 1,
		'post_status'         => 'publish',
	);

	if ( ! empty( $slug ) ) {
		$args['category_name'] = sanitize_title( $slug );
	}

	if ( ! empty( $displayed_posts ) ) {
		$test_args = $args;
		$test_args['post__not_in'] = $displayed_posts;
		$test_query = new WP_Query( $test_args );
		if ( $test_query->have_posts() ) {
			$args['post__not_in'] = $displayed_posts;
		}
	}

	$query = new WP_Query( $args );

	// Fallback to recent posts if category has no posts yet.
	if ( ! $query->have_posts() ) {
		$fallback_args = array(
			'posts_per_page'      => $count > 0 ? $count : 2,
			'ignore_sticky_posts' => 1,
			'post_status'         => 'publish',
		);
		if ( ! empty( $displayed_posts ) ) {
			$fallback_args['post__not_in'] = $displayed_posts;
		}
		$query = new WP_Query( $fallback_args );
	}

	return $query;
}

/**
 * Helper to fetch section posts based on dynamic source (latest, category, categories, tags, manual)
 * with deduplication support and graceful fallbacks.
 *
 * @param array $sec             Section data array.
 * @param array $displayed_posts Array of already displayed post IDs.
 * @return WP_Query
 */
function asutsabo_get_section_posts_query( $sec, &$displayed_posts = array() ) {
	$count  = isset( $sec['count'] ) ? absint( $sec['count'] ) : 4;
	if ( $count <= 0 ) {
		$count = 4;
	}
	$source = isset( $sec['source'] ) ? $sec['source'] : 'category';

	$args = array(
		'posts_per_page'      => $count,
		'ignore_sticky_posts' => 1,
		'post_status'         => 'publish',
	);

	switch ( $source ) {
		case 'latest':
			// Recent posts across all categories
			break;

		case 'category':
			if ( ! empty( $sec['category'] ) ) {
				$args['category_name'] = sanitize_title( $sec['category'] );
			}
			break;

		case 'categories':
			$cats = isset( $sec['categories'] ) ? $sec['categories'] : '';
			if ( is_string( $cats ) ) {
				$cat_array = array_map( 'trim', explode( ',', $cats ) );
			} elseif ( is_array( $cats ) ) {
				$cat_array = $cats;
			} else {
				$cat_array = array();
			}
			$cat_array = array_filter( array_map( 'sanitize_title', $cat_array ) );
			if ( ! empty( $cat_array ) ) {
				$args['category_name'] = implode( ',', $cat_array );
			}
			break;

		case 'tags':
			if ( ! empty( $sec['tags'] ) ) {
				$tag_input = is_array( $sec['tags'] ) ? implode( ',', $sec['tags'] ) : $sec['tags'];
				$tag_array = array_filter( array_map( 'trim', explode( ',', $tag_input ) ) );
				if ( ! empty( $tag_array ) ) {
					$args['tag_slug__in'] = $tag_array;
				}
			}
			break;

		case 'manual':
			if ( ! empty( $sec['manual_ids'] ) ) {
				$ids = is_array( $sec['manual_ids'] ) ? $sec['manual_ids'] : explode( ',', $sec['manual_ids'] );
				$ids = array_filter( array_map( 'absint', $ids ) );
				if ( ! empty( $ids ) ) {
					$args['post__in']       = $ids;
					$args['orderby']        = 'post__in';
					$args['posts_per_page'] = count( $ids );
				}
			}
			break;

		default:
			if ( ! empty( $sec['category'] ) ) {
				$args['category_name'] = sanitize_title( $sec['category'] );
			}
			break;
	}

	// Handle deduplication across homepage sections
	if ( 'manual' !== $source && ! empty( $displayed_posts ) ) {
		$test_args = $args;
		$test_args['post__not_in'] = $displayed_posts;
		$test_query = new WP_Query( $test_args );
		if ( $test_query->have_posts() ) {
			$args['post__not_in'] = $displayed_posts;
		}
	}

	$query = new WP_Query( $args );

	// Graceful fallback to recent posts if no posts matched
	if ( ! $query->have_posts() && 'manual' !== $source ) {
		$fallback_args = array(
			'posts_per_page'      => $count,
			'ignore_sticky_posts' => 1,
			'post_status'         => 'publish',
		);
		if ( ! empty( $displayed_posts ) ) {
			$fallback_args['post__not_in'] = $displayed_posts;
		}
		$query = new WP_Query( $fallback_args );
		if ( ! $query->have_posts() ) {
			unset( $fallback_args['post__not_in'] );
			$query = new WP_Query( $fallback_args );
		}
	}

	return $query;
}

/**
 * Render section header with red vertical bar, optional description/subtitle, and optional View All link.
 *
 * @param array|string $sec      Section data array or section title.
 * @param string       $cat_slug Optional category slug fallback for "View all" link.
 */
function asutsabo_render_section_header( $sec, $cat_slug = '' ) {
	if ( is_string( $sec ) ) {
		$title      = $sec;
		$show_title = ! empty( $title );
		$show_desc  = false;
		$desc       = '';
		$show_va    = ! empty( $cat_slug );
		$va_text    = __( 'View all', 'asutsabo' );
		$va_url     = '';
		if ( ! empty( $cat_slug ) ) {
			$category = get_category_by_slug( $cat_slug );
			if ( $category ) {
				$va_url = get_category_link( $category->term_id );
			}
		}
	} else {
		$sec_data   = is_array( $sec ) ? $sec : array();
		$show_title = ! isset( $sec_data['show_title'] ) || ! empty( $sec_data['show_title'] );
		$title      = ! empty( $sec_data['title'] ) ? $sec_data['title'] : '';
		$show_desc  = ! empty( $sec_data['show_desc'] );
		$desc       = ! empty( $sec_data['description'] ) ? $sec_data['description'] : '';
		$show_va    = ! isset( $sec_data['show_view_all'] ) || ! empty( $sec_data['show_view_all'] );
		$va_text    = ! empty( $sec_data['view_all_text'] ) ? $sec_data['view_all_text'] : __( 'View all', 'asutsabo' );
		$va_url     = ! empty( $sec_data['view_all_url'] ) ? $sec_data['view_all_url'] : '';

		if ( empty( $va_url ) && ! empty( $sec_data['category'] ) ) {
			$category = get_category_by_slug( $sec_data['category'] );
			if ( $category ) {
				$va_url = get_category_link( $category->term_id );
			}
		}
	}

	if ( ! $show_title && ! ( $show_desc && ! empty( $desc ) ) && ! ( $show_va && ! empty( $va_url ) ) ) {
		return;
	}
	?>
	<div class="asutsabo-section-header">
		<div class="asutsabo-section-header-main">
			<?php if ( $show_title && ! empty( $title ) ) : ?>
				<h2 class="asutsabo-section-title">
					<span class="asutsabo-section-title-bar"></span>
					<span class="asutsabo-section-title-text"><?php echo esc_html( $title ); ?></span>
				</h2>
			<?php endif; ?>
			<?php if ( $show_desc && ! empty( $desc ) ) : ?>
				<p class="asutsabo-section-subtitle"><?php echo esc_html( $desc ); ?></p>
			<?php endif; ?>
		</div>
		<?php if ( $show_va && ! empty( $va_url ) ) : ?>
			<a href="<?php echo esc_url( $va_url ); ?>" class="asutsabo-section-view-all">
				<?php echo esc_html( $va_text ); ?> &rsaquo;
			</a>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Render a desk story column (used by split-column paired desks).
 *
 * @param array $sec             Section data.
 * @param array $displayed_posts Array of post IDs.
 */
function asutsabo_render_desk_column( $sec, &$displayed_posts ) {
	$title = ! empty( $sec['title'] ) ? $sec['title'] : '';
	$count = isset( $sec['count'] ) ? absint( $sec['count'] ) : 2;
	$cat   = isset( $sec['category'] ) ? $sec['category'] : '';

	$query = asutsabo_get_front_category_query( $cat, $count, $displayed_posts );
	?>
	<div class="asutsabo-desk-col asutsabo-desk-col-<?php echo esc_attr( $sec['id'] ); ?>">
		<?php if ( ! empty( $title ) ) : ?>
			<h2 class="is-style-asutsabo-section-label asutsabo-section-heading-<?php echo esc_attr( sanitize_title( $title ) ); ?>">
				<?php echo esc_html( $title ); ?>
			</h2>
		<?php endif; ?>

		<?php
		if ( $query->have_posts() ) :
			while ( $query->have_posts() ) :
				$query->the_post();
				$displayed_posts[] = get_the_ID();
				?>
				<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-desk-story' ); ?> style="margin-bottom:1.5rem;padding-bottom:1.25rem;border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);">
					<?php if ( has_post_thumbnail() ) : ?>
						<a href="<?php the_permalink(); ?>" style="display:block;margin-bottom:0.75rem;">
							<?php the_post_thumbnail( 'asutsabo-feature', array( 'style' => 'width:100%;height:auto;aspect-ratio:16/9;object-fit:cover;' ) ); ?>
						</a>
					<?php endif; ?>
					<?php asutsabo_category_kicker(); ?>
					<h3 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.35rem;line-height:1.2;margin:0.25rem 0 0.5rem 0;">
						<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
					</h3>
					<div style="font-size:0.875rem;line-height:1.5;color:var(--wp--preset--color--secondary, #474542);margin-bottom:0.5rem;">
						<?php the_excerpt(); ?>
					</div>
					<div class="is-style-asutsabo-metadata">
						<?php asutsabo_posted_by(); ?> &bull; <?php asutsabo_posted_on(); ?>
					</div>
				</article>
				<?php
			endwhile;
			wp_reset_postdata();
		endif;
		?>
	</div>
	<?php
}

$all_sections = asutsabo_get_homepage_sections();
$active_sections = array();
foreach ( $all_sections as $sec_key => $sec_data ) {
	if ( ! empty( $sec_data['enabled'] ) ) {
		$active_sections[] = $sec_data;
	}
}
?>

<main id="primary-content" class="site-main asutsabo-front-page-main asutsabo-container alignwide" style="padding-top:1.5rem;padding-bottom:3.5rem;">

	<?php
	// Dynamic Widget Area: Homepage Top (below navigation)
	if ( is_active_sidebar( 'home-top' ) ) :
		?>
		<aside class="asutsabo-home-widgets asutsabo-home-top-widgets" aria-label="<?php esc_attr_e( 'Homepage Top Widget Area', 'asutsabo' ); ?>" style="margin-bottom:2rem;">
			<?php dynamic_sidebar( 'home-top' ); ?>
		</aside>
	<?php endif; ?>

	<?php
	$total_active = count( $active_sections );
	$rendered_count = 0;
	$middle_widget_shown = false;

	for ( $i = 0; $i < $total_active; $i++ ) {
		$sec = $active_sections[ $i ];
		$sec_id = $sec['id'];
		$layout = isset( $sec['layout'] ) ? $sec['layout'] : 'split-column';
		$title  = isset( $sec['title'] ) ? $sec['title'] : '';
		$cat    = isset( $sec['category'] ) ? $sec['category'] : '';
		$count  = isset( $sec['count'] ) ? absint( $sec['count'] ) : 2;

		// ---------------------------------------------------------------------
		// 1. FAST WIRE TICKER
		// ---------------------------------------------------------------------
		if ( 'wire-ticker' === $layout || 'fast_wire' === $sec_id ) {
			$wire_count = $count > 0 ? $count : 6;
			$wire_args  = array(
				'posts_per_page'      => $wire_count,
				'ignore_sticky_posts' => 1,
				'post_status'         => 'publish',
			);
			if ( ! empty( $cat ) ) {
				$wire_args['category_name'] = sanitize_title( $cat );
			}
			$wire_query = new WP_Query( $wire_args );
			if ( ! $wire_query->have_posts() && ! empty( $cat ) ) {
				unset( $wire_args['category_name'] );
				$wire_query = new WP_Query( $wire_args );
			}
			?>
			<section class="asutsabo-section asutsabo-fast-wire" aria-label="<?php echo esc_attr( $title ); ?>" style="margin-bottom:2rem;">
				<?php if ( ! empty( $title ) ) : ?>
					<h3 class="is-style-asutsabo-section-label"><?php echo esc_html( $title ); ?></h3>
				<?php endif; ?>
				<?php if ( $wire_query->have_posts() ) : ?>
					<div class="asutsabo-wire-list" style="display:grid;grid-template-columns:repeat(auto-fill, minmax(320px, 1fr));gap:0.5rem 1.5rem;">
						<?php
						while ( $wire_query->have_posts() ) :
							$wire_query->the_post();
							?>
							<div class="asutsabo-wire-item" style="display:flex;align-items:baseline;padding:0.4rem 0;border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);gap:0.75rem;">
								<time class="asutsabo-wire-time is-style-asutsabo-metadata" datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ); ?>" style="font-family:var(--wp--preset--font-family--mono, monospace);font-size:0.75rem;flex-shrink:0;">
									<?php echo esc_html( get_the_date( 'H:i' ) ); ?>
								</time>
								<a href="<?php the_permalink(); ?>" class="asutsabo-wire-title" style="font-size:0.875rem;font-weight:600;color:inherit;text-decoration:none;line-height:1.35;">
									<?php the_title(); ?>
								</a>
							</div>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				<?php else : ?>
					<p class="asutsabo-no-content is-style-asutsabo-metadata"><?php esc_html_e( 'No wire updates at this moment.', 'asutsabo' ); ?></p>
				<?php endif; ?>
			</section>
			<?php
		}

		// ---------------------------------------------------------------------
		// 2. HERO: LEAD STORY & TOP DISPATCHES
		// ---------------------------------------------------------------------
		elseif ( 'hero-dispatches' === $layout || 'hero' === $sec_id ) {
			$disp_count = $count > 0 ? $count : 3;
			?>
			<section class="asutsabo-section asutsabo-hero-section" aria-label="<?php esc_attr_e( 'Lead Stories', 'asutsabo' ); ?>" style="margin-bottom:3rem;">
				<div class="asutsabo-hero-grid" style="display:grid;grid-template-columns:66.66% 33.33%;gap:2.5rem;">
					<!-- Lead Story (Left) -->
					<div class="asutsabo-hero-lead">
						<?php
						$lead_query = new WP_Query(
							array(
								'posts_per_page'      => 1,
								'ignore_sticky_posts' => 1,
								'post_status'         => 'publish',
							)
						);
						if ( $lead_query->have_posts() ) :
							while ( $lead_query->have_posts() ) :
								$lead_query->the_post();
								$displayed_posts[] = get_the_ID();
								?>
								<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-lead-article' ); ?>>
									<?php asutsabo_category_kicker(); ?>
									<h2 class="asutsabo-lead-title is-style-asutsabo-featured-headline" style="margin:0.25rem 0 0.75rem 0;">
										<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
									</h2>
									<?php if ( has_post_thumbnail() ) : ?>
										<div class="asutsabo-lead-media" style="margin:1rem 0;">
											<a href="<?php the_permalink(); ?>">
												<?php the_post_thumbnail( 'asutsabo-hero', array( 'style' => 'width:100%;height:auto;aspect-ratio:16/9;object-fit:cover;' ) ); ?>
											</a>
										</div>
									<?php endif; ?>
									<div class="asutsabo-lead-excerpt is-style-asutsabo-lead-paragraph" style="margin-bottom:1rem;">
										<?php the_excerpt(); ?>
									</div>
									<div class="asutsabo-lead-meta" style="display:flex;align-items:center;gap:1rem;">
										<?php asutsabo_posted_by( true, 28 ); ?>
										<?php asutsabo_posted_on(); ?>
									</div>
								</article>
								<?php
							endwhile;
							wp_reset_postdata();
						endif;
						?>
					</div>

					<!-- Secondary Top Dispatches (Right) -->
					<div class="asutsabo-hero-secondary" style="border-left:1px solid var(--wp--preset--color--border, #DED9D0);padding-left:2rem;">
						<?php if ( ! empty( $title ) ) : ?>
							<h3 class="is-style-asutsabo-section-label"><?php echo esc_html( $title ); ?></h3>
						<?php endif; ?>
						<?php
						$disp_args = array(
							'posts_per_page'      => $disp_count,
							'ignore_sticky_posts' => 1,
							'post_status'         => 'publish',
						);
						if ( ! empty( $cat ) ) {
							$disp_args['category_name'] = sanitize_title( $cat );
						} else {
							$disp_args['offset'] = 1;
						}
						if ( ! empty( $displayed_posts ) ) {
							$disp_args['post__not_in'] = $displayed_posts;
						}

						$dispatch_query = new WP_Query( $disp_args );

						if ( ! $dispatch_query->have_posts() ) {
							unset( $disp_args['post__not_in'] );
							if ( ! empty( $cat ) ) {
								unset( $disp_args['category_name'] );
							}
							$dispatch_query = new WP_Query( $disp_args );
						}

						if ( $dispatch_query->have_posts() ) :
							while ( $dispatch_query->have_posts() ) :
								$dispatch_query->the_post();
								$displayed_posts[] = get_the_ID();
								?>
								<article class="asutsabo-dispatch-item" style="padding-bottom:1.5rem;margin-bottom:1.5rem;border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);">
									<?php asutsabo_category_kicker(); ?>
									<h4 class="asutsabo-dispatch-title" style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.25rem;line-height:1.25;margin:0.25rem 0 0.5rem 0;">
										<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
									</h4>
									<div class="asutsabo-dispatch-excerpt" style="font-size:0.875rem;line-height:1.5;color:var(--wp--preset--color--secondary, #474542);margin-bottom:0.5rem;">
										<?php the_excerpt(); ?>
									</div>
									<div class="is-style-asutsabo-metadata">
										<?php asutsabo_posted_on(); ?>
									</div>
								</article>
								<?php
							endwhile;
							wp_reset_postdata();
						endif;
						?>
					</div>
				</div>
			</section>
			<?php
		}

		// ---------------------------------------------------------------------
		// FEATURE + LIST (Featured Overlay Card + Side Stories List)
		// ---------------------------------------------------------------------
		elseif ( 'feature-list' === $layout ) {
			$fl_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $fl_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-feature-list-section" style="margin-bottom:2.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-feature-list-grid">
						<?php
						$item_idx   = 0;
						$side_posts = array();

						while ( $fl_query->have_posts() ) :
							$fl_query->the_post();
							$displayed_posts[] = get_the_ID();
							if ( 0 === $item_idx ) :
								$badge = get_post_meta( get_the_ID(), '_asutsabo_badge', true );
								if ( empty( $badge ) && ! empty( $sec['badge'] ) ) {
									$badge = $sec['badge'];
								}
								if ( empty( $badge ) && ! empty( $cat ) ) {
									$category_obj = get_category_by_slug( $cat );
									if ( $category_obj ) {
										$badge = $category_obj->name;
									}
								}
								if ( empty( $badge ) ) {
									$c     = get_the_category();
									$badge = ! empty( $c ) ? $c[0]->name : '';
								}
								$show_badge = ! isset( $sec['show_badge'] ) || ! empty( $sec['show_badge'] );
								?>
								<div class="asutsabo-feature-lead-col">
									<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-feature-overlay-card' ); ?>>
										<a href="<?php the_permalink(); ?>" class="asutsabo-feature-overlay-link" aria-label="<?php the_title_attribute(); ?>">
											<?php if ( has_post_thumbnail() ) : ?>
												<?php the_post_thumbnail( 'asutsabo-feature', array( 'class' => 'asutsabo-feature-overlay-img' ) ); ?>
											<?php else : ?>
												<div class="asutsabo-feature-overlay-placeholder"></div>
											<?php endif; ?>
											<div class="asutsabo-feature-overlay-content">
												<?php if ( $show_badge && ! empty( $badge ) ) : ?>
													<span class="asutsabo-badge-pill"><?php echo esc_html( strtoupper( $badge ) ); ?></span>
												<?php endif; ?>
												<h3 class="asutsabo-feature-overlay-title">
													<?php the_title(); ?>
												</h3>
											</div>
										</a>
									</article>
								</div>
								<?php
							else :
								$side_posts[] = array(
									'id'        => get_the_ID(),
									'title'     => get_the_title(),
									'permalink' => get_permalink(),
									'thumbnail' => get_the_post_thumbnail( get_the_ID(), 'asutsabo-thumbnail-wide', array( 'class' => 'asutsabo-side-img' ) ),
								);
							endif;
							$item_idx++;
						endwhile;
						wp_reset_postdata();

						if ( ! empty( $side_posts ) ) :
							?>
							<div class="asutsabo-feature-side-col">
								<?php foreach ( $side_posts as $sp ) : ?>
									<article class="asutsabo-side-story-row">
										<a href="<?php echo esc_url( $sp['permalink'] ); ?>" class="asutsabo-side-story-thumb" aria-label="<?php echo esc_attr( $sp['title'] ); ?>">
											<?php if ( ! empty( $sp['thumbnail'] ) ) : ?>
												<?php echo $sp['thumbnail']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											<?php else : ?>
												<span class="asutsabo-side-placeholder"></span>
											<?php endif; ?>
										</a>
										<div class="asutsabo-side-story-body">
											<h4 class="asutsabo-side-story-title">
												<a href="<?php echo esc_url( $sp['permalink'] ); ?>">
													<?php echo esc_html( $sp['title'] ); ?>
												</a>
											</h4>
										</div>
									</article>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// FEATURE + SLIDER (Featured Slider Carousel + Side Stories List)
		// ---------------------------------------------------------------------
		elseif ( 'feature-slider' === $layout ) {
			$slider_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $slider_query->have_posts() ) :
				$all_posts    = $slider_query->posts;
				$slider_posts = array();
				$side_posts   = array();
				$s_idx        = 0;
				foreach ( $all_posts as $post_obj ) {
					$displayed_posts[] = $post_obj->ID;
					if ( $s_idx < 3 && count( $all_posts ) > 3 ) {
						$slider_posts[] = $post_obj;
					} elseif ( count( $all_posts ) <= 3 && 0 === $s_idx ) {
						$slider_posts[] = $post_obj;
					} else {
						$side_posts[] = $post_obj;
					}
					$s_idx++;
				}
				$carousel_id        = 'asutsabo-carousel-' . sanitize_html_class( $sec_id . '-' . $i );
				$carousel_arrows    = ! isset( $sec['carousel_arrows'] ) || ! empty( $sec['carousel_arrows'] );
				$carousel_dots      = ! isset( $sec['carousel_dots'] ) || ! empty( $sec['carousel_dots'] );
				$carousel_autoplay  = ! empty( $sec['carousel_autoplay'] );
				$carousel_speed     = ! empty( $sec['carousel_speed'] ) ? absint( $sec['carousel_speed'] ) : 4000;
				$show_badge         = ! isset( $sec['show_badge'] ) || ! empty( $sec['show_badge'] );
				?>
				<section class="asutsabo-section asutsabo-feature-slider-section" style="margin-bottom:2.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-feature-list-grid">
						<div class="asutsabo-feature-lead-col">
							<div id="<?php echo esc_attr( $carousel_id ); ?>" class="asutsabo-carousel-card" data-current-slide="0" data-autoplay="<?php echo $carousel_autoplay ? 'true' : 'false'; ?>" data-speed="<?php echo esc_attr( $carousel_speed ); ?>">
								<div class="asutsabo-carousel-slides">
									<?php foreach ( $slider_posts as $idx => $s_post ) :
										$badge = get_post_meta( $s_post->ID, '_asutsabo_badge', true );
										if ( empty( $badge ) && ! empty( $sec['badge'] ) ) {
											$badge = $sec['badge'];
										}
										if ( empty( $badge ) && ! empty( $cat ) ) {
											$category_obj = get_category_by_slug( $cat );
											if ( $category_obj ) {
												$badge = $category_obj->name;
											}
										}
										if ( empty( $badge ) ) {
											$c     = get_the_category( $s_post->ID );
											$badge = ! empty( $c ) ? $c[0]->name : '';
										}
										?>
										<article class="asutsabo-carousel-slide <?php echo 0 === $idx ? 'is-active' : ''; ?>" data-slide-index="<?php echo esc_attr( $idx ); ?>">
											<a href="<?php echo esc_url( get_permalink( $s_post->ID ) ); ?>" class="asutsabo-feature-overlay-link" aria-label="<?php echo esc_attr( get_the_title( $s_post->ID ) ); ?>">
												<?php if ( has_post_thumbnail( $s_post->ID ) ) : ?>
													<?php echo get_the_post_thumbnail( $s_post->ID, 'asutsabo-feature', array( 'class' => 'asutsabo-feature-overlay-img' ) ); ?>
												<?php else : ?>
													<div class="asutsabo-feature-overlay-placeholder"></div>
												<?php endif; ?>
												<div class="asutsabo-feature-overlay-content">
													<?php if ( $show_badge && ! empty( $badge ) ) : ?>
														<span class="asutsabo-badge-pill"><?php echo esc_html( strtoupper( $badge ) ); ?></span>
													<?php endif; ?>
													<h3 class="asutsabo-feature-overlay-title">
														<?php echo esc_html( get_the_title( $s_post->ID ) ); ?>
													</h3>
												</div>
											</a>
										</article>
									<?php endforeach; ?>
								</div>
								<?php if ( count( $slider_posts ) > 1 && $carousel_arrows ) : ?>
									<button type="button" class="asutsabo-carousel-arrow asutsabo-carousel-prev" aria-label="<?php esc_attr_e( 'Previous Slide', 'asutsabo' ); ?>" onclick="asutsaboCarouselPrev('<?php echo esc_js( $carousel_id ); ?>')">&lsaquo;</button>
									<button type="button" class="asutsabo-carousel-arrow asutsabo-carousel-next" aria-label="<?php esc_attr_e( 'Next Slide', 'asutsabo' ); ?>" onclick="asutsaboCarouselNext('<?php echo esc_js( $carousel_id ); ?>')">&rsaquo;</button>
								<?php endif; ?>
								<?php if ( count( $slider_posts ) > 1 && $carousel_dots ) : ?>
									<div class="asutsabo-carousel-dots">
										<?php foreach ( $slider_posts as $idx => $s_post ) : ?>
											<button type="button" class="asutsabo-dot <?php echo 0 === $idx ? 'is-active' : ''; ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'asutsabo' ), $idx + 1 ) ); ?>" onclick="asutsaboCarouselGoTo('<?php echo esc_js( $carousel_id ); ?>', <?php echo esc_js( $idx ); ?>)"></button>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>
							</div>
						</div>

						<?php if ( ! empty( $side_posts ) ) : ?>
							<div class="asutsabo-feature-side-col">
								<?php foreach ( $side_posts as $sp ) : ?>
									<article class="asutsabo-side-story-row">
										<a href="<?php echo esc_url( get_permalink( $sp->ID ) ); ?>" class="asutsabo-side-story-thumb" aria-label="<?php echo esc_attr( get_the_title( $sp->ID ) ); ?>">
											<?php if ( has_post_thumbnail( $sp->ID ) ) : ?>
												<?php echo get_the_post_thumbnail( $sp->ID, 'asutsabo-thumbnail-wide', array( 'class' => 'asutsabo-side-img' ) ); ?>
											<?php else : ?>
												<span class="asutsabo-side-placeholder"></span>
											<?php endif; ?>
										</a>
										<div class="asutsabo-side-story-body">
											<h4 class="asutsabo-side-story-title">
												<a href="<?php echo esc_url( get_permalink( $sp->ID ) ); ?>">
													<?php echo esc_html( get_the_title( $sp->ID ) ); ?>
												</a>
											</h4>
										</div>
									</article>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>
				</section>
				<?php
				wp_reset_postdata();
			endif;
		}

		// ---------------------------------------------------------------------
		// 3. OPINION & THE COLUMNISTS
		// ---------------------------------------------------------------------
		elseif ( 'opinion-columns' === $layout || 'opinion' === $sec_id ) {
			$op_count = $count > 0 ? $count : 3;
			$op_query = asutsabo_get_front_category_query( ! empty( $cat ) ? $cat : 'opinion', $op_count, $displayed_posts );
			if ( $op_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-opinion-section" style="margin:3.5rem 0;padding:2.5rem 0;border-top:2px solid var(--wp--preset--color--border-dark, #2B2927);border-bottom:1px solid var(--wp--preset--color--border-dark, #2B2927);">
					<?php if ( ! empty( $title ) ) : ?>
						<h2 class="is-style-asutsabo-section-label"><?php echo esc_html( $title ); ?></h2>
					<?php endif; ?>
					<div class="asutsabo-grid asutsabo-grid-3" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr));gap:2.5rem;">
						<?php
						while ( $op_query->have_posts() ) :
							$op_query->the_post();
							$displayed_posts[] = get_the_ID();
							?>
							<article class="asutsabo-opinion-col" style="border-right:1px solid var(--wp--preset--color--border, #DED9D0);padding-right:2rem;">
								<div class="asutsabo-opinion-author" style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem;">
									<span class="author-avatar" style="flex-shrink:0;">
										<?php echo get_avatar( get_the_author_meta( 'ID' ), 56, '', '', array( 'style' => 'border-radius:50%;' ) ); ?>
									</span>
									<div>
										<span class="is-style-asutsabo-kicker" style="display:block;"><?php esc_html_e( 'Column', 'asutsabo' ); ?></span>
										<strong style="font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.9rem;">
											<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" style="color:inherit;text-decoration:none;"><?php the_author(); ?></a>
										</strong>
									</div>
								</div>
								<h3 class="asutsabo-opinion-title" style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-style:italic;font-size:1.35rem;line-height:1.25;margin:0.5rem 0;">
									<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
								</h3>
								<div class="asutsabo-opinion-excerpt" style="font-size:0.875rem;line-height:1.5;color:var(--wp--preset--color--secondary, #474542);">
									<?php the_excerpt(); ?>
								</div>
							</article>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 4. ADVERTISEMENT LEADERBOARD
		// ---------------------------------------------------------------------
		elseif ( 'ad-banner' === $layout || 'ad_banner' === $sec_id ) {
			$ad_code = ! empty( $sec['ad_code'] ) ? $sec['ad_code'] : '';
			if ( ! empty( $ad_code ) ) :
				?>
				<div class="asutsabo-ad-container" style="margin:2.5rem auto;text-align:center;">
					<?php echo do_shortcode( wp_kses_post( $ad_code ) ); ?>
				</div>
			<?php else : ?>
				<div class="asutsabo-ad-placeholder asutsabo-ad-leaderboard">
					<span class="asutsabo-ad-label"><?php esc_html_e( 'Advertisement', 'asutsabo' ); ?></span>
					<span class="asutsabo-ad-dims">970 &times; 90 / 728 &times; 90</span>
				</div>
			<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 5. EDITORIAL BRIEFING / NEWSLETTER CTA
		// ---------------------------------------------------------------------
		elseif ( 'briefing' === $layout || 'briefing' === $sec_id ) {
			$eyebrow     = ! empty( $sec['newsletter_eyebrow'] ) ? $sec['newsletter_eyebrow'] : 'THE DAILY INTELLIGENCE';
			$headline    = ! empty( $sec['newsletter_headline'] ) ? $sec['newsletter_headline'] : __( 'Essential journalism, direct to your inbox.', 'asutsabo' );
			$description = ! empty( $sec['newsletter_desc'] ) ? $sec['newsletter_desc'] : '';
			$btn_text    = ! empty( $sec['newsletter_btn_text'] ) ? $sec['newsletter_btn_text'] : __( 'Join Free Briefing', 'asutsabo' );
			$btn_url     = ! empty( $sec['newsletter_btn_url'] ) ? $sec['newsletter_btn_url'] : '#subscribe';
			$disclaimer  = ! empty( $sec['newsletter_disclaimer'] ) ? $sec['newsletter_disclaimer'] : 'NO SPAM. ONE-CLICK UNSUBSCRIBE AT ANY TIME.';
			?>
			<section class="asutsabo-newsletter-box" aria-label="<?php esc_attr_e( 'Newsletter Subscription', 'asutsabo' ); ?>">
				<div class="asutsabo-newsletter-inner" style="display:grid;grid-template-columns:55% 45%;gap:2.5rem;align-items:center;">
					<div>
						<?php if ( ! empty( $eyebrow ) ) : ?>
							<span class="is-style-asutsabo-kicker asutsabo-briefing-eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
						<?php endif; ?>
						<h3 class="asutsabo-briefing-headline" style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.85rem;font-weight:800;line-height:1.15;margin:0.35rem 0 0.75rem 0;">
							<?php echo esc_html( $headline ); ?>
						</h3>
						<?php if ( ! empty( $description ) ) : ?>
							<p class="asutsabo-briefing-description" style="font-size:0.875rem;color:var(--wp--preset--color--secondary, #474542);margin:0;">
								<?php echo esc_html( $description ); ?>
							</p>
						<?php endif; ?>
					</div>
					<div>
						<form class="asutsabo-briefing-form" method="post" action="<?php echo esc_url( $btn_url ); ?>" style="display:flex;gap:0.5rem;flex-wrap:wrap;">
							<input type="email" name="asutsabo_email" placeholder="<?php esc_attr_e( 'Enter your email address...', 'asutsabo' ); ?>" required class="asutsabo-briefing-input" style="flex:1;min-width:180px;padding:0.75rem 1rem;border:1px solid var(--wp--preset--color--border, #DED9D0);border-radius:2px;font-size:0.875rem;background:var(--wp--preset--color--surface, #ffffff);color:var(--wp--preset--color--contrast, #141413);" />
							<button type="submit" class="asutsabo-btn asutsabo-briefing-button" style="padding:0.75rem 1.25rem;background:var(--wp--preset--color--primary, #181716);color:#ffffff;border:none;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;font-weight:700;cursor:pointer;border-radius:2px;white-space:nowrap;">
								<?php echo esc_html( $btn_text ); ?>
							</button>
						</form>
						<?php if ( ! empty( $disclaimer ) ) : ?>
							<p class="is-style-asutsabo-metadata asutsabo-briefing-disclaimer" style="margin-top:0.6rem;font-size:0.75rem;text-align:left;">
								<?php echo esc_html( $disclaimer ); ?>
							</p>
						<?php endif; ?>
					</div>
				</div>
			</section>
			<?php
		}

		// ---------------------------------------------------------------------
		// 6. SPLIT-COLUMN PAIRED DESK SECTIONS
		// ---------------------------------------------------------------------
		elseif ( 'split-column' === $layout ) {
			// Check if the next active section is also a split-column
			$has_paired_next = false;
			$next_sec = null;
			if ( ( $i + 1 ) < $total_active ) {
				$candidate = $active_sections[ $i + 1 ];
				$cand_layout = isset( $candidate['layout'] ) ? $candidate['layout'] : 'split-column';
				if ( 'split-column' === $cand_layout ) {
					$has_paired_next = true;
					$next_sec = $candidate;
				}
			}

			if ( $has_paired_next && $next_sec ) {
				?>
				<section class="asutsabo-section asutsabo-desks-section" style="margin-bottom:3rem;">
					<div class="asutsabo-grid asutsabo-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:2.5rem;">
						<?php
						asutsabo_render_desk_column( $sec, $displayed_posts );
						asutsabo_render_desk_column( $next_sec, $displayed_posts );
						?>
					</div>
				</section>
				<?php
				// Increment loop counter since we rendered two sections together
				$i++;
			} else {
				// Standalone desk section
				?>
				<section class="asutsabo-section asutsabo-desks-section" style="margin-bottom:3rem;">
					<div class="asutsabo-grid asutsabo-grid-1" style="display:grid;grid-template-columns:1fr;gap:2.5rem;">
						<?php asutsabo_render_desk_column( $sec, $displayed_posts ); ?>
					</div>
				</section>
				<?php
			}
		}

		// ---------------------------------------------------------------------
		// 7. 2-COLUMN STORY CARDS GRID
		// ---------------------------------------------------------------------
		elseif ( 'cards-2' === $layout ) {
			$q = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $q->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-cards-section" style="margin-bottom:2.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-cards-2-grid">
						<?php
						while ( $q->have_posts() ) :
							$q->the_post();
							$displayed_posts[] = get_the_ID();
							?>
							<article class="asutsabo-card-2-item">
								<a href="<?php the_permalink(); ?>" class="asutsabo-card-2-thumb-wrap" aria-label="<?php the_title_attribute(); ?>">
									<?php if ( has_post_thumbnail() ) : ?>
										<?php the_post_thumbnail( 'asutsabo-feature', array( 'class' => 'asutsabo-card-2-img' ) ); ?>
									<?php else : ?>
										<div class="asutsabo-card-2-img" style="background:#eee;"></div>
									<?php endif; ?>
								</a>
								<div class="asutsabo-card-2-body">
									<h3 class="asutsabo-card-2-title">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</h3>
								</div>
							</article>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 8. GRID / 3-COLUMN / 4-COLUMN GRID / CUSTOM GRID
		// ---------------------------------------------------------------------
		elseif ( 'grid' === $layout || 'grid-3' === $layout || 'grid-4' === $layout ) {
			$grid_cols = isset( $sec['columns'] ) ? absint( $sec['columns'] ) : ( 'grid-4' === $layout ? 4 : ( 'grid-3' === $layout ? 3 : 2 ) );
			if ( $grid_cols < 2 || $grid_cols > 4 ) {
				$grid_cols = 3;
			}
			$aspect = ! empty( $sec['aspect_ratio'] ) ? $sec['aspect_ratio'] : ( 'grid-3' === $layout ? '3-2' : '16-9' );
			$aspect_css = '16/9';
			if ( '3-2' === $aspect ) {
				$aspect_css = '3/2';
			} elseif ( '4-3' === $aspect ) {
				$aspect_css = '4/3';
			} elseif ( '1-1' === $aspect ) {
				$aspect_css = '1/1';
			}

			// Special handling for editor's pick if ID is editors_picks and source is category
			if ( 'editors_picks' === $sec_id && ( empty( $sec['source'] ) || 'category' === $sec['source'] ) ) {
				$editors_args = array(
					'posts_per_page'      => $count > 0 ? $count : 3,
					'ignore_sticky_posts' => 1,
					'post_status'         => 'publish',
					'meta_query'          => array(
						array(
							'key'     => '_asutsabo_editors_pick',
							'value'   => '1',
							'compare' => '=',
						),
					),
				);
				if ( ! empty( $displayed_posts ) ) {
					$editors_args['post__not_in'] = $displayed_posts;
				}
				$grid_query = new WP_Query( $editors_args );
				if ( ! $grid_query->have_posts() ) {
					$grid_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
				}
			} else {
				$grid_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			}

			if ( $grid_query->have_posts() ) :
				$show_badge   = ! isset( $sec['show_badge'] ) || ! empty( $sec['show_badge'] );
				$show_date    = ! isset( $sec['show_date'] ) || ! empty( $sec['show_date'] );
				$show_author  = ! isset( $sec['show_author'] ) || ! empty( $sec['show_author'] );
				$show_excerpt = ! isset( $sec['show_excerpt'] ) || ! empty( $sec['show_excerpt'] );
				?>
				<section class="asutsabo-section asutsabo-grid-section asutsabo-grid-cols-<?php echo esc_attr( $grid_cols ); ?>" style="margin-bottom:3.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-grid asutsabo-grid-<?php echo esc_attr( $grid_cols ); ?>" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(<?php echo 4 === $grid_cols ? '220px' : '280px'; ?>, 1fr));gap:2rem;">
						<?php
						while ( $grid_query->have_posts() ) :
							$grid_query->the_post();
							$displayed_posts[] = get_the_ID();
							?>
							<article class="asutsabo-card" style="border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);padding-bottom:1.5rem;">
								<?php if ( has_post_thumbnail() ) : ?>
									<a href="<?php the_permalink(); ?>" style="display:block;margin-bottom:0.75rem;aspect-ratio:<?php echo esc_attr( $aspect_css ); ?>;overflow:hidden;border-radius:4px;">
										<?php the_post_thumbnail( 'asutsabo-editorial-grid', array( 'style' => 'width:100%;height:100%;object-fit:cover;' ) ); ?>
									</a>
								<?php endif; ?>
								<?php if ( $show_badge ) : asutsabo_category_kicker(); endif; ?>
								<h3 class="asutsabo-card-title" style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.25rem;line-height:1.2;margin:0.25rem 0 0.5rem 0;">
									<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
								</h3>
								<?php if ( $show_excerpt ) : ?>
									<div class="asutsabo-card-excerpt" style="font-size:0.875rem;line-height:1.5;color:var(--wp--preset--color--secondary, #474542);margin-bottom:0.75rem;">
										<?php the_excerpt(); ?>
									</div>
								<?php endif; ?>
								<?php if ( $show_date || $show_author ) : ?>
									<div class="asutsabo-card-meta is-style-asutsabo-metadata">
										<?php if ( $show_author ) : asutsabo_posted_by(); endif; ?>
										<?php if ( $show_author && $show_date ) : ?> &bull; <?php endif; ?>
										<?php if ( $show_date ) : asutsabo_posted_on(); endif; ?>
									</div>
								<?php endif; ?>
							</article>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 9. COMPACT HEADLINE LIST
		// ---------------------------------------------------------------------
		elseif ( 'list' === $layout ) {
			$list_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $list_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-list-section" style="margin-bottom:2.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-side-col asutsabo-list-items">
						<?php
						while ( $list_query->have_posts() ) :
							$list_query->the_post();
							$displayed_posts[] = get_the_ID();
							?>
							<article class="asutsabo-side-story-row">
								<a href="<?php the_permalink(); ?>" class="asutsabo-side-story-thumb" aria-label="<?php the_title_attribute(); ?>">
									<?php if ( has_post_thumbnail() ) : ?>
										<?php the_post_thumbnail( 'asutsabo-thumbnail-wide', array( 'class' => 'asutsabo-side-img' ) ); ?>
									<?php else : ?>
										<span class="asutsabo-side-placeholder"></span>
									<?php endif; ?>
								</a>
								<div class="asutsabo-side-story-body">
									<h4 class="asutsabo-side-story-title">
										<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
									</h4>
								</div>
							</article>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 9B. HORIZONTAL CARDS
		// ---------------------------------------------------------------------
		elseif ( 'horizontal-cards' === $layout ) {
			$h_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $h_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-horizontal-cards-section" style="margin-bottom:2.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-horizontal-grid" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(320px, 1fr));gap:1.5rem;">
						<?php
						while ( $h_query->have_posts() ) :
							$h_query->the_post();
							$displayed_posts[] = get_the_ID();
							$show_badge   = ! isset( $sec['show_badge'] ) || ! empty( $sec['show_badge'] );
							$show_date    = ! isset( $sec['show_date'] ) || ! empty( $sec['show_date'] );
							$show_author  = ! isset( $sec['show_author'] ) || ! empty( $sec['show_author'] );
							$show_excerpt = ! isset( $sec['show_excerpt'] ) || ! empty( $sec['show_excerpt'] );
							?>
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-horizontal-card' ); ?> style="display:flex;gap:1.25rem;align-items:flex-start;padding-bottom:1.25rem;border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);">
								<?php if ( has_post_thumbnail() ) : ?>
									<a href="<?php the_permalink(); ?>" style="flex-shrink:0;width:140px;aspect-ratio:16/10;overflow:hidden;border-radius:4px;display:block;">
										<?php the_post_thumbnail( 'asutsabo-thumbnail-wide', array( 'style' => 'width:100%;height:100%;object-fit:cover;' ) ); ?>
									</a>
								<?php endif; ?>
								<div style="flex:1;min-width:0;">
									<?php if ( $show_badge ) : asutsabo_category_kicker(); endif; ?>
									<h3 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.15rem;line-height:1.25;margin:0.2rem 0 0.4rem 0;">
										<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
									</h3>
									<?php if ( $show_excerpt ) : ?>
										<div style="font-size:0.875rem;line-height:1.45;color:var(--wp--preset--color--secondary, #474542);margin-bottom:0.4rem;">
											<?php the_excerpt(); ?>
										</div>
									<?php endif; ?>
									<?php if ( $show_date || $show_author ) : ?>
										<div class="is-style-asutsabo-metadata">
											<?php if ( $show_author ) : asutsabo_posted_by(); endif; ?>
											<?php if ( $show_author && $show_date ) : ?> &bull; <?php endif; ?>
											<?php if ( $show_date ) : asutsabo_posted_on(); endif; ?>
										</div>
									<?php endif; ?>
								</div>
							</article>
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 9C. VERTICAL CARDS
		// ---------------------------------------------------------------------
		elseif ( 'vertical-cards' === $layout ) {
			$v_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $v_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-vertical-cards-section" style="margin-bottom:2.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-vertical-grid" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:1.5rem;">
						<?php
						while ( $v_query->have_posts() ) :
							$v_query->the_post();
							$displayed_posts[] = get_the_ID();
							$show_badge   = ! isset( $sec['show_badge'] ) || ! empty( $sec['show_badge'] );
							$show_date    = ! isset( $sec['show_date'] ) || ! empty( $sec['show_date'] );
							$show_author  = ! isset( $sec['show_author'] ) || ! empty( $sec['show_author'] );
							$show_excerpt = ! isset( $sec['show_excerpt'] ) || ! empty( $sec['show_excerpt'] );
							?>
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-vertical-card' ); ?> style="border:1px solid var(--wp--preset--color--border, #DED9D0);border-radius:6px;overflow:hidden;background:#fff;display:flex;flex-direction:column;">
								<?php if ( has_post_thumbnail() ) : ?>
									<a href="<?php the_permalink(); ?>" style="display:block;aspect-ratio:16/10;overflow:hidden;">
										<?php the_post_thumbnail( 'asutsabo-editorial-grid', array( 'style' => 'width:100%;height:100%;object-fit:cover;' ) ); ?>
									</a>
								<?php endif; ?>
								<div style="padding:1rem;flex:1;display:flex;flex-direction:column;">
									<?php if ( $show_badge ) : asutsabo_category_kicker(); endif; ?>
									<h3 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.15rem;line-height:1.25;margin:0.25rem 0 0.5rem 0;flex:1;">
										<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
									</h3>
									<?php if ( $show_excerpt ) : ?>
										<div style="font-size:0.875rem;line-height:1.45;color:var(--wp--preset--color--secondary, #474542);margin-bottom:0.5rem;">
											<?php the_excerpt(); ?>
										</div>
									<?php endif; ?>
									<?php if ( $show_date || $show_author ) : ?>
										<div class="is-style-asutsabo-metadata" style="margin-top:auto;padding-top:0.5rem;border-top:1px solid #f0ede6;">
											<?php if ( $show_author ) : asutsabo_posted_by(); endif; ?>
											<?php if ( $show_author && $show_date ) : ?> &bull; <?php endif; ?>
											<?php if ( $show_date ) : asutsabo_posted_on(); endif; ?>
										</div>
									<?php endif; ?>
								</div>
							</article>
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 9D. MAGAZINE LAYOUT
		// ---------------------------------------------------------------------
		elseif ( 'magazine' === $layout ) {
			$mag_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $mag_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-magazine-section" style="margin-bottom:3rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-magazine-wrapper">
						<?php
						$mag_idx = 0;
						$mag_sub = array();
						while ( $mag_query->have_posts() ) :
							$mag_query->the_post();
							$displayed_posts[] = get_the_ID();
							if ( 0 === $mag_idx ) :
								?>
								<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-magazine-lead' ); ?> style="margin-bottom:2rem;padding-bottom:1.5rem;border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);">
									<?php if ( has_post_thumbnail() ) : ?>
										<a href="<?php the_permalink(); ?>" style="display:block;margin-bottom:1rem;aspect-ratio:16/9;overflow:hidden;border-radius:6px;">
											<?php the_post_thumbnail( 'asutsabo-hero', array( 'style' => 'width:100%;height:100%;object-fit:cover;' ) ); ?>
										</a>
									<?php endif; ?>
									<?php asutsabo_category_kicker(); ?>
									<h2 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.85rem;line-height:1.2;margin:0.25rem 0 0.75rem 0;">
										<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
									</h2>
									<div style="font-size:1rem;line-height:1.6;color:var(--wp--preset--color--secondary, #474542);margin-bottom:0.75rem;">
										<?php the_excerpt(); ?>
									</div>
									<div class="is-style-asutsabo-metadata">
										<?php asutsabo_posted_by(); ?> &bull; <?php asutsabo_posted_on(); ?>
									</div>
								</article>
								<?php
							else :
								$mag_sub[] = array(
									'id'        => get_the_ID(),
									'title'     => get_the_title(),
									'permalink' => get_permalink(),
									'thumb'     => get_the_post_thumbnail( get_the_ID(), 'asutsabo-editorial-grid', array( 'style' => 'width:100%;aspect-ratio:3/2;object-fit:cover;border-radius:4px;margin-bottom:0.5rem;' ) ),
									'date'      => get_the_date(),
								);
							endif;
							$mag_idx++;
						endwhile;
						wp_reset_postdata();

						if ( ! empty( $mag_sub ) ) :
							?>
							<div class="asutsabo-grid asutsabo-grid-3" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:1.5rem;">
								<?php foreach ( $mag_sub as $ms ) : ?>
									<article class="asutsabo-magazine-sub-card" style="border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);padding-bottom:1rem;">
										<?php if ( ! empty( $ms['thumb'] ) ) : ?>
											<a href="<?php echo esc_url( $ms['permalink'] ); ?>" style="display:block;">
												<?php echo $ms['thumb']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											</a>
										<?php endif; ?>
										<h3 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.15rem;line-height:1.25;margin:0.25rem 0 0.4rem 0;">
											<a href="<?php echo esc_url( $ms['permalink'] ); ?>" style="color:inherit;text-decoration:none;">
												<?php echo esc_html( $ms['title'] ); ?>
											</a>
										</h3>
										<div class="is-style-asutsabo-metadata">
											<?php echo esc_html( $ms['date'] ); ?>
										</div>
									</article>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 10. MULTIMEDIA & VIDEO SHOWCASE
		// ---------------------------------------------------------------------
		elseif ( 'video-showcase' === $layout ) {
			$video_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $video_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-video-section" style="margin-bottom:3.5rem;">
					<div class="asutsabo-video-container" style="background:var(--wp--preset--color--primary, #181716);color:#FAF8F5;padding:2rem;border-radius:2px;">
						<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;border-bottom:1px solid rgba(255,255,255,0.15);padding-bottom:0.75rem;">
							<div style="display:flex;align-items:center;gap:0.75rem;">
								<span style="display:inline-block;width:10px;height:10px;background:var(--wp--preset--color--accent, #B81D24);border-radius:50%;"></span>
								<h2 class="is-style-asutsabo-section-label" style="color:#FAF8F5;margin:0;"><?php echo esc_html( ! empty( $title ) ? $title : __( 'Multimedia & Video Dispatches', 'asutsabo' ) ); ?></h2>
							</div>
							<span class="is-style-asutsabo-metadata" style="color:rgba(255,255,255,0.7);text-transform:uppercase;letter-spacing:0.05em;font-size:0.75rem;"><?php esc_html_e( 'Watch & Listen', 'asutsabo' ); ?></span>
						</div>

						<div class="asutsabo-video-grid" style="display:grid;grid-template-columns:1.6fr 1fr;gap:2rem;">
							<?php
							$v_idx = 0;
							$secondary_videos = array();

							while ( $video_query->have_posts() ) :
								$video_query->the_post();
								$displayed_posts[] = get_the_ID();

								if ( 0 === $v_idx ) :
									// Lead Video Feature
									?>
									<div class="asutsabo-video-lead">
										<?php if ( has_post_thumbnail() ) : ?>
											<div class="asutsabo-video-thumb-wrap" style="position:relative;margin-bottom:1rem;aspect-ratio:16/9;overflow:hidden;border-radius:2px;">
												<a href="<?php the_permalink(); ?>" style="display:block;">
													<?php the_post_thumbnail( 'asutsabo-feature', array( 'style' => 'width:100%;height:100%;object-fit:cover;' ) ); ?>
													<span class="asutsabo-play-overlay" style="position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);width:56px;height:56px;background:rgba(20,20,19,0.75);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#ffffff;font-size:1.5rem;box-shadow:0 4px 12px rgba(0,0,0,0.4);">&#9658;</span>
												</a>
											</div>
										<?php endif; ?>
										<?php asutsabo_category_kicker(); ?>
										<h3 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.65rem;font-weight:800;line-height:1.2;margin:0.35rem 0 0.5rem 0;">
											<a href="<?php the_permalink(); ?>" style="color:#FAF8F5;text-decoration:none;"><?php the_title(); ?></a>
										</h3>
										<div style="font-size:0.925rem;line-height:1.5;color:rgba(255,255,255,0.75);margin-bottom:0.75rem;">
											<?php the_excerpt(); ?>
										</div>
										<div class="is-style-asutsabo-metadata" style="color:rgba(255,255,255,0.6);">
											<?php asutsabo_posted_by(); ?> &bull; <?php asutsabo_posted_on(); ?>
										</div>
									</div>
									<?php
								else :
									$secondary_videos[] = array(
										'id'        => get_the_ID(),
										'title'     => get_the_title(),
										'permalink' => get_permalink(),
										'thumb'     => get_the_post_thumbnail( get_the_ID(), 'asutsabo-thumbnail-wide', array( 'style' => 'width:100px;height:65px;object-fit:cover;flex-shrink:0;border-radius:2px;' ) ),
										'date'      => get_the_date(),
									);
								endif;
								$v_idx++;
							endwhile;
							wp_reset_postdata();

							if ( ! empty( $secondary_videos ) ) :
								?>
								<div class="asutsabo-video-sidebar" style="display:flex;flex-direction:column;gap:1rem;border-left:1px solid rgba(255,255,255,0.12);padding-left:1.5rem;">
									<?php foreach ( $secondary_videos as $sv ) : ?>
										<div class="asutsabo-video-item" style="display:flex;gap:1rem;align-items:center;padding-bottom:1rem;border-bottom:1px solid rgba(255,255,255,0.08);">
											<?php if ( ! empty( $sv['thumb'] ) ) : ?>
												<a href="<?php echo esc_url( $sv['permalink'] ); ?>" style="position:relative;display:block;">
													<?php echo $sv['thumb']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
													<span style="position:absolute;bottom:4px;right:4px;background:rgba(0,0,0,0.8);color:#fff;font-size:0.65rem;padding:2px 4px;border-radius:2px;">&#9658;</span>
												</a>
											<?php endif; ?>
											<div>
												<h4 style="font-size:0.95rem;line-height:1.3;margin:0 0 0.35rem 0;">
													<a href="<?php echo esc_url( $sv['permalink'] ); ?>" style="color:#FAF8F5;text-decoration:none;">
														<?php echo esc_html( $sv['title'] ); ?>
													</a>
												</h4>
												<span class="is-style-asutsabo-metadata" style="color:rgba(255,255,255,0.55);font-size:0.75rem;">
													<?php echo esc_html( $sv['date'] ); ?>
												</span>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</section>
				<?php
			endif;
		}

		// ---------------------------------------------------------------------
		// 11. TRENDING & MOST READ DISPATCHES
		// ---------------------------------------------------------------------
		elseif ( 'trending' === $layout ) {
			$trend_query = asutsabo_get_section_posts_query( $sec, $displayed_posts );
			if ( $trend_query->have_posts() ) :
				?>
				<section class="asutsabo-section asutsabo-trending-section" style="margin-bottom:3.5rem;">
					<?php asutsabo_render_section_header( $sec ); ?>
					<div class="asutsabo-trending-grid" style="display:grid;grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));gap:1.5rem;border-top:2px solid var(--wp--preset--color--border-dark, #2B2927);padding-top:1.5rem;">
						<?php
						$rank = 0;
						while ( $trend_query->have_posts() ) :
							$trend_query->the_post();
							$displayed_posts[] = get_the_ID();
							$rank++;
							?>
							<article class="asutsabo-trending-card" style="display:flex;flex-direction:column;justify-content:space-between;border-right:1px solid var(--wp--preset--color--border, #DED9D0);padding-right:1.25rem;">
								<div>
									<span class="asutsabo-trend-rank" style="font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:2.25rem;font-weight:900;color:var(--wp--preset--color--accent, #B81D24);line-height:1;display:block;margin-bottom:0.5rem;">
										<?php printf( '%02d', $rank ); ?>
									</span>
									<?php asutsabo_category_kicker(); ?>
									<h3 style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.1rem;line-height:1.25;margin:0.25rem 0 0.5rem 0;">
										<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;">
											<?php the_title(); ?>
										</a>
									</h3>
								</div>
								<div class="is-style-asutsabo-metadata" style="font-size:0.75rem;margin-top:0.5rem;">
									<?php comments_number( __( 'No Comments', 'asutsabo' ), __( '1 Discussion', 'asutsabo' ), __( '% Discussions', 'asutsabo' ) ); ?>
								</div>
							</article>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</section>
				<?php
			endif;
		}

		$rendered_count++;

		// Middle dynamic sidebar insertion (typically after 3rd section or hero)
		if ( ! $middle_widget_shown && ( 3 === $rendered_count || 'hero' === $sec_id ) ) {
			if ( is_active_sidebar( 'home-middle' ) ) {
				?>
				<aside class="asutsabo-home-widgets asutsabo-home-middle-widgets" aria-label="<?php esc_attr_e( 'Homepage Middle Widget Area', 'asutsabo' ); ?>" style="margin-bottom:2.5rem;">
					<?php dynamic_sidebar( 'home-middle' ); ?>
				</aside>
				<?php
				$middle_widget_shown = true;
			}
		}
	}

	// Dynamic Widget Area: Homepage Bottom (above footer)
	if ( is_active_sidebar( 'home-bottom' ) ) :
		?>
		<aside class="asutsabo-home-widgets asutsabo-home-bottom-widgets" aria-label="<?php esc_attr_e( 'Homepage Bottom Widget Area', 'asutsabo' ); ?>" style="margin-top:2.5rem;margin-bottom:2.5rem;">
			<?php dynamic_sidebar( 'home-bottom' ); ?>
		</aside>
	<?php endif; ?>

</main><!-- #primary-content -->

<?php
get_footer();
