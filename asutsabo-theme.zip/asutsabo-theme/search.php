<?php
/**
 * The template for displaying search results pages.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

global $wp_query;
$total_results   = $wp_query->found_posts;
$asutsabo_layout = asutsabo_get_layout();
$has_sidebar     = ( 'right-sidebar' === $asutsabo_layout && is_active_sidebar( 'primary-sidebar' ) );
$layout_class    = $has_sidebar ? 'asutsabo-has-sidebar' : 'asutsabo-no-sidebar';
?>

<main id="primary-content" class="site-main asutsabo-search-main asutsabo-container alignwide <?php echo esc_attr( $layout_class ); ?>" style="padding-top:2rem;padding-bottom:4rem;">
	<header class="page-header asutsabo-search-header" style="border-bottom:2px solid var(--wp--preset--color--border-dark, #2B2927);padding-bottom:1.5rem;margin-bottom:2.5rem;">
		<span class="is-style-asutsabo-kicker"><?php esc_html_e( 'Search The Newsroom', 'asutsabo' ); ?></span>
		<h1 class="page-title is-style-asutsabo-featured-headline" style="margin:0.25rem 0 0.5rem 0;">
			<?php
			/* translators: %s: search query. */
			printf( esc_html__( 'Search Results for: %s', 'asutsabo' ), '<span style="font-style:italic;">&ldquo;' . esc_html( get_search_query() ) . '&rdquo;</span>' );
			?>
		</h1>
		<div class="asutsabo-search-meta is-style-asutsabo-metadata" style="margin-bottom:1.5rem;">
			<?php
			/* translators: %d: number of results */
			printf( esc_html__( '%d matching dispatches found', 'asutsabo' ), (int) $total_results );
			?>
		</div>
		<div class="asutsabo-search-form-wrap" style="max-width:560px;">
			<?php get_search_form(); ?>
		</div>
	</header>

	<div class="asutsabo-layout-container <?php echo $has_sidebar ? 'asutsabo-layout-with-sidebar' : 'asutsabo-layout-single-column'; ?>">
		<div class="asutsabo-content-column">
			<?php if ( have_posts() ) : ?>
				<div class="asutsabo-grid asutsabo-archive-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/post/content' );
					endwhile;
					?>
				</div>

				<div class="asutsabo-pagination-wrap" style="margin-top:3.5rem;text-align:center;">
					<?php
					the_posts_pagination(
						array(
							'prev_text' => __( '&larr; Previous', 'asutsabo' ),
							'next_text' => __( 'Next &rarr;', 'asutsabo' ),
						)
					);
					?>
				</div>
			<?php else : ?>
				<div class="asutsabo-no-results" style="padding:2.5rem 0;max-width:740px;">
					<h3 class="is-style-asutsabo-section-label"><?php esc_html_e( 'No Stories Matched Your Query', 'asutsabo' ); ?></h3>
					<p style="font-size:1.125rem;line-height:1.6;color:var(--wp--preset--color--secondary, #474542);margin-bottom:1.5rem;">
						<?php esc_html_e( 'We could not find any reports matching your search terms. Try searching with different keywords, check for typographical errors, or browse our latest dispatches.', 'asutsabo' ); ?>
					</p>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="asutsabo-btn asutsabo-btn-primary" style="display:inline-block;padding:0.6rem 1.25rem;background:var(--wp--preset--color--primary, #181716);color:#ffffff;text-decoration:none;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;font-weight:700;border-radius:2px;">
						<?php esc_html_e( 'Return to Front Page', 'asutsabo' ); ?> &rarr;
					</a>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $has_sidebar ) : ?>
			<div class="asutsabo-sidebar-column">
				<?php get_sidebar(); ?>
			</div>
		<?php endif; ?>
	</div>
</main><!-- #primary-content -->

<?php
get_footer();
