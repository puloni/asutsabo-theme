<?php
/**
 * The template for displaying all static pages.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$asutsabo_layout = asutsabo_get_layout();
$has_sidebar     = ( 'right-sidebar' === $asutsabo_layout && is_active_sidebar( 'primary-sidebar' ) );
$layout_class    = $has_sidebar ? 'asutsabo-has-sidebar' : 'asutsabo-no-sidebar';
?>

<main id="primary-content" class="site-main asutsabo-page-main asutsabo-container alignwide <?php echo esc_attr( $layout_class ); ?>" style="padding-top:2.5rem;padding-bottom:4rem;">
	<?php
	while ( have_posts() ) :
		the_post();
		$post_id    = get_the_ID();
		$hide_title = (bool) get_post_meta( $post_id, '_asutsabo_hide_title', true );
		$hide_thumb = (bool) get_post_meta( $post_id, '_asutsabo_hide_featured_image', true );
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-page-article' ); ?>>
			<?php if ( ! $hide_title ) : ?>
				<header class="entry-header asutsabo-page-header" style="max-width:780px;margin:0 auto 2.5rem auto;text-align:center;">
					<span class="is-style-asutsabo-kicker"><?php esc_html_e( 'Publication Dispatch', 'asutsabo' ); ?></span>
					<h1 class="entry-title is-style-asutsabo-featured-headline" style="margin:0.5rem 0 1rem 0;">
						<?php the_title(); ?>
					</h1>
					<hr class="wp-block-separator is-style-asutsabo-divider-double" style="margin:1.5rem auto;max-width:300px;" />
				</header>
			<?php endif; ?>

			<?php if ( ! $hide_thumb && has_post_thumbnail() ) : ?>
				<div class="entry-media asutsabo-page-featured-media" style="margin-bottom:2.5rem;text-align:center;">
					<?php the_post_thumbnail( 'asutsabo-hero', array( 'style' => 'width:100%;max-width:960px;height:auto;aspect-ratio:16/9;object-fit:cover;margin:0 auto;' ) ); ?>
				</div>
			<?php endif; ?>

			<div class="asutsabo-layout-container <?php echo $has_sidebar ? 'asutsabo-layout-with-sidebar' : 'asutsabo-layout-single-column'; ?>">
				<div class="asutsabo-content-column">
					<!-- In-Page Table of Contents -->
					<?php asutsabo_render_table_of_contents( $post_id ); ?>

					<div class="entry-content asutsabo-page-content" style="font-size:1.125rem;line-height:1.75;">
						<?php
						the_content();

						wp_link_pages(
							array(
								'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'asutsabo' ),
								'after'  => '</div>',
							)
						);
						?>
					</div>
				</div>

				<?php if ( $has_sidebar ) : ?>
					<div class="asutsabo-sidebar-column">
						<?php get_sidebar(); ?>
					</div>
				<?php endif; ?>
			</div>
		</article>
	<?php endwhile; ?>
</main><!-- #primary-content -->

<?php
get_footer();
