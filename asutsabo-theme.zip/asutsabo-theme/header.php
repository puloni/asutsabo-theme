<?php
/**
 * The header for the Asutsabo theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php asutsabo_render_reading_progress_bar(); ?>

<div id="page" class="site asutsabo-site-wrapper">
	<a class="skip-link screen-reader-text" href="#primary-content"><?php esc_html_e( 'Skip to content', 'asutsabo' ); ?></a>

	<header id="masthead" class="site-header asutsabo-site-header">
		<?php get_template_part( 'template-parts/header/breaking-news' ); ?>

		<?php get_template_part( 'template-parts/header/masthead' ); ?>

		<div class="asutsabo-nav-container-wrap" style="border-bottom:2px solid var(--wp--preset--color--border-dark, #2B2927);">
			<div class="asutsabo-container alignwide asutsabo-navigation-bar" style="padding:0.65rem 1.5rem;">
				<div class="asutsabo-nav-controls" style="display:flex;align-items:center;justify-content:space-between;gap:1rem;width:100%;">
					<button class="asutsabo-nav-toggle menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle Navigation Menu', 'asutsabo' ); ?>">
						<span class="asutsabo-nav-toggle-icon" aria-hidden="true">&#9776;</span>
						<span class="asutsabo-nav-toggle-text"><?php esc_html_e( 'Menu', 'asutsabo' ); ?></span>
					</button>

					<?php if ( get_theme_mod( 'asutsabo_show_search', true ) ) : ?>
						<div class="asutsabo-header-search header-search">
							<?php get_search_form(); ?>
						</div>
					<?php endif; ?>
				</div>

				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_id'        => 'primary-menu',
						'container'      => 'nav',
						'container_class'=> 'main-navigation asutsabo-nav',
						'menu_class'     => 'nav-menu asutsabo-nav-menu',
						'fallback_cb'    => 'asutsabo_primary_menu_fallback',
						'depth'          => 2,
					)
				);
				?>
			</div>
		</div>
	</header>

	<div id="content" class="site-content asutsabo-site-content">
