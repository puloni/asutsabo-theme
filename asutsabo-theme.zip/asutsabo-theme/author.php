<?php
/**
 * The template for displaying Author archive pages.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$author_id      = get_queried_object_id();
$author_title   = get_user_meta( $author_id, 'asutsabo_job_title', true );
$twitter        = get_user_meta( $author_id, 'asutsabo_twitter', true );
$linkedin       = get_user_meta( $author_id, 'asutsabo_linkedin', true );
$bluesky        = get_user_meta( $author_id, 'asutsabo_bluesky', true );
$user_url       = get_the_author_meta( 'user_url', $author_id );

$asutsabo_layout = asutsabo_get_layout();
$has_sidebar     = ( 'right-sidebar' === $asutsabo_layout && is_active_sidebar( 'primary-sidebar' ) );
$layout_class    = $has_sidebar ? 'asutsabo-has-sidebar' : 'asutsabo-no-sidebar';
?>

<main id="primary-content" class="site-main asutsabo-author-main asutsabo-container alignwide <?php echo esc_attr( $layout_class ); ?>" style="padding-top:2rem;padding-bottom:4rem;">
	<!-- Author Profile Masthead -->
	<header class="page-header asutsabo-author-header asutsabo-author-bio-card" style="margin-bottom:3rem;">
		<?php echo get_avatar( $author_id, 100, '', '', array( 'style' => 'border-radius:50%;flex-shrink:0;' ) ); ?>
		<div class="asutsabo-author-profile-details">
			<span class="is-style-asutsabo-kicker"><?php esc_html_e( 'Staff Journalist &bull; Dispatches by', 'asutsabo' ); ?></span>
			<h1 class="page-title is-style-asutsabo-featured-headline" style="margin:0.25rem 0 0.5rem 0;font-size:2.25rem;">
				<?php echo esc_html( get_the_author_meta( 'display_name', $author_id ) ); ?>
			</h1>

			<?php if ( ! empty( $author_title ) ) : ?>
				<div class="is-style-asutsabo-metadata" style="font-weight:700;font-size:0.95rem;color:var(--wp--preset--color--primary, #181716);margin-bottom:0.5rem;">
					<?php echo esc_html( $author_title ); ?>
				</div>
			<?php endif; ?>

			<?php if ( get_the_author_meta( 'description', $author_id ) ) : ?>
				<p class="asutsabo-author-bio-text" style="font-size:1rem;line-height:1.6;color:var(--wp--preset--color--secondary, #474542);margin:0.5rem 0 0.75rem 0;">
					<?php echo esc_html( get_the_author_meta( 'description', $author_id ) ); ?>
				</p>
			<?php endif; ?>

			<div class="is-style-asutsabo-metadata" style="margin-bottom:0.75rem;">
				<?php
				/* translators: %d: article count */
				printf( esc_html__( '%d Published Dispatches', 'asutsabo' ), (int) count_user_posts( $author_id ) );
				?>
			</div>

			<?php if ( ! empty( $twitter ) || ! empty( $linkedin ) || ! empty( $bluesky ) || ! empty( $user_url ) ) : ?>
				<div class="asutsabo-author-social-links" style="display:flex;align-items:center;gap:0.75rem;font-size:0.8125rem;">
					<span style="font-weight:700;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.75rem;text-transform:uppercase;letter-spacing:0.05em;color:var(--wp--preset--color--muted, #6E6B65);"><?php esc_html_e( 'Connect:', 'asutsabo' ); ?></span>
					<?php if ( ! empty( $twitter ) ) :
						$t_url = ( strpos( $twitter, 'http' ) === 0 ) ? $twitter : 'https://x.com/' . ltrim( $twitter, '@' );
					?>
						<a href="<?php echo esc_url( $t_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'Twitter / X Profile', 'asutsabo' ); ?>">
							<?php echo asutsabo_get_social_icon_svg( 'twitter' ); ?>
							<span>X</span>
						</a>
					<?php endif; ?>

					<?php if ( ! empty( $linkedin ) ) :
						$li_url = ( strpos( $linkedin, 'http' ) === 0 ) ? $linkedin : 'https://linkedin.com/in/' . $linkedin;
					?>
						<a href="<?php echo esc_url( $li_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'LinkedIn Profile', 'asutsabo' ); ?>">
							<?php echo asutsabo_get_social_icon_svg( 'linkedin' ); ?>
							<span>LinkedIn</span>
						</a>
					<?php endif; ?>

					<?php if ( ! empty( $bluesky ) ) :
						$bsky_url = ( strpos( $bluesky, 'http' ) === 0 ) ? $bluesky : 'https://bsky.app/profile/' . ltrim( $bluesky, '@' );
					?>
						<a href="<?php echo esc_url( $bsky_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'Bluesky Profile', 'asutsabo' ); ?>">
							<?php echo asutsabo_get_social_icon_svg( 'bluesky' ); ?>
							<span>Bluesky</span>
						</a>
					<?php endif; ?>

					<?php if ( ! empty( $user_url ) ) : ?>
						<a href="<?php echo esc_url( $user_url ); ?>" target="_blank" rel="noopener noreferrer" style="display:inline-flex;align-items:center;gap:0.25rem;color:inherit;text-decoration:none;" aria-label="<?php esc_attr_e( 'Personal Website', 'asutsabo' ); ?>">
							<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>
							<span><?php esc_html_e( 'Website', 'asutsabo' ); ?></span>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</header>

	<div class="asutsabo-layout-container <?php echo $has_sidebar ? 'asutsabo-layout-with-sidebar' : 'asutsabo-layout-single-column'; ?>">
		<div class="asutsabo-content-column">
			<h2 class="is-style-asutsabo-section-label"><?php esc_html_e( 'Articles & Reporting', 'asutsabo' ); ?></h2>

			<?php if ( have_posts() ) : ?>
				<div class="asutsabo-grid asutsabo-archive-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/post/content' );
					endwhile;
					?>
				</div>

				<div class="asutsabo-pagination-wrap" style="margin-top:3.5rem;text-align:center;">
					<?php
					the_posts_pagination(
						array(
							'prev_text' => __( '&larr; Previous', 'asutsabo' ),
							'next_text' => __( 'Next &rarr;', 'asutsabo' ),
						)
					);
					?>
				</div>
			<?php else : ?>
				<div class="asutsabo-no-results" style="padding:3rem 0;text-align:center;">
					<h3 class="is-style-asutsabo-section-label"><?php esc_html_e( 'No Articles Published Yet', 'asutsabo' ); ?></h3>
					<p style="font-size:1.1rem;color:var(--wp--preset--color--secondary, #474542);">
						<?php esc_html_e( 'This staff journalist has not published any stories yet.', 'asutsabo' ); ?>
					</p>
					<?php get_search_form(); ?>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $has_sidebar ) : ?>
			<div class="asutsabo-sidebar-column">
				<?php get_sidebar(); ?>
			</div>
		<?php endif; ?>
	</div>
</main><!-- #primary-content -->

<?php
get_footer();
