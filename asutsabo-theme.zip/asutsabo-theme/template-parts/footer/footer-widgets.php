<?php
/**
 * Template part for displaying the multi-column footer widget area.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$show_col2   = (bool) get_theme_mod( 'asutsabo_footer_col2_show', true );
$col2_title  = get_theme_mod( 'asutsabo_footer_col2_title', __( 'Sections', 'asutsabo' ) );
$col2_custom = get_theme_mod( 'asutsabo_footer_col2_custom_content', '' );

$show_col3   = (bool) get_theme_mod( 'asutsabo_footer_col3_show', true );
$col3_title  = get_theme_mod( 'asutsabo_footer_col3_title', __( 'Standards', 'asutsabo' ) );
$col3_custom = get_theme_mod( 'asutsabo_footer_col3_custom_content', '' );
?>
<div class="asutsabo-footer-widgets-area">
	<div class="asutsabo-container alignwide">
		<div class="asutsabo-footer-grid">
			<!-- Column 1: About -->
			<div class="asutsabo-footer-col asutsabo-footer-col-1">
				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<?php dynamic_sidebar( 'footer-1' ); ?>
				<?php else : ?>
					<h3 class="asutsabo-footer-site-title" style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.75rem;font-weight:800;margin:0 0 0.5rem 0;">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;text-decoration:none;"><?php bloginfo( 'name' ); ?></a>
					</h3>
					<?php
					$tagline = get_bloginfo( 'description' );
					if ( $tagline ) :
						?>
						<p class="asutsabo-footer-tagline is-style-asutsabo-metadata" style="margin:0 0 1rem 0;letter-spacing:0.06em;color:var(--wp--preset--color--secondary, #474542);">
							<?php echo esc_html( $tagline ); ?>
						</p>
					<?php endif; ?>
					<div class="asutsabo-footer-bio" style="font-size:0.875rem;line-height:1.6;color:var(--wp--preset--color--secondary, #474542);margin:0;">
						<?php
						$footer_bio = get_theme_mod(
							'asutsabo_footer_bio',
							esc_html__( 'A digital publication devoted to fearless journalism, deep investigative reporting, critical commentary, and cultural analysis. Founded on principles of truth, nuance, and editorial rigor.', 'asutsabo' )
						);
						echo wp_kses_post( $footer_bio );
						?>
					</div>
				<?php endif; ?>
			</div>

			<!-- Column 2: Sections -->
			<?php if ( $show_col2 || is_customize_preview() ) : ?>
				<div class="asutsabo-footer-col asutsabo-footer-col-2" <?php if ( ! $show_col2 ) : ?>style="display:none;"<?php endif; ?>>
					<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
						<?php dynamic_sidebar( 'footer-2' ); ?>
					<?php else : ?>
						<?php if ( ! empty( $col2_title ) ) : ?>
							<h4 class="footer-widget-title is-style-asutsabo-section-label"><?php echo esc_html( $col2_title ); ?></h4>
						<?php endif; ?>

						<?php if ( ! empty( $col2_custom ) && '' !== trim( wp_strip_all_tags( $col2_custom ) ) ) : ?>
							<div class="asutsabo-footer-custom-content">
								<?php echo wp_kses_post( $col2_custom ); ?>
							</div>
						<?php elseif ( has_nav_menu( 'footer-sections' ) ) : ?>
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer-sections',
									'menu_class'     => 'asutsabo-footer-list',
									'container'      => false,
									'depth'          => 1,
									'fallback_cb'    => false,
								)
							);
							?>
						<?php elseif ( function_exists( 'asutsabo_get_sections_menu_items' ) ) : ?>
							<ul class="asutsabo-footer-list" style="list-style:none;padding:0;margin:0;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;line-height:2;">
								<?php
								$sec_items = asutsabo_get_sections_menu_items();
								if ( ! empty( $sec_items ) && is_array( $sec_items ) ) :
									foreach ( $sec_items as $item ) :
										if ( ! empty( $item['hidden'] ) ) {
											continue;
										}
										$item_title = ! empty( $item['title'] ) ? $item['title'] : '';
										$item_url   = ! empty( $item['url'] ) ? $item['url'] : '#';
										if ( $item_title ) :
											?>
											<li><a href="<?php echo esc_url( $item_url ); ?>" style="color:inherit;text-decoration:none;"><?php echo esc_html( $item_title ); ?></a></li>
											<?php
										endif;
									endforeach;
								endif;
								?>
							</ul>
						<?php else : ?>
							<ul class="asutsabo-footer-list" style="list-style:none;padding:0;margin:0;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;line-height:2;">
								<?php
								$footer_cats = get_categories( array( 'number' => 6, 'hide_empty' => false ) );
								foreach ( $footer_cats as $fc ) {
									if ( $fc->slug === 'uncategorized' ) {
										continue;
									}
									echo '<li><a href="' . esc_url( get_category_link( $fc->term_id ) ) . '" style="color:inherit;text-decoration:none;">' . esc_html( $fc->name ) . '</a></li>';
								}
								?>
							</ul>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<!-- Column 3: Standards -->
			<?php if ( $show_col3 || is_customize_preview() ) : ?>
				<div class="asutsabo-footer-col asutsabo-footer-col-3" <?php if ( ! $show_col3 ) : ?>style="display:none;"<?php endif; ?>>
					<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
						<?php dynamic_sidebar( 'footer-3' ); ?>
					<?php else : ?>
						<?php if ( ! empty( $col3_title ) ) : ?>
							<h4 class="footer-widget-title is-style-asutsabo-section-label"><?php echo esc_html( $col3_title ); ?></h4>
						<?php endif; ?>

						<?php if ( ! empty( $col3_custom ) && '' !== trim( wp_strip_all_tags( $col3_custom ) ) ) : ?>
							<div class="asutsabo-footer-custom-content">
								<?php echo wp_kses_post( $col3_custom ); ?>
							</div>
						<?php elseif ( has_nav_menu( 'footer-standards' ) ) : ?>
							<?php
							wp_nav_menu(
								array(
									'theme_location' => 'footer-standards',
									'menu_class'     => 'asutsabo-footer-list',
									'container'      => false,
									'depth'          => 1,
									'fallback_cb'    => 'asutsabo_footer_menu_fallback',
								)
							);
							?>
						<?php elseif ( function_exists( 'asutsabo_get_standards_menu_items' ) ) : ?>
							<ul class="asutsabo-footer-list" style="list-style:none;padding:0;margin:0;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;line-height:2;">
								<?php
								$std_items = asutsabo_get_standards_menu_items();
								if ( ! empty( $std_items ) && is_array( $std_items ) ) :
									foreach ( $std_items as $item ) :
										if ( ! empty( $item['hidden'] ) ) {
											continue;
										}
										$item_title = ! empty( $item['title'] ) ? $item['title'] : '';
										$item_url   = ! empty( $item['url'] ) ? $item['url'] : '#';
										if ( $item_title ) :
											?>
											<li><a href="<?php echo esc_url( $item_url ); ?>" style="color:inherit;text-decoration:none;"><?php echo esc_html( $item_title ); ?></a></li>
											<?php
										endif;
									endforeach;
								endif;
								?>
							</ul>
						<?php else : ?>
							<?php asutsabo_footer_menu_fallback(); ?>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>

		</div>
	</div>
</div>
