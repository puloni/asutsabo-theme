<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="asutsabo-no-results no-results not-found" style="padding:3rem 0;text-align:center;">
	<header class="page-header">
		<h2 class="is-style-asutsabo-section-label"><?php esc_html_e( 'Nothing Found', 'asutsabo' ); ?></h2>
	</header>

	<div class="page-content" style="max-width:600px;margin:1.5rem auto 0 auto;">
		<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>
			<p>
				<?php
				printf(
					wp_kses(
						/* translators: 1: link to WP admin new post page. */
						__( 'Ready to publish your first dispatch? <a href="%1$s">Get started here</a>.', 'asutsabo' ),
						array(
							'a' => array(
								'href' => array(),
							),
						)
					),
					esc_url( admin_url( 'post-new.php' ) )
				);
				?>
			</p>
		<?php elseif ( is_search() ) : ?>
			<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'asutsabo' ); ?></p>
			<?php get_search_form(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'asutsabo' ); ?></p>
			<?php get_search_form(); ?>
		<?php endif; ?>
	</div>
</div>
