<?php
/**
 * Template part for displaying posts in archives and loops.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-card' ); ?> style="border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);padding-bottom:1.5rem;">
	<?php if ( has_post_thumbnail() ) : ?>
		<a href="<?php the_permalink(); ?>" style="display:block;margin-bottom:0.75rem;">
			<?php the_post_thumbnail( 'asutsabo-editorial-grid', array( 'style' => 'width:100%;height:auto;aspect-ratio:3/2;object-fit:cover;' ) ); ?>
		</a>
	<?php endif; ?>

	<?php asutsabo_category_kicker(); ?>

	<h2 class="asutsabo-card-title" style="font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.25rem;line-height:1.25;margin:0.25rem 0 0.5rem 0;">
		<a href="<?php the_permalink(); ?>" style="color:inherit;text-decoration:none;"><?php the_title(); ?></a>
	</h2>

	<div class="asutsabo-card-excerpt" style="font-size:0.875rem;line-height:1.5;color:var(--wp--preset--color--secondary, #474542);margin-bottom:0.75rem;">
		<?php the_excerpt(); ?>
	</div>

	<div class="asutsabo-card-meta is-style-asutsabo-metadata">
		<?php asutsabo_posted_by(); ?> &bull; <?php asutsabo_posted_on(); ?>
	</div>
</article>
