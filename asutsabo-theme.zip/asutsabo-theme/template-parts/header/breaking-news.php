<?php
/**
 * Template part for displaying the breaking news ticker in the header.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$breaking_enabled = get_theme_mod( 'asutsabo_breaking_news_enable', true );
if ( ! $breaking_enabled ) {
	return;
}

$badge_text = get_theme_mod( 'asutsabo_breaking_news_badge', 'BREAKING NEWS' );
$category   = get_theme_mod( 'asutsabo_breaking_news_category', '' );
$post_count = absint( get_theme_mod( 'asutsabo_breaking_news_count', 4 ) );
if ( $post_count < 1 ) {
	$post_count = 4;
}

$args = array(
	'posts_per_page'      => $post_count,
	'ignore_sticky_posts' => 1,
	'post_status'         => 'publish',
);

if ( ! empty( $category ) ) {
	$args['category_name'] = sanitize_title( $category );
}

$breaking_query = new WP_Query( $args );

// Fallback to latest published posts if category is empty or has no posts
if ( ! $breaking_query->have_posts() && ! empty( $category ) ) {
	unset( $args['category_name'] );
	$breaking_query = new WP_Query( $args );
}

if ( $breaking_query->have_posts() ) :
	$breaking_posts = $breaking_query->posts;
	$first_id       = $breaking_posts[0]->ID;
	$total_items    = count( $breaking_posts );
	?>
	<aside aria-label="<?php esc_attr_e( 'Breaking News', 'asutsabo' ); ?>" class="asutsabo-breaking-news" data-alert-id="breaking-<?php echo esc_attr( $first_id ); ?>">
		<div class="asutsabo-breaking-news-inner" style="display:flex;align-items:center;flex:1;overflow:hidden;">
			<span class="asutsabo-breaking-news-label">
				<span class="asutsabo-breaking-news-pulse" aria-hidden="true"></span>
				<?php echo esc_html( $badge_text ); ?>
			</span>

			<div class="asutsabo-breaking-news-content asutsabo-breaking-carousel" style="flex:1;overflow:hidden;position:relative;">
				<?php
				$idx = 0;
				foreach ( $breaking_posts as $post_obj ) :
					$active_class = ( 0 === $idx ) ? ' is-active' : '';
					$display_style = ( 0 === $idx ) ? 'display:inline-block;' : 'display:none;';
					?>
					<span class="asutsabo-breaking-slide<?php echo esc_attr( $active_class ); ?>" data-slide-index="<?php echo esc_attr( $idx ); ?>" style="<?php echo esc_attr( $display_style ); ?>white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;">
						<a href="<?php echo esc_url( get_permalink( $post_obj->ID ) ); ?>" class="asutsabo-breaking-news-link" style="font-weight:600;">
							<?php echo esc_html( get_the_title( $post_obj->ID ) ); ?>
						</a>
					</span>
					<?php
					$idx++;
				endforeach;
				?>
			</div>

			<?php if ( $total_items > 1 ) : ?>
				<div class="asutsabo-breaking-controls" aria-label="<?php esc_attr_e( 'Breaking news navigation', 'asutsabo' ); ?>" style="display:inline-flex;align-items:center;gap:0.35rem;margin:0 0.75rem;">
					<button type="button" class="asutsabo-breaking-nav asutsabo-breaking-prev" aria-label="<?php esc_attr_e( 'Previous headline', 'asutsabo' ); ?>">&lsaquo;</button>
					<span class="asutsabo-breaking-counter" style="font-size:0.75rem;opacity:0.85;">
						<span class="asutsabo-breaking-current">1</span>/<span class="asutsabo-breaking-total"><?php echo esc_html( $total_items ); ?></span>
					</span>
					<button type="button" class="asutsabo-breaking-nav asutsabo-breaking-next" aria-label="<?php esc_attr_e( 'Next headline', 'asutsabo' ); ?>">&rsaquo;</button>
				</div>
			<?php endif; ?>
		</div>
		<button type="button" class="asutsabo-breaking-news-dismiss" aria-label="<?php esc_attr_e( 'Dismiss breaking news alert', 'asutsabo' ); ?>">&times;</button>
	</aside>
	<?php
endif;
wp_reset_postdata();
