<?php
/**
 * Template part for displaying the newspaper masthead.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$show_date     = get_theme_mod( 'asutsabo_show_date', true );
$date_format   = get_theme_mod( 'asutsabo_date_format', '' );
$custom_format = ! empty( $date_format ) ? $date_format : get_option( 'date_format', 'l, F j, Y' );
$edition_text  = get_theme_mod( 'asutsabo_edition_text', 'DIGITAL EDITION' );

// Site identity display mode & granular toggles
$display_mode = get_theme_mod( 'asutsabo_site_title_display', 'all' );
$show_logo    = (bool) get_theme_mod( 'asutsabo_show_site_logo', true );
$show_title   = (bool) get_theme_mod( 'asutsabo_show_site_title', true );
$show_tagline = (bool) get_theme_mod( 'asutsabo_show_site_tagline', true );

if ( 'logo_tagline' === $display_mode ) {
	$show_logo    = true;
	$show_title   = false;
	$show_tagline = true;
} elseif ( 'title_tagline' === $display_mode ) {
	$show_logo    = false;
	$show_title   = true;
	$show_tagline = true;
} elseif ( 'logo_only' === $display_mode ) {
	$show_logo    = true;
	$show_title   = false;
	$show_tagline = false;
} elseif ( 'title_only' === $display_mode ) {
	$show_logo    = false;
	$show_title   = true;
	$show_tagline = false;
}
?>
<div class="asutsabo-masthead">
	<!-- Mobile Header Bar (Visible on screens <= 768px) -->
	<div class="asutsabo-mobile-header-bar">
		<button type="button" class="asutsabo-mobile-search-toggle" aria-label="<?php esc_attr_e( 'Search', 'asutsabo' ); ?>">
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
		</button>
		<div class="asutsabo-mobile-brand">
			<?php if ( $show_logo && has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
			<?php endif; ?>
		</div>
		<button type="button" class="asutsabo-mobile-menu-toggle menu-toggle" aria-controls="primary-menu" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle Navigation Menu', 'asutsabo' ); ?>">
			<span class="asutsabo-hamburger-icon" aria-hidden="true">
				<span></span>
				<span></span>
				<span></span>
			</span>
		</button>
	</div>
	<div class="asutsabo-mobile-search-drawer" style="display:none;">
		<?php get_search_form(); ?>
	</div>

	<?php if ( $show_date || ! empty( $edition_text ) || is_customize_preview() ) : ?>
		<div class="asutsabo-masthead-top asutsabo-container alignwide" style="display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1.5rem;border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.75rem;letter-spacing:0.05em;text-transform:uppercase;color:var(--wp--preset--color--muted, #6E6B65);">
			<div class="asutsabo-today-date" <?php if ( ! $show_date ) : ?>style="display:none;"<?php endif; ?>>
				<?php echo esc_html( wp_date( $custom_format ) ); ?>
			</div>
			<div class="asutsabo-edition-label">
				<?php echo esc_html( $edition_text ); ?>
			</div>
		</div>
	<?php endif; ?>

	<div class="asutsabo-masthead-center asutsabo-container alignwide" style="text-align:center;padding:2.5rem 1.5rem 1.75rem 1.5rem;">
		<?php
		if ( $show_logo && has_custom_logo() ) {
			the_custom_logo();
		}
		?>

		<?php if ( $show_title ) : ?>
			<?php if ( is_front_page() && is_home() ) : ?>
				<h1 class="site-title asutsabo-site-title" style="margin:0.25rem 0;font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:clamp(2.75rem, 7vw, 4.75rem);letter-spacing:-0.03em;font-weight:800;line-height:1;">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="color:var(--wp--preset--color--primary, #181716);text-decoration:none;"><?php bloginfo( 'name' ); ?></a>
				</h1>
			<?php else : ?>
				<p class="site-title asutsabo-site-title" style="margin:0.25rem 0;font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:clamp(2.75rem, 7vw, 4.75rem);letter-spacing:-0.03em;font-weight:800;line-height:1;">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="color:var(--wp--preset--color--primary, #181716);text-decoration:none;"><?php bloginfo( 'name' ); ?></a>
				</p>
			<?php endif; ?>
		<?php else : ?>
			<span class="screen-reader-text"><?php bloginfo( 'name' ); ?></span>
		<?php endif; ?>

		<?php
		$description = get_bloginfo( 'description', 'display' );
		if ( $show_tagline && ( $description || is_customize_preview() ) ) :
			?>
			<p class="site-description asutsabo-site-tagline" style="margin:0.5rem 0 0 0;font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;letter-spacing:0.08em;text-transform:uppercase;color:var(--wp--preset--color--secondary, #474542);">
				<?php echo esc_html( $description ); ?>
			</p>
		<?php endif; ?>
	</div>

	<div class="asutsabo-container alignwide">
		<hr class="wp-block-separator is-style-asutsabo-divider-double" style="margin:0.5rem 0 1rem 0;" />
	</div>
</div>
