<?php
/**
 * Asutsabo functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define constants.
 */
define( 'ASUTSABO_VERSION', '1.1.0' );
define( 'ASUTSABO_DIR', get_template_directory() );
define( 'ASUTSABO_URI', get_template_directory_uri() );

/**
 * Core theme setup and asset enqueues.
 */
require_once ASUTSABO_DIR . '/inc/setup.php';

/**
 * Block style variations registration.
 */
require_once ASUTSABO_DIR . '/inc/block-styles.php';

/**
 * Block pattern categories registration.
 */
require_once ASUTSABO_DIR . '/inc/block-patterns.php';

/**
 * Template tags and editorial helpers.
 */
require_once ASUTSABO_DIR . '/inc/template-tags.php';

/**
 * Structured data & technical SEO fallback.
 */
require_once ASUTSABO_DIR . '/inc/structured-data.php';

/**
 * Theme Customizer definitions.
 */
require_once ASUTSABO_DIR . '/inc/customizer.php';

/**
 * Homepage Builder & Section Management.
 */
require_once ASUTSABO_DIR . '/inc/homepage-builder.php';

/**
 * One-click demo content importer.
 */
if ( is_admin() ) {
	require_once ASUTSABO_DIR . '/inc/demo-importer/demo-import-page.php';
}


