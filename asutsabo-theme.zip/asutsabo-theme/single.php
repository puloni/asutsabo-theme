<?php
/**
 * The template for displaying all single posts.
 *
 * @package Asutsabo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$asutsabo_layout = asutsabo_get_layout();
$has_sidebar     = ( 'right-sidebar' === $asutsabo_layout && is_active_sidebar( 'primary-sidebar' ) );
$layout_class    = $has_sidebar ? 'asutsabo-has-sidebar' : 'asutsabo-no-sidebar';
?>

<main id="primary-content" class="site-main asutsabo-single-main asutsabo-container alignwide <?php echo esc_attr( $layout_class ); ?>" style="padding-top:2rem;padding-bottom:4rem;">
	<?php
	while ( have_posts() ) :
		the_post();
		$post_id = get_the_ID();

		$hide_title   = (bool) get_post_meta( $post_id, '_asutsabo_hide_title', true );
		$hide_thumb   = (bool) get_post_meta( $post_id, '_asutsabo_hide_featured_image', true );
		$hide_byline  = (bool) get_post_meta( $post_id, '_asutsabo_hide_byline', true );
		$hide_share   = (bool) get_post_meta( $post_id, '_asutsabo_hide_share', true );
		$hide_bio     = (bool) get_post_meta( $post_id, '_asutsabo_hide_author_bio', true );
		$hide_related = (bool) get_post_meta( $post_id, '_asutsabo_hide_related', true );
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'asutsabo-single-article asutsabo-article-layout' ); ?>>

			<!-- Article Header -->
			<header class="entry-header asutsabo-article-header" style="margin-bottom:2.5rem;">
				<?php asutsabo_category_kicker(); ?>

				<?php if ( ! $hide_title ) : ?>
					<h1 class="entry-title is-style-asutsabo-featured-headline" style="margin:0.35rem 0 1rem 0;">
						<?php the_title(); ?>
					</h1>
				<?php endif; ?>

				<?php
				$asutsabo_subtitle = get_post_meta( $post_id, '_asutsabo_subtitle', true );
				if ( ! empty( $asutsabo_subtitle ) && '' !== trim( wp_strip_all_tags( $asutsabo_subtitle ) ) ) :
				?>
					<div class="entry-lead is-style-asutsabo-lead-paragraph asutsabo-post-subtitle" style="margin-bottom:1.5rem;">
						<?php echo wp_kses_post( $asutsabo_subtitle ); ?>
					</div>
				<?php endif; ?>

				<!-- Comprehensive Byline & Reading Time -->
				<?php if ( ! $hide_byline ) : ?>
					<div class="asutsabo-byline-bar" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;padding:1rem 0;border-top:1px solid var(--wp--preset--color--border, #DED9D0);border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);margin-bottom:1.5rem;">
						<div class="asutsabo-byline-left" style="display:flex;align-items:center;gap:0.75rem;">
							<span class="author-avatar" style="flex-shrink:0;">
								<?php echo get_avatar( get_the_author_meta( 'ID' ), 44, '', '', array( 'style' => 'border-radius:50%;' ) ); ?>
							</span>
							<div>
								<strong style="font-family:var(--wp--preset--font-family--sans, sans-serif);font-size:0.875rem;display:block;">
									<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" style="color:inherit;text-decoration:none;"><?php the_author(); ?></a>
								</strong>
								<div class="is-style-asutsabo-metadata">
									<?php asutsabo_posted_on(); ?>
								</div>
							</div>
						</div>

						<div class="asutsabo-byline-right is-style-asutsabo-metadata" style="display:flex;align-items:center;gap:1rem;">
							<span class="asutsabo-reading-time">&#9201; <?php echo esc_html( asutsabo_get_reading_time() ); ?></span>
						</div>
					</div>
				<?php endif; ?>

				<!-- Reader Toolbar (Font Size & Dark/Sepia Mode) -->
				<?php asutsabo_render_reader_controls(); ?>

				<?php if ( has_post_thumbnail() && ! $hide_thumb ) : ?>
					<div class="entry-media asutsabo-featured-image-wrap" style="margin:2rem 0;">
						<?php the_post_thumbnail( 'asutsabo-hero', array( 'style' => 'width:100%;height:auto;aspect-ratio:16/9;object-fit:cover;' ) ); ?>
						<?php if ( get_the_post_thumbnail_caption() ) : ?>
							<p class="is-style-asutsabo-caption" style="margin-top:0.5rem;">
								<?php echo esc_html( get_the_post_thumbnail_caption() ); ?>
							</p>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<!-- Audio Dispatch Player -->
				<?php asutsabo_render_audio_player( $post_id ); ?>
			</header>

			<!-- Layout Grid Wrap (Content + Optional Sidebar) -->
			<div class="asutsabo-layout-container <?php echo $has_sidebar ? 'asutsabo-layout-with-sidebar' : 'asutsabo-layout-single-column'; ?>">
				<!-- Article Body Content Column -->
				<div class="asutsabo-content-column">
					<!-- Editorial Correction Note -->
					<?php asutsabo_render_editorial_correction( $post_id ); ?>

					<!-- In-Article Table of Contents -->
					<?php asutsabo_render_table_of_contents( $post_id ); ?>

					<div class="entry-content asutsabo-article-content" style="font-size:1.125rem;line-height:1.75;">
						<?php
						the_content();

						wp_link_pages(
							array(
								'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'asutsabo' ),
								'after'  => '</div>',
							)
						);
						?>

						<!-- Tags -->
						<?php asutsabo_entry_footer(); ?>

						<!-- Share Row -->
						<?php if ( ! $hide_share ) : ?>
							<?php asutsabo_share_buttons(); ?>
						<?php endif; ?>

						<!-- Author Bio Card -->
						<?php if ( ! $hide_bio ) : ?>
							<?php asutsabo_author_bio(); ?>
						<?php endif; ?>

						<!-- Post Navigation -->
						<nav class="asutsabo-post-navigation" style="margin:2.5rem 0;padding:1.5rem 0;border-top:1px solid var(--wp--preset--color--border, #DED9D0);border-bottom:1px solid var(--wp--preset--color--border, #DED9D0);">
							<?php
							the_post_navigation(
								array(
									'prev_text' => '<span class="nav-subtitle is-style-asutsabo-metadata">' . esc_html__( '&larr; Previous Story', 'asutsabo' ) . '</span> <span class="nav-title" style="display:block;font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.15rem;font-weight:700;margin-top:0.25rem;">%title</span>',
									'next_text' => '<span class="nav-subtitle is-style-asutsabo-metadata">' . esc_html__( 'Next Story &rarr;', 'asutsabo' ) . '</span> <span class="nav-title" style="display:block;font-family:var(--wp--preset--font-family--serif, Georgia, serif);font-size:1.15rem;font-weight:700;margin-top:0.25rem;">%title</span>',
								)
							);
							?>
						</nav>

						<!-- Related Posts -->
						<?php if ( ! $hide_related ) : ?>
							<?php asutsabo_related_posts( 3 ); ?>
						<?php endif; ?>

						<!-- Comments Area -->
						<div class="asutsabo-comments-area" style="margin-top:3.5rem;">
							<?php
							if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;
							?>
						</div>
					</div><!-- .entry-content -->
				</div><!-- .asutsabo-content-column -->

				<?php if ( $has_sidebar ) : ?>
					<div class="asutsabo-sidebar-column">
						<?php get_sidebar(); ?>
					</div>
				<?php endif; ?>
			</div><!-- .asutsabo-layout-container -->

		</article>
	<?php endwhile; ?>
</main><!-- #primary-content -->

<?php
get_footer();
